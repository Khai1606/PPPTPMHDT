﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Forms; // Thêm namespace này

namespace QuanLyHoSoBenhAn
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Đổi Form1() thành Forms.frmMain()
            Application.Run(new frmMain());
        }
    }
}