﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class frmLapToaThuoc : Form
    {
        private readonly ToaThuocService svc = new ToaThuocService();
        private readonly BindingList<ChiTietToaItem> dsChiTiet = new BindingList<ChiTietToaItem>();

        public frmLapToaThuoc()
        {
            InitializeComponent();
        }

        private void frmLapToaThuoc_Load(object sender, EventArgs e)
        {
            // Nạp dữ liệu vào các ComboBox dùng FormHelper
            FormHelper.Nap(cboPhieuKham, svc.LayPhieuKhamChoKeToa(), "HienThi", "MaPhieuKham");
            FormHelper.Nap(cboThuoc, svc.LayDanhMucThuoc(), "TenThuoc", "MaThuoc");

            // Gán nguồn dữ liệu cho DataGridView
            dgvChiTiet.DataSource = dsChiTiet;
        }

        // Nút Thêm Thuốc vào danh sách tạm trên DataGridView
        private void btnThemThuoc_Click(object sender, EventArgs e)
        {
            string maThuoc = FormHelper.Gia(cboThuoc);
            if (string.IsNullOrEmpty(maThuoc))
            {
                MessageBox.Show("Vui lòng chọn loại thuốc.");
                return;
            }

            if (numSoLuong.Value <= 0)
            {
                MessageBox.Show("Số lượng phải lớn hơn 0.");
                return;
            }

            // Kiểm tra xem thuốc đã có trong danh sách chưa
            var tonTai = dsChiTiet.FirstOrDefault(x => x.MaThuoc == maThuoc);
            if (tonTai != null)
            {
                tonTai.SoLuong += (int)numSoLuong.Value;
                dgvChiTiet.Refresh();
            }
            else
            {
                dsChiTiet.Add(new ChiTietToaItem
                {
                    MaThuoc = maThuoc,
                    TenThuoc = cboThuoc.Text,
                    SoLuong = (int)numSoLuong.Value,
                    LieuDung = txtLieuDung.Text.Trim()
                });
            }

            txtLieuDung.Clear();
            numSoLuong.Value = 1;
        }

        // Nút Lưu Toa Thuốc vào CSDL
        private void btnLuuToa_Click(object sender, EventArgs e)
        {
            var ds = dsChiTiet.ToList();

            // Gọi Service và kiểm tra kết quả qua FormHelper.Bao()
            bool thanhCong = FormHelper.Bao(svc.LapToaThuoc(
                txtMaToa.Text.Trim(),
                FormHelper.Gia(cboPhieuKham),
                txtLoiDan.Text.Trim(),
                ds
            ));

            if (thanhCong)
            {
                // Reset lại Form sau khi lưu thành công
                txtMaToa.Clear();
                txtLoiDan.Clear();
                dsChiTiet.Clear();
                FormHelper.Nap(cboPhieuKham, svc.LayPhieuKhamChoKeToa(), "HienThi", "MaPhieuKham");
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}