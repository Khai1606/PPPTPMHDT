﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class frmLapToaThuoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpThongTinToa = new System.Windows.Forms.GroupBox();
            this.txtLoiDan = new System.Windows.Forms.TextBox();
            this.lblLoiDan = new System.Windows.Forms.Label();
            this.cboPhieuKham = new System.Windows.Forms.ComboBox();
            this.lblPhieuKham = new System.Windows.Forms.Label();
            this.txtMaToa = new System.Windows.Forms.TextBox();
            this.lblMaToa = new System.Windows.Forms.Label();
            this.grpChiTietThuoc = new System.Windows.Forms.GroupBox();
            this.btnThemThuoc = new System.Windows.Forms.Button();
            this.txtLieuDung = new System.Windows.Forms.TextBox();
            this.lblLieuDung = new System.Windows.Forms.Label();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.cboThuoc = new System.Windows.Forms.ComboBox();
            this.lblThuoc = new System.Windows.Forms.Label();
            this.dgvChiTiet = new System.Windows.Forms.DataGridView();
            this.btnLuuToa = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpThongTinToa.SuspendLayout();
            this.grpChiTietThuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(260, 15);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(282, 26);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "LẬP TOA THUỐC ĐIỀU TRỊ";
            // 
            // grpThongTinToa
            // 
            this.grpThongTinToa.Controls.Add(this.txtLoiDan);
            this.grpThongTinToa.Controls.Add(this.lblLoiDan);
            this.grpThongTinToa.Controls.Add(this.cboPhieuKham);
            this.grpThongTinToa.Controls.Add(this.lblPhieuKham);
            this.grpThongTinToa.Controls.Add(this.txtMaToa);
            this.grpThongTinToa.Controls.Add(this.lblMaToa);
            this.grpThongTinToa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpThongTinToa.Location = new System.Drawing.Point(15, 50);
            this.grpThongTinToa.Name = "grpThongTinToa";
            this.grpThongTinToa.Size = new System.Drawing.Size(755, 125);
            this.grpThongTinToa.TabIndex = 1;
            this.grpThongTinToa.TabStop = false;
            this.grpThongTinToa.Text = "Thông tin chung toa thuốc";
            // 
            // txtLoiDan
            // 
            this.txtLoiDan.Location = new System.Drawing.Point(115, 65);
            this.txtLoiDan.Multiline = true;
            this.txtLoiDan.Name = "txtLoiDan";
            this.txtLoiDan.Size = new System.Drawing.Size(615, 45);
            this.txtLoiDan.TabIndex = 5;
            // 
            // lblLoiDan
            // 
            this.lblLoiDan.AutoSize = true;
            this.lblLoiDan.Location = new System.Drawing.Point(15, 68);
            this.lblLoiDan.Name = "lblLoiDan";
            this.lblLoiDan.Size = new System.Drawing.Size(89, 15);
            this.lblLoiDan.TabIndex = 4;
            this.lblLoiDan.Text = "Lời dặn bác sĩ:";
            // 
            // cboPhieuKham
            // 
            this.cboPhieuKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhieuKham.FormattingEnabled = true;
            this.cboPhieuKham.Location = new System.Drawing.Point(415, 27);
            this.cboPhieuKham.Name = "cboPhieuKham";
            this.cboPhieuKham.Size = new System.Drawing.Size(315, 23);
            this.cboPhieuKham.TabIndex = 3;
            // 
            // lblPhieuKham
            // 
            this.lblPhieuKham.AutoSize = true;
            this.lblPhieuKham.Location = new System.Drawing.Point(330, 30);
            this.lblPhieuKham.Name = "lblPhieuKham";
            this.lblPhieuKham.Size = new System.Drawing.Size(76, 15);
            this.lblPhieuKham.TabIndex = 2;
            this.lblPhieuKham.Text = "Phiếu khám:";
            // 
            // txtMaToa
            // 
            this.txtMaToa.Location = new System.Drawing.Point(115, 27);
            this.txtMaToa.Name = "txtMaToa";
            this.txtMaToa.Size = new System.Drawing.Size(180, 21);
            this.txtMaToa.TabIndex = 1;
            // 
            // lblMaToa
            // 
            this.lblMaToa.AutoSize = true;
            this.lblMaToa.Location = new System.Drawing.Point(15, 30);
            this.lblMaToa.Name = "lblMaToa";
            this.lblMaToa.Size = new System.Drawing.Size(78, 15);
            this.lblMaToa.TabIndex = 0;
            this.lblMaToa.Text = "Mã toa thuốc:";
            // 
            // grpChiTietThuoc
            // 
            this.grpChiTietThuoc.Controls.Add(this.btnThemThuoc);
            this.grpChiTietThuoc.Controls.Add(this.txtLieuDung);
            this.grpChiTietThuoc.Controls.Add(this.lblLieuDung);
            this.grpChiTietThuoc.Controls.Add(this.numSoLuong);
            this.grpChiTietThuoc.Controls.Add(this.lblSoLuong);
            this.grpChiTietThuoc.Controls.Add(this.cboThuoc);
            this.grpChiTietThuoc.Controls.Add(this.lblThuoc);
            this.grpChiTietThuoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpChiTietThuoc.Location = new System.Drawing.Point(15, 185);
            this.grpChiTietThuoc.Name = "grpChiTietThuoc";
            this.grpChiTietThuoc.Size = new System.Drawing.Size(755, 95);
            this.grpChiTietThuoc.TabIndex = 2;
            this.grpChiTietThuoc.TabStop = false;
            this.grpChiTietThuoc.Text = "Kê đơn chi tiết thuốc";
            // 
            // btnThemThuoc
            // 
            this.btnThemThuoc.Location = new System.Drawing.Point(545, 55);
            this.btnThemThuoc.Name = "btnThemThuoc";
            this.btnThemThuoc.Size = new System.Drawing.Size(185, 28);
            this.btnThemThuoc.TabIndex = 6;
            this.btnThemThuoc.Text = "Thêm vào toa thuốc";
            this.btnThemThuoc.UseVisualStyleBackColor = true;
            this.btnThemThuoc.Click += new System.EventHandler(this.btnThemThuoc_Click);
            // 
            // txtLieuDung
            // 
            this.txtLieuDung.Location = new System.Drawing.Point(545, 22);
            this.txtLieuDung.Name = "txtLieuDung";
            this.txtLieuDung.Size = new System.Drawing.Size(185, 21);
            this.txtLieuDung.TabIndex = 5;
            // 
            // lblLieuDung
            // 
            this.lblLieuDung.AutoSize = true;
            this.lblLieuDung.Location = new System.Drawing.Point(475, 25);
            this.lblLieuDung.Name = "lblLieuDung";
            this.lblLieuDung.Size = new System.Drawing.Size(64, 15);
            this.lblLieuDung.TabIndex = 4;
            this.lblLieuDung.Text = "Liều dùng:";
            // 
            // numSoLuong
            // 
            this.numSoLuong.Location = new System.Drawing.Point(385, 22);
            this.numSoLuong.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numSoLuong.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(70, 21);
            this.numSoLuong.TabIndex = 3;
            this.numSoLuong.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(320, 25);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(59, 15);
            this.lblSoLuong.TabIndex = 2;
            this.lblSoLuong.Text = "Số lượng:";
            // 
            // cboThuoc
            // 
            this.cboThuoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboThuoc.FormattingEnabled = true;
            this.cboThuoc.Location = new System.Drawing.Point(85, 22);
            this.cboThuoc.Name = "cboThuoc";
            this.cboThuoc.Size = new System.Drawing.Size(220, 23);
            this.cboThuoc.TabIndex = 1;
            // 
            // lblThuoc
            // 
            this.lblThuoc.AutoSize = true;
            this.lblThuoc.Location = new System.Drawing.Point(15, 25);
            this.lblThuoc.Name = "lblThuoc";
            this.lblThuoc.Size = new System.Drawing.Size(65, 15);
            this.lblThuoc.TabIndex = 0;
            this.lblThuoc.Text = "Tên thuốc:";
            // 
            // dgvChiTiet
            // 
            this.dgvChiTiet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTiet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTiet.Location = new System.Drawing.Point(15, 290);
            this.dgvChiTiet.Name = "dgvChiTiet";
            this.dgvChiTiet.ReadOnly = true;
            this.dgvChiTiet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTiet.Size = new System.Drawing.Size(755, 200);
            this.dgvChiTiet.TabIndex = 3;
            // 
            // btnLuuToa
            // 
            this.btnLuuToa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuToa.Location = new System.Drawing.Point(500, 505);
            this.btnLuuToa.Name = "btnLuuToa";
            this.btnLuuToa.Size = new System.Drawing.Size(140, 35);
            this.btnLuuToa.TabIndex = 4;
            this.btnLuuToa.Text = "Lưu Toa Thuốc";
            this.btnLuuToa.UseVisualStyleBackColor = true;
            this.btnLuuToa.Click += new System.EventHandler(this.btnLuuToa_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(650, 505);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // frmLapToaThuoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 555);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLuuToa);
            this.Controls.Add(this.dgvChiTiet);
            this.Controls.Add(this.grpChiTietThuoc);
            this.Controls.Add(this.grpThongTinToa);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmLapToaThuoc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lập toa thuốc";
            this.Load += new System.EventHandler(this.frmLapToaThuoc_Load);
            this.grpThongTinToa.ResumeLayout(false);
            this.grpThongTinToa.PerformLayout();
            this.grpChiTietThuoc.ResumeLayout(false);
            this.grpChiTietThuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpThongTinToa;
        private System.Windows.Forms.Label lblMaToa;
        private System.Windows.Forms.TextBox txtMaToa;
        private System.Windows.Forms.Label lblPhieuKham;
        private System.Windows.Forms.ComboBox cboPhieuKham;
        private System.Windows.Forms.Label lblLoiDan;
        private System.Windows.Forms.TextBox txtLoiDan;
        private System.Windows.Forms.GroupBox grpChiTietThuoc;
        private System.Windows.Forms.Label lblThuoc;
        private System.Windows.Forms.ComboBox cboThuoc;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Label lblLieuDung;
        private System.Windows.Forms.TextBox txtLieuDung;
        private System.Windows.Forms.Button btnThemThuoc;
        private System.Windows.Forms.DataGridView dgvChiTiet;
        private System.Windows.Forms.Button btnLuuToa;
        private System.Windows.Forms.Button btnDong;
    }
}