﻿using System;
using System.Windows.Forms;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        // Hàm mở Form con theo đúng chuẩn bài dạy của thầy
        private void Mo(Form f)
        {
            using (f) f.ShowDialog(this);
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            Mo(new frmDangKyBenhNhan());
        }

        private void btnKhamBenh_Click(object sender, EventArgs e)
        {
            Mo(new frmKhamBenh());
        }

        private void btnLapToa_Click(object sender, EventArgs e)
        {
            Mo(new frmLapToaThuoc());
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát ứng dụng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}