﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class frmKhamBenh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpThongTinKham = new System.Windows.Forms.GroupBox();
            this.txtChanDoan = new System.Windows.Forms.TextBox();
            this.lblChanDoan = new System.Windows.Forms.Label();
            this.txtTrieuChung = new System.Windows.Forms.TextBox();
            this.lblTrieuChung = new System.Windows.Forms.Label();
            this.txtHuyetAp = new System.Windows.Forms.TextBox();
            this.lblHuyetAp = new System.Windows.Forms.Label();
            this.numNhietDo = new System.Windows.Forms.NumericUpDown();
            this.lblNhietDo = new System.Windows.Forms.Label();
            this.cboLoaiKham = new System.Windows.Forms.ComboBox();
            this.lblLoaiKham = new System.Windows.Forms.Label();
            this.cboBacSi = new System.Windows.Forms.ComboBox();
            this.lblBacSi = new System.Windows.Forms.Label();
            this.cboHoSo = new System.Windows.Forms.ComboBox();
            this.lblHoSo = new System.Windows.Forms.Label();
            this.txtMaPK = new System.Windows.Forms.TextBox();
            this.lblMaPK = new System.Windows.Forms.Label();
            this.dgvLichSu = new System.Windows.Forms.DataGridView();
            this.btnLuuKham = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpThongTinKham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNhietDo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(230, 15);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(325, 26);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "KHÁM BỆNH & CHẨN ĐOÁN";
            // 
            // grpThongTinKham
            // 
            this.grpThongTinKham.Controls.Add(this.txtChanDoan);
            this.grpThongTinKham.Controls.Add(this.lblChanDoan);
            this.grpThongTinKham.Controls.Add(this.txtTrieuChung);
            this.grpThongTinKham.Controls.Add(this.lblTrieuChung);
            this.grpThongTinKham.Controls.Add(this.txtHuyetAp);
            this.grpThongTinKham.Controls.Add(this.lblHuyetAp);
            this.grpThongTinKham.Controls.Add(this.numNhietDo);
            this.grpThongTinKham.Controls.Add(this.lblNhietDo);
            this.grpThongTinKham.Controls.Add(this.cboLoaiKham);
            this.grpThongTinKham.Controls.Add(this.lblLoaiKham);
            this.grpThongTinKham.Controls.Add(this.cboBacSi);
            this.grpThongTinKham.Controls.Add(this.lblBacSi);
            this.grpThongTinKham.Controls.Add(this.cboHoSo);
            this.grpThongTinKham.Controls.Add(this.lblHoSo);
            this.grpThongTinKham.Controls.Add(this.txtMaPK);
            this.grpThongTinKham.Controls.Add(this.lblMaPK);
            this.grpThongTinKham.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpThongTinKham.Location = new System.Drawing.Point(15, 50);
            this.grpThongTinKham.Name = "grpThongTinKham";
            this.grpThongTinKham.Size = new System.Drawing.Size(755, 180);
            this.grpThongTinKham.TabIndex = 1;
            this.grpThongTinKham.TabStop = false;
            this.grpThongTinKham.Text = "Thông tin đợt khám bệnh";
            // 
            // txtChanDoan
            // 
            this.txtChanDoan.Location = new System.Drawing.Point(115, 135);
            this.txtChanDoan.Name = "txtChanDoan";
            this.txtChanDoan.Size = new System.Drawing.Size(620, 21);
            this.txtChanDoan.TabIndex = 15;
            // 
            // lblChanDoan
            // 
            this.lblChanDoan.AutoSize = true;
            this.lblChanDoan.Location = new System.Drawing.Point(15, 138);
            this.lblChanDoan.Name = "lblChanDoan";
            this.lblChanDoan.Size = new System.Drawing.Size(70, 15);
            this.lblChanDoan.TabIndex = 14;
            this.lblChanDoan.Text = "Chẩn đoán:";
            // 
            // txtTrieuChung
            // 
            this.txtTrieuChung.Location = new System.Drawing.Point(115, 100);
            this.txtTrieuChung.Name = "txtTrieuChung";
            this.txtTrieuChung.Size = new System.Drawing.Size(620, 21);
            this.txtTrieuChung.TabIndex = 13;
            // 
            // lblTrieuChung
            // 
            this.lblTrieuChung.AutoSize = true;
            this.lblTrieuChung.Location = new System.Drawing.Point(15, 103);
            this.lblTrieuChung.Name = "lblTrieuChung";
            this.lblTrieuChung.Size = new System.Drawing.Size(76, 15);
            this.lblTrieuChung.TabIndex = 12;
            this.lblTrieuChung.Text = "Triệu chứng:";
            // 
            // txtHuyetAp
            // 
            this.txtHuyetAp.Location = new System.Drawing.Point(620, 62);
            this.txtHuyetAp.Name = "txtHuyetAp";
            this.txtHuyetAp.Size = new System.Drawing.Size(115, 21);
            this.txtHuyetAp.TabIndex = 11;
            // 
            // lblHuyetAp
            // 
            this.lblHuyetAp.AutoSize = true;
            this.lblHuyetAp.Location = new System.Drawing.Point(550, 65);
            this.lblHuyetAp.Name = "lblHuyetAp";
            this.lblHuyetAp.Size = new System.Drawing.Size(58, 15);
            this.lblHuyetAp.TabIndex = 10;
            this.lblHuyetAp.Text = "Huyết áp:";
            // 
            // numNhietDo
            // 
            this.numNhietDo.DecimalPlaces = 1;
            this.numNhietDo.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numNhietDo.Location = new System.Drawing.Point(435, 62);
            this.numNhietDo.Maximum = new decimal(new int[] {
            42,
            0,
            0,
            0});
            this.numNhietDo.Minimum = new decimal(new int[] {
            35,
            0,
            0,
            0});
            this.numNhietDo.Name = "numNhietDo";
            this.numNhietDo.Size = new System.Drawing.Size(95, 21);
            this.numNhietDo.TabIndex = 9;
            this.numNhietDo.Value = new decimal(new int[] {
            37,
            0,
            0,
            0});
            // 
            // lblNhietDo
            // 
            this.lblNhietDo.AutoSize = true;
            this.lblNhietDo.Location = new System.Drawing.Point(345, 65);
            this.lblNhietDo.Name = "lblNhietDo";
            this.lblNhietDo.Size = new System.Drawing.Size(81, 15);
            this.lblNhietDo.TabIndex = 8;
            this.lblNhietDo.Text = "Thân nhiệt(°C):";
            // 
            // cboLoaiKham
            // 
            this.cboLoaiKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKham.FormattingEnabled = true;
            this.cboLoaiKham.Location = new System.Drawing.Point(115, 62);
            this.cboLoaiKham.Name = "cboLoaiKham";
            this.cboLoaiKham.Size = new System.Drawing.Size(200, 23);
            this.cboLoaiKham.TabIndex = 7;
            // 
            // lblLoaiKham
            // 
            this.lblLoaiKham.AutoSize = true;
            this.lblLoaiKham.Location = new System.Drawing.Point(15, 65);
            this.lblLoaiKham.Name = "lblLoaiKham";
            this.lblLoaiKham.Size = new System.Drawing.Size(68, 15);
            this.lblLoaiKham.TabIndex = 6;
            this.lblLoaiKham.Text = "Loại khám:";
            // 
            // cboBacSi
            // 
            this.cboBacSi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBacSi.FormattingEnabled = true;
            this.cboBacSi.Location = new System.Drawing.Point(550, 25);
            this.cboBacSi.Name = "cboBacSi";
            this.cboBacSi.Size = new System.Drawing.Size(185, 23);
            this.cboBacSi.TabIndex = 5;
            // 
            // lblBacSi
            // 
            this.lblBacSi.AutoSize = true;
            this.lblBacSi.Location = new System.Drawing.Point(465, 28);
            this.lblBacSi.Name = "lblBacSi";
            this.lblBacSi.Size = new System.Drawing.Size(80, 15);
            this.lblBacSi.TabIndex = 4;
            this.lblBacSi.Text = "Bác sĩ khám:";
            // 
            // cboHoSo
            // 
            this.cboHoSo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHoSo.FormattingEnabled = true;
            this.cboHoSo.Location = new System.Drawing.Point(265, 25);
            this.cboHoSo.Name = "cboHoSo";
            this.cboHoSo.Size = new System.Drawing.Size(185, 23);
            this.cboHoSo.TabIndex = 3;
            this.cboHoSo.SelectedIndexChanged += new System.EventHandler(this.cboHoSo_SelectedIndexChanged);
            // 
            // lblHoSo
            // 
            this.lblHoSo.AutoSize = true;
            this.lblHoSo.Location = new System.Drawing.Point(180, 28);
            this.lblHoSo.Name = "lblHoSo";
            this.lblHoSo.Size = new System.Drawing.Size(81, 15);
            this.lblHoSo.TabIndex = 2;
            this.lblHoSo.Text = "Hồ sơ bệnh nhân:";
            // 
            // txtMaPK
            // 
            this.txtMaPK.Location = new System.Drawing.Point(85, 25);
            this.txtMaPK.Name = "txtMaPK";
            this.txtMaPK.Size = new System.Drawing.Size(80, 21);
            this.txtMaPK.TabIndex = 1;
            // 
            // lblMaPK
            // 
            this.lblMaPK.AutoSize = true;
            this.lblMaPK.Location = new System.Drawing.Point(15, 28);
            this.lblMaPK.Name = "lblMaPK";
            this.lblMaPK.Size = new System.Drawing.Size(61, 15);
            this.lblMaPK.TabIndex = 0;
            this.lblMaPK.Text = "Mã phiếu:";
            // 
            // dgvLichSu
            // 
            this.dgvLichSu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLichSu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichSu.Location = new System.Drawing.Point(15, 245);
            this.dgvLichSu.Name = "dgvLichSu";
            this.dgvLichSu.ReadOnly = true;
            this.dgvLichSu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLichSu.Size = new System.Drawing.Size(755, 245);
            this.dgvLichSu.TabIndex = 2;
            // 
            // btnLuuKham
            // 
            this.btnLuuKham.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuKham.Location = new System.Drawing.Point(490, 500);
            this.btnLuuKham.Name = "btnLuuKham";
            this.btnLuuKham.Size = new System.Drawing.Size(150, 35);
            this.btnLuuKham.TabIndex = 3;
            this.btnLuuKham.Text = "Lưu Phiếu Khám";
            this.btnLuuKham.UseVisualStyleBackColor = true;
            this.btnLuuKham.Click += new System.EventHandler(this.btnLuuKham_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(650, 500);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.TabIndex = 4;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // frmKhamBenh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 545);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLuuKham);
            this.Controls.Add(this.dgvLichSu);
            this.Controls.Add(this.grpThongTinKham);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmKhamBenh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khám bệnh & Chẩn đoán";
            this.Load += new System.EventHandler(this.frmKhamBenh_Load);
            this.grpThongTinKham.ResumeLayout(false);
            this.grpThongTinKham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNhietDo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpThongTinKham;
        private System.Windows.Forms.Label lblMaPK;
        private System.Windows.Forms.TextBox txtMaPK;
        private System.Windows.Forms.Label lblHoSo;
        private System.Windows.Forms.ComboBox cboHoSo;
        private System.Windows.Forms.Label lblBacSi;
        private System.Windows.Forms.ComboBox cboBacSi;
        private System.Windows.Forms.Label lblLoaiKham;
        private System.Windows.Forms.ComboBox cboLoaiKham;
        private System.Windows.Forms.Label lblNhietDo;
        private System.Windows.Forms.NumericUpDown numNhietDo;
        private System.Windows.Forms.Label lblHuyetAp;
        private System.Windows.Forms.TextBox txtHuyetAp;
        private System.Windows.Forms.Label lblTrieuChung;
        private System.Windows.Forms.TextBox txtTrieuChung;
        private System.Windows.Forms.Label lblChanDoan;
        private System.Windows.Forms.TextBox txtChanDoan;
        private System.Windows.Forms.DataGridView dgvLichSu;
        private System.Windows.Forms.Button btnLuuKham;
        private System.Windows.Forms.Button btnDong;
    }
}