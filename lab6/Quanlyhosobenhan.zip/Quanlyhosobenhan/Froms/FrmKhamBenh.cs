﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class frmKhamBenh : Form
    {
        private readonly KhamBenhService svc = new KhamBenhService();

        public frmKhamBenh()
        {
            InitializeComponent();
        }

        private void frmKhamBenh_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboHoSo, svc.LayHoSoBenhAn(), "HienThi", "MaHoSo");
            FormHelper.Nap(cboBacSi, svc.LayDanhSachBacSi(), "HienThi", "MaBS");
            cboLoaiKham.Items.AddRange(new object[] { QuyDinh.KhamThuong, QuyDinh.KhamDinhKy });
            cboLoaiKham.SelectedIndex = 0;
            numNhietDo.Value = 37.0m;
            TaiLichSu();
        }

        private void cboHoSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboHoSo.ValueMember == "MaHoSo") TaiLichSu();
        }

        private void TaiLichSu()
        {
            string maHoSo = FormHelper.Gia(cboHoSo);
            if (!string.IsNullOrEmpty(maHoSo))
            {
                dgvLichSu.DataSource = svc.LayLichSuKham(maHoSo);
            }
        }

        private void btnLuuKham_Click(object sender, EventArgs e)
        {
            bool thanhCong = FormHelper.Bao(svc.TaoPhieuKham(
                txtMaPK.Text.Trim(),
                FormHelper.Gia(cboHoSo),
                FormHelper.Gia(cboBacSi),
                numNhietDo.Value,
                txtHuyetAp.Text.Trim(),
                txtTrieuChung.Text.Trim(),
                txtChanDoan.Text.Trim(),
                cboLoaiKham.Text
            ));

            if (thanhCong)
            {
                txtMaPK.Clear();
                txtTrieuChung.Clear();
                txtChanDoan.Clear();
                TaiLichSu();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}