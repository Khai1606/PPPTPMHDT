﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class frmDangKyBenhNhan : Form
    {
        private readonly BenhNhanService svc = new BenhNhanService();

        public frmDangKyBenhNhan()
        {
            InitializeComponent();
        }

        private void frmDangKyBenhNhan_Load(object sender, EventArgs e)
        {
            numLePhi.Value = QuyDinh.LePhiQuanLyNam;
            dtpNgaySinh.Value = new DateTime(1995, 1, 1);
            Tai();
        }

        private void Tai()
        {
            dgvBenhNhan.DataSource = svc.LayDanhSachBenhNhan();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            bool thanhCong = FormHelper.Bao(svc.DangKyBenhNhanMoi(
                txtMaBN.Text.Trim(),
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                txtDiaChi.Text.Trim(),
                txtDienThoai.Text.Trim(),
                txtMaHoSo.Text.Trim(),
                numLePhi.Value
            ));

            if (thanhCong)
            {
                txtMaBN.Clear();
                txtHoTen.Clear();
                txtDiaChi.Clear();
                txtDienThoai.Clear();
                txtMaHoSo.Clear();
                Tai();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}