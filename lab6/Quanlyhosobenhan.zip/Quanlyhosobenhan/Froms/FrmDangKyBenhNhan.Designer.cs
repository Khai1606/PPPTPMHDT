﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class frmDangKyBenhNhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpBenhNhan = new System.Windows.Forms.GroupBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaBN = new System.Windows.Forms.TextBox();
            this.lblMaBN = new System.Windows.Forms.Label();
            this.grpHosSo = new System.Windows.Forms.GroupBox();
            this.numLePhi = new System.Windows.Forms.NumericUpDown();
            this.lblLePhi = new System.Windows.Forms.Label();
            this.txtMaHoSo = new System.Windows.Forms.TextBox();
            this.lblMaHoSo = new System.Windows.Forms.Label();
            this.dgvBenhNhan = new System.Windows.Forms.DataGridView();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpBenhNhan.SuspendLayout();
            this.grpHosSo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLePhi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(220, 15);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(354, 26);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "ĐĂNG KÝ BỆNH NHÂN & HỒ SƠ";
            // 
            // grpBenhNhan
            // 
            this.grpBenhNhan.Controls.Add(this.dtpNgaySinh);
            this.grpBenhNhan.Controls.Add(this.lblNgaySinh);
            this.grpBenhNhan.Controls.Add(this.txtDienThoai);
            this.grpBenhNhan.Controls.Add(this.lblDienThoai);
            this.grpBenhNhan.Controls.Add(this.txtDiaChi);
            this.grpBenhNhan.Controls.Add(this.lblDiaChi);
            this.grpBenhNhan.Controls.Add(this.txtHoTen);
            this.grpBenhNhan.Controls.Add(this.lblHoTen);
            this.grpBenhNhan.Controls.Add(this.txtMaBN);
            this.grpBenhNhan.Controls.Add(this.lblMaBN);
            this.grpBenhNhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBenhNhan.Location = new System.Drawing.Point(15, 50);
            this.grpBenhNhan.Name = "grpBenhNhan";
            this.grpBenhNhan.Size = new System.Drawing.Size(755, 105);
            this.grpBenhNhan.TabIndex = 1;
            this.grpBenhNhan.TabStop = false;
            this.grpBenhNhan.Text = "Thông tin bệnh nhân";
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(620, 25);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(115, 21);
            this.dtpNgaySinh.TabIndex = 5;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Location = new System.Drawing.Point(550, 28);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(65, 15);
            this.lblNgaySinh.TabIndex = 4;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(620, 60);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(115, 21);
            this.txtDienThoai.TabIndex = 9;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(550, 63);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(66, 15);
            this.lblDienThoai.TabIndex = 8;
            this.lblDienThoai.Text = "Điện thoại:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(105, 60);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(425, 21);
            this.txtDiaChi.TabIndex = 7;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 63);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(48, 15);
            this.lblDiaChi.TabIndex = 6;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(325, 25);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(205, 21);
            this.txtHoTen.TabIndex = 3;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(260, 28);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(61, 15);
            this.lblHoTen.TabIndex = 2;
            this.lblHoTen.Text = "Họ và tên:";
            // 
            // txtMaBN
            // 
            this.txtMaBN.Location = new System.Drawing.Point(105, 25);
            this.txtMaBN.Name = "txtMaBN";
            this.txtMaBN.Size = new System.Drawing.Size(135, 21);
            this.txtMaBN.TabIndex = 1;
            // 
            // lblMaBN
            // 
            this.lblMaBN.AutoSize = true;
            this.lblMaBN.Location = new System.Drawing.Point(15, 28);
            this.lblMaBN.Name = "lblMaBN";
            this.lblMaBN.Size = new System.Drawing.Size(89, 15);
            this.lblMaBN.TabIndex = 0;
            this.lblMaBN.Text = "Mã bệnh nhân:";
            // 
            // grpHosSo
            // 
            this.grpHosSo.Controls.Add(this.numLePhi);
            this.grpHosSo.Controls.Add(this.lblLePhi);
            this.grpHosSo.Controls.Add(this.txtMaHoSo);
            this.grpHosSo.Controls.Add(this.lblMaHoSo);
            this.grpHosSo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpHosSo.Location = new System.Drawing.Point(15, 165);
            this.grpHosSo.Name = "grpHosSo";
            this.grpHosSo.Size = new System.Drawing.Size(755, 65);
            this.grpHosSo.TabIndex = 2;
            this.grpHosSo.TabStop = false;
            this.grpHosSo.Text = "Cấp hồ sơ bệnh án & Thu lệ phí hằng năm";
            // 
            // numLePhi
            // 
            this.numLePhi.Location = new System.Drawing.Point(475, 25);
            this.numLePhi.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numLePhi.Name = "numLePhi";
            this.numLePhi.Size = new System.Drawing.Size(160, 21);
            this.numLePhi.TabIndex = 3;
            // 
            // lblLePhi
            // 
            this.lblLePhi.AutoSize = true;
            this.lblLePhi.Location = new System.Drawing.Point(345, 28);
            this.lblLePhi.Name = "lblLePhi";
            this.lblLePhi.Size = new System.Drawing.Size(124, 15);
            this.lblLePhi.TabIndex = 2;
            this.lblLePhi.Text = "Lệ phí quản lý (Năm):";
            // 
            // txtMaHoSo
            // 
            this.txtMaHoSo.Location = new System.Drawing.Point(135, 25);
            this.txtMaHoSo.Name = "txtMaHoSo";
            this.txtMaHoSo.Size = new System.Drawing.Size(175, 21);
            this.txtMaHoSo.TabIndex = 1;
            // 
            // lblMaHoSo
            // 
            this.lblMaHoSo.AutoSize = true;
            this.lblMaHoSo.Location = new System.Drawing.Point(15, 28);
            this.lblMaHoSo.Name = "lblMaHoSo";
            this.lblMaHoSo.Size = new System.Drawing.Size(114, 15);
            this.lblMaHoSo.TabIndex = 0;
            this.lblMaHoSo.Text = "Mã hồ sơ bệnh án:";
            // 
            // dgvBenhNhan
            // 
            this.dgvBenhNhan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBenhNhan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBenhNhan.Location = new System.Drawing.Point(15, 240);
            this.dgvBenhNhan.Name = "dgvBenhNhan";
            this.dgvBenhNhan.ReadOnly = true;
            this.dgvBenhNhan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBenhNhan.Size = new System.Drawing.Size(755, 250);
            this.dgvBenhNhan.TabIndex = 3;
            // 
            // btnDangKy
            // 
            this.btnDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(475, 500);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(165, 35);
            this.btnDangKy.TabIndex = 4;
            this.btnDangKy.Text = "Đăng ký & Cấp hồ sơ";
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(650, 500);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // frmDangKyBenhNhan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 545);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.dgvBenhNhan);
            this.Controls.Add(this.grpHosSo);
            this.Controls.Add(this.grpBenhNhan);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmDangKyBenhNhan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng ký Bệnh nhân & Hồ sơ bệnh án";
            this.Load += new System.EventHandler(this.frmDangKyBenhNhan_Load);
            this.grpBenhNhan.ResumeLayout(false);
            this.grpBenhNhan.PerformLayout();
            this.grpHosSo.ResumeLayout(false);
            this.grpHosSo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLePhi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpBenhNhan;
        private System.Windows.Forms.Label lblMaBN;
        private System.Windows.Forms.TextBox txtMaBN;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.GroupBox grpHosSo;
        private System.Windows.Forms.Label lblMaHoSo;
        private System.Windows.Forms.TextBox txtMaHoSo;
        private System.Windows.Forms.Label lblLePhi;
        private System.Windows.Forms.NumericUpDown numLePhi;
        private System.Windows.Forms.DataGridView dgvBenhNhan;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnDong;
    }
}