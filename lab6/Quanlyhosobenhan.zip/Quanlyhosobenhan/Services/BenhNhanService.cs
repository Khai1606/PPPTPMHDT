﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class BenhNhanService
    {
        // 1. Lấy danh sách bệnh nhân và thông tin hồ sơ
        public DataTable LayDanhSachBenhNhan()
        {
            return Db.Query(@"SELECT bn.MaBN, bn.HoTen, bn.NgaySinh, bn.DiaChi, bn.DienThoai,
                                     hs.MaHoSo, hs.NgayTao, lp.SoTien AS LePhiNam
                              FROM BenhNhan bn
                              JOIN HoSoBenhAn hs ON bn.MaBN = hs.MaBN
                              LEFT JOIN LePhiNam lp ON hs.MaHoSo = lp.MaHoSo AND lp.Nam = YEAR(GETDATE())
                              ORDER BY hs.NgayTao DESC");
        }

        // 2. Đăng ký bệnh nhân mới + Tạo Hồ sơ + Đóng lệ phí năm trong 1 Transaction
        public KetQuaXuLy DangKyBenhNhanMoi(string maBN, string hoTen, DateTime ngaySinh, string diaChi, string dienThoai, string maHoSo, decimal lePhi)
        {
            if (string.IsNullOrWhiteSpace(maBN) || string.IsNullOrWhiteSpace(hoTen) || string.IsNullOrWhiteSpace(maHoSo))
                return KetQuaXuLy.Fail("Mã bệnh nhân, Họ tên và Mã hồ sơ không được để trống.");

            if (lePhi <= 0)
                return KetQuaXuLy.Fail("Lệ phí quản lý hằng năm phải lớn hơn 0.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // 1. Thêm Bệnh nhân
                    Exec(cn, tr, @"INSERT INTO BenhNhan(MaBN, HoTen, NgaySinh, DiaChi, DienThoai)
                                   VALUES(@mbn, @ht, @ns, @dc, @dt)",
                        Db.P("@mbn", maBN), Db.P("@ht", hoTen), Db.P("@ns", ngaySinh.Date), Db.P("@dc", diaChi), Db.P("@dt", dienThoai));

                    // 2. Tạo Hồ sơ bệnh án
                    Exec(cn, tr, @"INSERT INTO HoSoBenhAn(MaHoSo, MaBN, NgayTao, TrangThai)
                                   VALUES(@mhs, @mbn, SYSDATETIME(), @tt)",
                        Db.P("@mhs", maHoSo), Db.P("@mbn", maBN), Db.P("@tt", QuyDinh.DangTheoDoi));

                    // 3. Thu lệ phí quản lý hằng năm
                    string maLePhi = "LP" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    Exec(cn, tr, @"INSERT INTO LePhiNam(MaLePhi, MaHoSo, Nam, NgayThu, SoTien, DaThu)
                                   VALUES(@mlp, @mhs, @nam, SYSDATETIME(), @st, 1)",
                        Db.P("@mlp", maLePhi), Db.P("@mhs", maHoSo), Db.P("@nam", DateTime.Now.Year), Db.P("@st", lePhi));

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã đăng ký bệnh nhân và cấp hồ sơ bệnh án " + maHoSo + " thành công!");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        private static void Exec(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr))
            {
                if (ps != null) cmd.Parameters.AddRange(ps);
                cmd.ExecuteNonQuery();
            }
        }
    }
}