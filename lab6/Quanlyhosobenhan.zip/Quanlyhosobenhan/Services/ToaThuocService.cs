﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    /// <summary>Item lưu thông tin từng dòng thuốc kê trong toa</summary>
    public class ChiTietToaItem
    {
        public string MaThuoc { get; set; }
        public string TenThuoc { get; set; }
        public int SoLuong { get; set; }
        public string LieuDung { get; set; }
    }

    public class ToaThuocService
    {
        // 1. Lấy danh sách phiếu khám để chọn kê toa
        public DataTable LayPhieuKhamChoKeToa()
        {
            return Db.Query(@"SELECT p.MaPhieuKham, 
                                     p.MaPhieuKham + ' - ' + bn.HoTen + ' (' + p.ChanDoan + ')' AS HienThi
                              FROM PhieuKham p
                              JOIN HoSoBenhAn hs ON p.MaHoSo = hs.MaHoSo
                              JOIN BenhNhan bn ON hs.MaBN = bn.MaBN
                              WHERE NOT EXISTS (SELECT 1 FROM ToaThuoc t WHERE t.MaPhieuKham = p.MaPhieuKham)");
        }

        // 2. Lấy danh mục thuốc nạp vào ComboBox
        public DataTable LayDanhMucThuoc()
        {
            return Db.Query("SELECT MaThuoc, TenThuoc, DonViTinh, DonGia FROM Thuoc ORDER BY TenThuoc");
        }

        // 3. Lập toa thuốc sử dụng Transaction (Chuẩn theo DangKyDoanService của thầy)
        public KetQuaXuLy LapToaThuoc(string maToa, string maPhieuKham, string loiDan, List<ChiTietToaItem> dsThuoc)
        {
            if (string.IsNullOrWhiteSpace(maToa) || string.IsNullOrWhiteSpace(maPhieuKham))
                return KetQuaXuLy.Fail("Mã toa thuốc và Mã phiếu khám không được để trống.");

            if (dsThuoc == null || dsThuoc.Count == 0)
                return KetQuaXuLy.Fail("Toa thuốc phải có ít nhất một loại thuốc.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // Thêm bản ghi vào bảng ToaThuoc
                    Exec(cn, tr, @"INSERT INTO ToaThuoc(MaToa, MaPhieuKham, NgayKe, LoiDan)
                                   VALUES(@m, @pk, SYSDATETIME(), @ld)",
                        Db.P("@m", maToa), Db.P("@pk", maPhieuKham), Db.P("@ld", loiDan));

                    // Lặp qua từng thuốc để thêm vào ChiTietToaThuoc
                    foreach (var item in dsThuoc)
                    {
                        Exec(cn, tr, @"INSERT INTO ChiTietToaThuoc(MaToa, MaThuoc, SoLuong, LieuDung)
                                       VALUES(@m, @mt, @sl, @ld)",
                            Db.P("@m", maToa), Db.P("@mt", item.MaThuoc), Db.P("@sl", item.SoLuong), Db.P("@ld", item.LieuDung));
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Lập toa thuốc " + maToa + " thành công!");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        private static void Exec(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr))
            {
                if (ps != null) cmd.Parameters.AddRange(ps);
                cmd.ExecuteNonQuery();
            }
        }
    }
}