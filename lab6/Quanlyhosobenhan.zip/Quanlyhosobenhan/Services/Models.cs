﻿namespace QuanLyHoSoBenhAn.Services
{
    /// <summary>Kết quả của mọi thao tác nghiệp vụ; Form chỉ đọc ThanhCong và ThongBao.</summary>
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; private set; }
        public string ThongBao { get; private set; }

        public static KetQuaXuLy Ok(string thongBao) => new KetQuaXuLy { ThanhCong = true, ThongBao = thongBao };
        public static KetQuaXuLy Fail(string thongBao) => new KetQuaXuLy { ThanhCong = false, ThongBao = thongBao };
    }

    /// <summary>Hằng số quy tắc nghiệp vụ bệnh viện.</summary>
    public static class QuyDinh
    {
        public const decimal LePhiQuanLyNam = 200000; // 200.000đ/năm
        public const string DangTheoDoi = "Đang theo dõi";
        public const string KhamThuong = "Khám thường";
        public const string KhamDinhKy = "Khám định kỳ";
    }
}