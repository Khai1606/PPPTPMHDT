﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class KhamBenhService
    {
        // 1. Lấy danh sách hồ sơ bệnh án đang theo dõi để chọn khám
        public DataTable LayHoSoBenhAn()
        {
            return Db.Query(@"SELECT hs.MaHoSo, hs.MaHoSo + ' - ' + bn.HoTen AS HienThi
                              FROM HoSoBenhAn hs
                              JOIN BenhNhan bn ON hs.MaBN = bn.MaBN
                              WHERE hs.TrangThai = @tt", Db.P("@tt", QuyDinh.DangTheoDoi));
        }

        // 2. Lấy danh sách bác sĩ
        public DataTable LayDanhSachBacSi()
        {
            return Db.Query("SELECT MaBS, MaBS + ' - ' + HoTen AS HienThi FROM BacSi ORDER BY HoTen");
        }

        // 3. Lấy lịch sử phiếu khám bệnh theo mã hồ sơ
        public DataTable LayLichSuKham(string maHoSo)
        {
            return Db.Query(@"SELECT pk.MaPhieuKham, pk.NgayKham, bs.HoTen AS TenBacSi, pk.NhietDo, pk.HuyetAp, pk.TrieuChung, pk.ChanDoan, pk.LoaiKham
                              FROM PhieuKham pk
                              JOIN BacSi bs ON pk.MaBS = bs.MaBS
                              WHERE pk.MaHoSo = @mhs
                              ORDER BY pk.NgayKham DESC", Db.P("@mhs", maHoSo));
        }

        // 4. Tạo mới phiếu khám bệnh
        public KetQuaXuLy TaoPhieuKham(string maPK, string maHoSo, string maBS, decimal nhietDo, string huyetAp, string trieuChung, string chanDoan, string loaiKham)
        {
            if (string.IsNullOrWhiteSpace(maPK) || string.IsNullOrWhiteSpace(maHoSo) || string.IsNullOrWhiteSpace(maBS))
                return KetQuaXuLy.Fail("Mã phiếu khám, Mã hồ sơ và Bác sĩ không được để trống.");

            try
            {
                Db.Execute(@"INSERT INTO PhieuKham(MaPhieuKham, MaHoSo, MaBS, NgayKham, NhietDo, HuyetAp, TrieuChung, ChanDoan, LoaiKham)
                             VALUES(@mpk, @mhs, @mbs, SYSDATETIME(), @nd, @ha, @tc, @cd, @lk)",
                    Db.P("@mpk", maPK), Db.P("@mhs", maHoSo), Db.P("@mbs", maBS),
                    Db.P("@nd", nhietDo), Db.P("@ha", huyetAp), Db.P("@tc", trieuChung),
                    Db.P("@cd", chanDoan), Db.P("@lk", loaiKham));

                return KetQuaXuLy.Ok("Đã lưu thông tin phiếu khám " + maPK + " thành công!");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.Fail(ex.Message);
            }
        }
    }
}