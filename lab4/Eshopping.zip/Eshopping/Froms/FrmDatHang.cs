﻿using System;
using System.Data;
using System.Data.SqlClient;
using Eshopping.Data; // Đổi lại đúng namespace chứa file Db.cs của bạn nếu cần

namespace Eshopping.Services
{
    public class DatHangService
    {
        // 1. Hàm lấy danh sách loại phiếu đặt
        public DataTable GetLoaiPhieuDatHang()
        {
            string sql = "SELECT * FROM LoaiPhieuDatHang";
            return Db.GetData(sql);
        }

        // 2. Hàm lấy danh sách khu vực giao hàng
        public DataTable GetKhuVucGiaoHang()
        {
            string sql = "SELECT * FROM KhuVucGiaoHang";
            return Db.GetData(sql);
        }

        // 3. Hàm lấy danh sách loại thẻ
        public DataTable GetLoaiThe()
        {
            string sql = "SELECT * FROM LoaiThe";
            return Db.GetData(sql);
        }

        // 4. Class trả về kết quả Đặt hàng cho FrmDatHang
        public class KetQuaDatHang
        {
            public bool ThanhCong { get; set; }
            public string ThongBao { get; set; }
        }

        // 5. Hàm tạo phiếu đặt hàng phù hợp với FrmDatHang
        public KetQuaDatHang TaoPhieuDatHang(
            int? maKH,
            int maLoaiPhieu,
            int? maKhuVuc,
            string hoTen,
            string diaChi,
            string sdt,
            decimal chiPhi,
            string loaiThe,
            string soThe,
            DataTable dtGioHang)
        {
            using (var cn = Db.OpenConnection())
            {
                if (cn == null)
                {
                    return new KetQuaDatHang { ThanhCong = false, ThongBao = "Không thể kết nối CSDL!" };
                }

                using (var tx = cn.BeginTransaction())
                {
                    try
                    {
                        // Thêm phiếu đặt
                        string sqlPhieu = @"INSERT INTO PhieuDatHang (MaKH, MaLoaiPhieu, MaKhuVuc, HoTenNguoiNhan, DiaChiNguoiNhan, SoDienThoaiNguoiNhan, ChiPhiGiaoHang, LoaiThe, SoThe, NgayLap)
                                            VALUES (@MaKH, @MaLoaiPhieu, @MaKhuVuc, @HoTen, @DiaChi, @SDT, @ChiPhi, @LoaiThe, @SoThe, GETDATE());
                                            SELECT SCOPE_IDENTITY();";

                        object res = Db.ScalarWithTx(sqlPhieu, tx,
                            new SqlParameter("@MaKH", (object)maKH ?? DBNull.Value),
                            new SqlParameter("@MaLoaiPhieu", maLoaiPhieu),
                            new SqlParameter("@MaKhuVuc", (object)maKhuVuc ?? DBNull.Value),
                            new SqlParameter("@HoTen", (object)hoTen ?? DBNull.Value),
                            new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                            new SqlParameter("@SDT", (object)sdt ?? DBNull.Value),
                            new SqlParameter("@ChiPhi", chiPhi),
                            new SqlParameter("@LoaiThe", (object)loaiThe ?? DBNull.Value),
                            new SqlParameter("@SoThe", (object)soThe ?? DBNull.Value)
                        );

                        int maPhieu = Convert.ToInt32(res);

                        // Thêm chi tiết phiếu đặt
                        string sqlCT = @"INSERT INTO ChiTietPhieuDat (MaPhieu, MaSP, SoLuong, DonGia) 
                                         VALUES (@MaPhieu, @MaSP, @SoLuong, @DonGia)";

                        if (dtGioHang != null)
                        {
                            foreach (DataRow row in dtGioHang.Rows)
                            {
                                Db.ExecuteWithTx(sqlCT, tx,
                                    new SqlParameter("@MaPhieu", maPhieu),
                                    new SqlParameter("@MaSP", row["MaSP"]),
                                    new SqlParameter("@SoLuong", row["SoLuong"]),
                                    new SqlParameter("@DonGia", row["DonGia"])
                                );
                            }
                        }

                        tx.Commit();
                        return new KetQuaDatHang { ThanhCong = true, ThongBao = "Đặt hàng thành công!" };
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        return new KetQuaDatHang { ThanhCong = false, ThongBao = ex.Message };
                    }
                }
            }
        }
    }
}