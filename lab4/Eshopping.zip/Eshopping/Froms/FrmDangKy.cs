﻿using System;
using System.Windows.Forms;
using eShopping.Services;

namespace eShopping
{
    public partial class FrmDangKy : Form
    {
        private readonly KhachHangService khService = new KhachHangService();

        public FrmDangKy()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text) || string.IsNullOrWhiteSpace(txtTenDN.Text) || string.IsNullOrWhiteSpace(txtMK.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ các thông tin bắt buộc (*)", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string err;
            bool ok = khService.DangKy(
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                txtCMND.Text.Trim(),
                txtDiaChi.Text.Trim(),
                txtSDT.Text.Trim(),
                txtTenDN.Text.Trim(),
                txtMK.Text.Trim(),
                txtEmail.Text.Trim(),
                out err
            );

            if (ok)
            {
                MessageBox.Show("Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Đăng ký thất bại: " + err, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}