﻿namespace Eshopping.Froms
{
    partial class FrmDatHang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpSanPham = new System.Windows.Forms.GroupBox();
            this.btnThemVaoGio = new System.Windows.Forms.Button();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.dgvSanPham = new System.Windows.Forms.DataGridView();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.cboNhomSP = new System.Windows.Forms.ComboBox();
            this.grpDonHang = new System.Windows.Forms.GroupBox();
            this.btnDatHang = new System.Windows.Forms.Button();
            this.dtpNgayHetHan = new System.Windows.Forms.DateTimePicker();
            this.txtChuThe = new System.Windows.Forms.TextBox();
            this.txtSoThe = new System.Windows.Forms.TextBox();
            this.cboLoaiThe = new System.Windows.Forms.ComboBox();
            this.chkThanhToanThe = new System.Windows.Forms.CheckBox();
            this.cboKhuVuc = new System.Windows.Forms.ComboBox();
            this.cboLoaiPhieu = new System.Windows.Forms.ComboBox();
            this.txtDiaChiNhan = new System.Windows.Forms.TextBox();
            this.txtSDTNhan = new System.Windows.Forms.TextBox();
            this.txtNguoiNhan = new System.Windows.Forms.TextBox();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.dgvGioHang = new System.Windows.Forms.DataGridView();

            this.grpSanPham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).BeginInit();
            this.grpDonHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).BeginInit();
            this.SuspendLayout();

            // grpSanPham
            this.grpSanPham.Controls.Add(this.btnThemVaoGio);
            this.grpSanPham.Controls.Add(this.numSoLuong);
            this.grpSanPham.Controls.Add(this.dgvSanPham);
            this.grpSanPham.Controls.Add(this.btnTimKiem);
            this.grpSanPham.Controls.Add(this.txtTimKiem);
            this.grpSanPham.Controls.Add(this.cboNhomSP);
            this.grpSanPham.Location = new System.Drawing.Point(12, 12);
            this.grpSanPham.Name = "grpSanPham";
            this.grpSanPham.Size = new System.Drawing.Size(500, 580);
            this.grpSanPham.TabIndex = 0;
            this.grpSanPham.TabStop = false;
            this.grpSanPham.Text = "Danh sách sản phẩm";

            // cboNhomSP
            this.cboNhomSP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhomSP.FormattingEnabled = true;
            this.cboNhomSP.Location = new System.Drawing.Point(10, 25);
            this.cboNhomSP.Name = "cboNhomSP";
            this.cboNhomSP.Size = new System.Drawing.Size(180, 24);

            // txtTimKiem
            this.txtTimKiem.Location = new System.Drawing.Point(200, 25);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(180, 22);

            // btnTimKiem
            this.btnTimKiem.Location = new System.Drawing.Point(390, 23);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(95, 26);
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);

            // dgvSanPham
            this.dgvSanPham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSanPham.Location = new System.Drawing.Point(10, 60);
            this.dgvSanPham.Name = "dgvSanPham";
            this.dgvSanPham.RowHeadersWidth = 51;
            this.dgvSanPham.Size = new System.Drawing.Size(475, 460);

            // numSoLuong
            this.numSoLuong.Location = new System.Drawing.Point(10, 535);
            this.numSoLuong.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(100, 22);
            this.numSoLuong.Value = new decimal(new int[] { 1, 0, 0, 0 });

            // btnThemVaoGio
            this.btnThemVaoGio.Location = new System.Drawing.Point(120, 530);
            this.btnThemVaoGio.Name = "btnThemVaoGio";
            this.btnThemVaoGio.Size = new System.Drawing.Size(130, 32);
            this.btnThemVaoGio.Text = "Thêm vào giỏ";
            this.btnThemVaoGio.Click += new System.EventHandler(this.btnThemVaoGio_Click);

            // grpDonHang
            this.grpDonHang.Controls.Add(this.btnDatHang);
            this.grpDonHang.Controls.Add(this.dtpNgayHetHan);
            this.grpDonHang.Controls.Add(this.txtChuThe);
            this.grpDonHang.Controls.Add(this.txtSoThe);
            this.grpDonHang.Controls.Add(this.cboLoaiThe);
            this.grpDonHang.Controls.Add(this.chkThanhToanThe);
            this.grpDonHang.Controls.Add(this.cboKhuVuc);
            this.grpDonHang.Controls.Add(this.cboLoaiPhieu);
            this.grpDonHang.Controls.Add(this.txtDiaChiNhan);
            this.grpDonHang.Controls.Add(this.txtSDTNhan);
            this.grpDonHang.Controls.Add(this.txtNguoiNhan);
            this.grpDonHang.Controls.Add(this.lblTongTien);
            this.grpDonHang.Controls.Add(this.dgvGioHang);
            this.grpDonHang.Location = new System.Drawing.Point(525, 12);
            this.grpDonHang.Name = "grpDonHang";
            this.grpDonHang.Size = new System.Drawing.Size(445, 580);
            this.grpDonHang.Text = "Thông tin đơn hàng";

            // dgvGioHang
            this.dgvGioHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGioHang.Location = new System.Drawing.Point(10, 25);
            this.dgvGioHang.Name = "dgvGioHang";
            this.dgvGioHang.RowHeadersWidth = 51;
            this.dgvGioHang.Size = new System.Drawing.Size(425, 200);

            // lblTongTien
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTongTien.Location = new System.Drawing.Point(10, 235);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(130, 20);
            this.lblTongTien.Text = "Tổng tiền: 0 VNĐ";

            // txtNguoiNhan
            this.txtNguoiNhan.Location = new System.Drawing.Point(10, 270);
            this.txtNguoiNhan.Name = "txtNguoiNhan";
            this.txtNguoiNhan.Size = new System.Drawing.Size(200, 22);
            this.txtNguoiNhan.Text = "Nguyễn Văn A";

            // txtSDTNhan
            this.txtSDTNhan.Location = new System.Drawing.Point(220, 270);
            this.txtSDTNhan.Name = "txtSDTNhan";
            this.txtSDTNhan.Size = new System.Drawing.Size(215, 22);
            this.txtSDTNhan.Text = "0901234567";

            // txtDiaChiNhan
            this.txtDiaChiNhan.Location = new System.Drawing.Point(10, 305);
            this.txtDiaChiNhan.Name = "txtDiaChiNhan";
            this.txtDiaChiNhan.Size = new System.Drawing.Size(425, 22);
            this.txtDiaChiNhan.Text = "123 Lê Lợi, Q.1, TP.HCM";

            // cboLoaiPhieu
            this.cboLoaiPhieu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiPhieu.Location = new System.Drawing.Point(10, 340);
            this.cboLoaiPhieu.Name = "cboLoaiPhieu";
            this.cboLoaiPhieu.Size = new System.Drawing.Size(200, 24);

            // cboKhuVuc
            this.cboKhuVuc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhuVuc.Location = new System.Drawing.Point(220, 340);
            this.cboKhuVuc.Name = "cboKhuVuc";
            this.cboKhuVuc.Size = new System.Drawing.Size(215, 24);

            // chkThanhToanThe
            this.chkThanhToanThe.AutoSize = true;
            this.chkThanhToanThe.Location = new System.Drawing.Point(10, 380);
            this.chkThanhToanThe.Name = "chkThanhToanThe";
            this.chkThanhToanThe.Size = new System.Drawing.Size(135, 20);
            this.chkThanhToanThe.Text = "Thanh toán thẻ";

            // cboLoaiThe
            this.cboLoaiThe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiThe.Location = new System.Drawing.Point(10, 410);
            this.cboLoaiThe.Name = "cboLoaiThe";
            this.cboLoaiThe.Size = new System.Drawing.Size(120, 24);

            // txtSoThe
            this.txtSoThe.Location = new System.Drawing.Point(140, 410);
            this.txtSoThe.Name = "txtSoThe";
            this.txtSoThe.Size = new System.Drawing.Size(140, 22);
            this.txtSoThe.Text = "************1234";

            // txtChuThe
            this.txtChuThe.Location = new System.Drawing.Point(290, 410);
            this.txtChuThe.Name = "txtChuThe";
            this.txtChuThe.Size = new System.Drawing.Size(145, 22);
            this.txtChuThe.Text = "NGUYEN VAN A";

            // dtpNgayHetHan
            this.dtpNgayHetHan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayHetHan.Location = new System.Drawing.Point(10, 445);
            this.dtpNgayHetHan.Name = "dtpNgayHetHan";
            this.dtpNgayHetHan.Size = new System.Drawing.Size(200, 22);

            // btnDatHang
            this.btnDatHang.BackColor = System.Drawing.Color.LightGreen;
            this.btnDatHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnDatHang.Location = new System.Drawing.Point(10, 495);
            this.btnDatHang.Name = "btnDatHang";
            this.btnDatHang.Size = new System.Drawing.Size(425, 45);
            this.btnDatHang.Text = "ĐẶT HÀNG NGAY";
            this.btnDatHang.UseVisualStyleBackColor = false;
            this.btnDatHang.Click += new System.EventHandler(this.btnDatHang_Click);

            // FrmDatHang
            this.ClientSize = new System.Drawing.Size(982, 603);
            this.Controls.Add(this.grpDonHang);
            this.Controls.Add(this.grpSanPham);
            this.Name = "FrmDatHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Đặt hàng - Eshopping";
            this.Load += new System.EventHandler(this.FrmDatHang_Load);

            this.grpSanPham.ResumeLayout(false);
            this.grpSanPham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).EndInit();
            this.grpDonHang.ResumeLayout(false);
            this.grpDonHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox grpSanPham;
        private System.Windows.Forms.ComboBox cboNhomSP;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.DataGridView dgvSanPham;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Button btnThemVaoGio;

        private System.Windows.Forms.GroupBox grpDonHang;
        private System.Windows.Forms.DataGridView dgvGioHang;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.TextBox txtNguoiNhan;
        private System.Windows.Forms.TextBox txtSDTNhan;
        private System.Windows.Forms.TextBox txtDiaChiNhan;
        private System.Windows.Forms.ComboBox cboLoaiPhieu;
        private System.Windows.Forms.ComboBox cboKhuVuc;
        private System.Windows.Forms.CheckBox chkThanhToanThe;
        private System.Windows.Forms.ComboBox cboLoaiThe;
        private System.Windows.Forms.TextBox txtSoThe;
        private System.Windows.Forms.TextBox txtChuThe;
        private System.Windows.Forms.DateTimePicker dtpNgayHetHan;
        private System.Windows.Forms.Button btnDatHang;
    }
}