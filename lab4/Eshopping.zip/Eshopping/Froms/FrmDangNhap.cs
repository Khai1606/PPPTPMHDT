﻿using eShopping.Services;
using Eshopping.Froms;
using System;
using System.Data;
using System.Windows.Forms;

namespace eShopping
{
    public partial class FrmDangNhap : Form
    {
        private readonly KhachHangService khService = new KhachHangService();
        public static DataRow CurrentUser = null; // Lưu lại thông tin khách hàng vừa đăng nhập thành công

        public FrmDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string user = txtTenDN.Text.Trim();
            string pass = txtMK.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRow kh = khService.DangNhap(user, pass);
            if (kh != null)
            {
                CurrentUser = kh;
                MessageBox.Show($"Chào mừng {kh["HoTen"]} quay trở lại!", "Đăng nhập thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FrmDatHang frmDatHang = new FrmDatHang();
                frmDatHang.FormClosed += (s, args) => this.Close();
                frmDatHang.Show();
            }
            else
            {
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không chính xác!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            FrmDangKy frmKy = new FrmDangKy();
            frmKy.ShowDialog();
        }
    }
}