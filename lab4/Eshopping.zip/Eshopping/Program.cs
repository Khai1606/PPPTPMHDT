﻿using System;
using System.Windows.Forms;

namespace eShopping
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Chạy bắt đầu từ Form Đăng Nhập
            Application.Run(new FrmDangNhap());
        }
    }
}