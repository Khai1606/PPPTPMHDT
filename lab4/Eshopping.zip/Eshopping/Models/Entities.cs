﻿using System;

namespace Eshopping.Models
{
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; set; }
        public string ThongBao { get; set; }

        public static KetQuaXuLy Ok(string msg = "Thành công") => new KetQuaXuLy { ThanhCong = true, ThongBao = msg };
        public static KetQuaXuLy Loi(string msg) => new KetQuaXuLy { ThanhCong = false, ThongBao = msg };
    }

    public class SanPhamModel
    {
        public string MaSP { get; set; }
        public string TenSP { get; set; }
        public int MaNhom { get; set; }
        public string TenNhaSanXuat { get; set; }
        public decimal GiaBanHienHang { get; set; }
        public string TinhTrang { get; set; }
    }

    public class CartItem
    {
        public string MaSP { get; set; }
        public string TenSP { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGiaBan { get; set; }
        public decimal ThanhTien => SoLuong * DonGiaBan;
    }

    public class PhieuDatHangModel
    {
        public int MaKH { get; set; }
        public int MaLoaiPhieu { get; set; }
        public int? MaKhuVuc { get; set; }
        public string HoTenNguoiNhan { get; set; }
        public string DiaChiNguoiNhan { get; set; }
        public string SoDienThoaiNguoiNhan { get; set; }
        public decimal ChiPhiGiaoHang { get; set; }
    }

    public class ThanhToanTheModel
    {
        public string LoaiThe { get; set; }
        public string SoHieuTheAnDanh { get; set; }
        public string TenChuThe { get; set; }
        public DateTime? NgayHetHan { get; set; }
        public decimal LePhi { get; set; }
    }
}