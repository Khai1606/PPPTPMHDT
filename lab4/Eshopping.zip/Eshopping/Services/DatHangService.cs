﻿using System;
using System.Data;
using System.Data.SqlClient;
using Eshopping.Data;

namespace Eshopping.Services
{
    public class DatHangService
    {
        // Hàm lưu đơn hàng khi khách bấm Đặt hàng
        public bool TaoPhieuDatHang(
            int? maKH,
            int maLoaiPhieu,
            int? maKhuVuc,
            string hoTen,
            string diaChi,
            string sdt,
            decimal chiPhi,
            DataTable dtGioHang,
            out string error)
        {
            error = string.Empty;
            using (var cn = Db.OpenConnection())
            {
                if (cn == null)
                {
                    error = "Không thể kết nối CSDL!";
                    return false;
                }

                using (var tx = cn.BeginTransaction())
                {
                    try
                    {
                        // 1. Lưu thông tin phiếu đặt
                        string sqlPhieu = @"INSERT INTO PhieuDatHang (MaKH, MaLoaiPhieu, MaKhuVuc, HoTenNguoiNhan, DiaChiNguoiNhan, SoDienThoaiNguoiNhan, ChiPhiGiaoHang, NgayLap)
                                            VALUES (@MaKH, @MaLoaiPhieu, @MaKhuVuc, @HoTen, @DiaChi, @SDT, @ChiPhi, GETDATE());
                                            SELECT SCOPE_IDENTITY();";

                        object res = Db.ScalarWithTx(sqlPhieu, tx,
                            new SqlParameter("@MaKH", (object)maKH ?? DBNull.Value),
                            new SqlParameter("@MaLoaiPhieu", maLoaiPhieu),
                            new SqlParameter("@MaKhuVuc", (object)maKhuVuc ?? DBNull.Value),
                            new SqlParameter("@HoTen", (object)hoTen ?? DBNull.Value),
                            new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                            new SqlParameter("@SDT", (object)sdt ?? DBNull.Value),
                            new SqlParameter("@ChiPhi", chiPhi)
                        );

                        int maPhieu = Convert.ToInt32(res);

                        // 2. Lưu từng món trong giỏ hàng vào ChiTietPhieuDat
                        string sqlCT = @"INSERT INTO ChiTietPhieuDat (MaPhieu, MaSP, SoLuong, DonGia) 
                                         VALUES (@MaPhieu, @MaSP, @SoLuong, @DonGia)";

                        foreach (DataRow row in dtGioHang.Rows)
                        {
                            Db.ExecuteWithTx(sqlCT, tx,
                                new SqlParameter("@MaPhieu", maPhieu),
                                new SqlParameter("@MaSP", row["MaSP"]),
                                new SqlParameter("@SoLuong", row["SoLuong"]),
                                new SqlParameter("@DonGia", row["DonGia"])
                            );
                        }

                        tx.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        error = ex.Message;
                        return false;
                    }
                }
            }
        }
    }
}