﻿using System.Data;
using System.Data.SqlClient;
using Eshopping.Data;

namespace Eshopping.Services
{
    public class SanPhamService
    {
        public DataTable GetNhomSanPham()
        {
            return Db.Query("SELECT * FROM NhomSanPham");
        }

        public DataTable GetDanhSachSanPham(int? maNhom = null, string tuKhoa = "")
        {
            string sql = @"SELECT sp.MaSP, sp.TenSP, nsp.TenNhom, sp.TenNhaSanXuat, sp.GiaBanHienHang, sp.TinhTrang 
                           FROM SanPham sp 
                           JOIN NhomSanPham nsp ON sp.MaNhom = nsp.MaNhom 
                           WHERE 1=1";

            if (maNhom.HasValue && maNhom.Value > 0)
                sql += " AND sp.MaNhom = " + maNhom.Value;

            if (!string.IsNullOrEmpty(tuKhoa))
                sql += $" AND (sp.TenSP LIKE N'%{tuKhoa}%' OR sp.MaSP LIKE '%{tuKhoa}%')";

            return Db.Query(sql);
        }
    }
}