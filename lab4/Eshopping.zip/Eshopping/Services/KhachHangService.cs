﻿using Eshopping.Data;
using System;
using System.Data;
using System.Data.SqlClient;

namespace eShopping.Services
{
    public class KhachHangService
    {
        // Đăng nhập tài khoản
        public DataRow DangNhap(string tenDangNhap, string matKhau)
        {
            string sql = "SELECT * FROM KhachHang WHERE TenDangNhap = @TenDN AND MatKhau = @MK";
            DataTable dt = Db.Query(sql,
                new SqlParameter("@TenDN", tenDangNhap),
                new SqlParameter("@MK", matKhau));

            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0];
            return null;
        }

        // Đăng ký tài khoản khách hàng mới
        public bool DangKy(string hoTen, DateTime? ngaySinh, string cmnd, string diaChi, string sdt, string tenDN, string matKhau, string email, out string err)
        {
            err = "";
            // Kiểm tra tên đăng nhập tồn tại
            string checkSql = "SELECT COUNT(*) FROM KhachHang WHERE TenDangNhap = @TenDN";
            DataTable dtCheck = Db.Query(checkSql, new SqlParameter("@TenDN", tenDN));
            if (dtCheck != null && Convert.ToInt32(dtCheck.Rows[0][0]) > 0)
            {
                err = "Tên đăng nhập đã tồn tại trong hệ thống!";
                return false;
            }

            string sql = @"INSERT INTO KhachHang(HoTen, NgaySinh, CMND, DiaChi, DienThoai, TenDangNhap, MatKhau, Email)
                           VALUES(@HoTen, @NgaySinh, @CMND, @DiaChi, @SDT, @TenDN, @MK, @Email)";

            try
            {
                Db.Execute(sql,
                    new SqlParameter("@HoTen", hoTen),
                    new SqlParameter("@NgaySinh", (object)ngaySinh ?? DBNull.Value),
                    new SqlParameter("@CMND", (object)cmnd ?? DBNull.Value),
                    new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                    new SqlParameter("@SDT", (object)sdt ?? DBNull.Value),
                    new SqlParameter("@TenDN", tenDN),
                    new SqlParameter("@MK", matKhau),
                    new SqlParameter("@Email", (object)email ?? DBNull.Value)
                );
                return true;
            }
            catch (Exception ex)
            {
                err = ex.Message;
                return false;
            }
        }
    }
}