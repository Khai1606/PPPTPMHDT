﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Eshopping.Data
{
    public class Db
    {
        private static readonly string connectionString = @"Data Source=.;Initial Catalog=EshoppingDB;Integrated Security=True"; // Thay ConnectionString của bạn vào đây

        public static SqlConnection OpenConnection()
        {
            var cn = new SqlConnection(connectionString);
            cn.Open();
            return cn;
        }

        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteScalar();
            }
        }

        public static DataTable GetData(string sql, params SqlParameter[] parameters)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        // --- HÀM XỬ LÝ TRANSACTION ---
        public static object ScalarWithTx(string sql, SqlTransaction tx, params SqlParameter[] parameters)
        {
            using (var cmd = new SqlCommand(sql, tx.Connection, tx))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteScalar();
            }
        }

        public static int ExecuteWithTx(string sql, SqlTransaction tx, params SqlParameter[] parameters)
        {
            using (var cmd = new SqlCommand(sql, tx.Connection, tx))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteNonQuery();
            }
        }
    }
}