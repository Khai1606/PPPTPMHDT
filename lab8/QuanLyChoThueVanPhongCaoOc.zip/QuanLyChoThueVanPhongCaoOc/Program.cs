﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Forms;

namespace QuanLyChoThueCaoOc
{
    static class Program
    {
        /// <summary>
        /// Điểm khởi chạy chính (Main Entry Point) cho ứng dụng WinForms Quản lý cao ốc.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Khởi chạy Trang chủ điều hướng chính FrmMain
            Application.Run(new FrmMain());
        }
    }
}