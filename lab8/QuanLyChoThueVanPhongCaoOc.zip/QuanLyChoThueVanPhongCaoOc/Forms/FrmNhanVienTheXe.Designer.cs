﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmNhanVienTheXe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabNhanVienTheXe = new System.Windows.Forms.TabControl();
            this.tpNhanVien = new System.Windows.Forms.TabPage();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblKhachHang = new System.Windows.Forms.Label();
            this.cboKhachHang = new System.Windows.Forms.ComboBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.lblSoDienThoai = new System.Windows.Forms.Label();
            this.txtSoDienThoai = new System.Windows.Forms.TextBox();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.tpTheXe = new System.Windows.Forms.TabPage();
            this.lblMaTheXe = new System.Windows.Forms.Label();
            this.txtMaTheXe = new System.Windows.Forms.TextBox();
            this.lblNhanVien = new System.Windows.Forms.Label();
            this.cboNhanVien = new System.Windows.Forms.ComboBox();
            this.lblBienSoXe = new System.Windows.Forms.Label();
            this.txtBienSoXe = new System.Windows.Forms.TextBox();
            this.lblLoaiXe = new System.Windows.Forms.Label();
            this.cboLoaiXe = new System.Windows.Forms.ComboBox();
            this.btnCapTheXe = new System.Windows.Forms.Button();
            this.dgvTheXe = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabNhanVienTheXe.SuspendLayout();
            this.tpNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.tpTheXe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheXe)).BeginInit();
            this.SuspendLayout();
            // 
            // tabNhanVienTheXe
            // 
            this.tabNhanVienTheXe.Controls.Add(this.tpNhanVien);
            this.tabNhanVienTheXe.Controls.Add(this.tpTheXe);
            this.tabNhanVienTheXe.Location = new System.Drawing.Point(12, 12);
            this.tabNhanVienTheXe.Name = "tabNhanVienTheXe";
            this.tabNhanVienTheXe.SelectedIndex = 0;
            this.tabNhanVienTheXe.Size = new System.Drawing.Size(660, 380);
            this.tabNhanVienTheXe.TabIndex = 0;
            // 
            // tpNhanVien
            // 
            this.tpNhanVien.Controls.Add(this.dgvNhanVien);
            this.tpNhanVien.Controls.Add(this.btnThemNV);
            this.tpNhanVien.Controls.Add(this.txtSoDienThoai);
            this.tpNhanVien.Controls.Add(this.lblSoDienThoai);
            this.tpNhanVien.Controls.Add(this.txtChucVu);
            this.tpNhanVien.Controls.Add(this.lblChucVu);
            this.tpNhanVien.Controls.Add(this.txtHoTen);
            this.tpNhanVien.Controls.Add(this.lblHoTen);
            this.tpNhanVien.Controls.Add(this.cboPhong);
            this.tpNhanVien.Controls.Add(this.lblPhong);
            this.tpNhanVien.Controls.Add(this.cboKhachHang);
            this.tpNhanVien.Controls.Add(this.lblKhachHang);
            this.tpNhanVien.Controls.Add(this.txtMaNV);
            this.tpNhanVien.Controls.Add(this.lblMaNV);
            this.tpNhanVien.Location = new System.Drawing.Point(4, 22);
            this.tpNhanVien.Name = "tpNhanVien";
            this.tpNhanVien.Padding = new System.Windows.Forms.Padding(3);
            this.tpNhanVien.Size = new System.Drawing.Size(652, 354);
            this.tpNhanVien.TabIndex = 0;
            this.tpNhanVien.Text = "Nhân Viên Công Ty";
            this.tpNhanVien.UseVisualStyleBackColor = true;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Location = new System.Drawing.Point(15, 15);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(43, 13);
            this.lblMaNV.Text = "Mã NV:";
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(80, 12);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(120, 20);
            this.txtMaNV.TabIndex = 1;
            // 
            // lblKhachHang
            // 
            this.lblKhachHang.AutoSize = true;
            this.lblKhachHang.Location = new System.Drawing.Point(220, 15);
            this.lblKhachHang.Name = "lblKhachHang";
            this.lblKhachHang.Size = new System.Drawing.Size(67, 13);
            this.lblKhachHang.Text = "Công ty/KH:";
            // 
            // cboKhachHang
            // 
            this.cboKhachHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhachHang.FormattingEnabled = true;
            this.cboKhachHang.Location = new System.Drawing.Point(293, 12);
            this.cboKhachHang.Name = "cboKhachHang";
            this.cboKhachHang.Size = new System.Drawing.Size(340, 21);
            this.cboKhachHang.TabIndex = 3;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(15, 48);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(41, 13);
            this.lblPhong.Text = "Phòng:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(80, 45);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(120, 21);
            this.cboPhong.TabIndex = 5;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(220, 48);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(42, 13);
            this.lblHoTen.Text = "Họ tên:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(293, 45);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(180, 20);
            this.txtHoTen.TabIndex = 7;
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Location = new System.Drawing.Point(15, 81);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(50, 13);
            this.lblChucVu.Text = "Chức vụ:";
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(80, 78);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(120, 20);
            this.txtChucVu.TabIndex = 9;
            // 
            // lblSoDienThoai
            // 
            this.lblSoDienThoai.AutoSize = true;
            this.lblSoDienThoai.Location = new System.Drawing.Point(220, 81);
            this.lblSoDienThoai.Name = "lblSoDienThoai";
            this.lblSoDienThoai.Size = new System.Drawing.Size(31, 13);
            this.lblSoDienThoai.Text = "SĐT:";
            // 
            // txtSoDienThoai
            // 
            this.txtSoDienThoai.Location = new System.Drawing.Point(293, 78);
            this.txtSoDienThoai.Name = "txtSoDienThoai";
            this.txtSoDienThoai.Size = new System.Drawing.Size(180, 20);
            this.txtSoDienThoai.TabIndex = 11;
            // 
            // btnThemNV
            // 
            this.btnThemNV.Location = new System.Drawing.Point(513, 75);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(120, 25);
            this.btnThemNV.TabIndex = 12;
            this.btnThemNV.Text = "Thêm Nhân Viên";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AllowUserToAddRows = false;
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Location = new System.Drawing.Point(15, 115);
            this.dgvNhanVien.MultiSelect = false;
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.ReadOnly = true;
            this.dgvNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNhanVien.Size = new System.Drawing.Size(618, 225);
            this.dgvNhanVien.TabIndex = 13;
            // 
            // tpTheXe
            // 
            this.tpTheXe.Controls.Add(this.dgvTheXe);
            this.tpTheXe.Controls.Add(this.btnCapTheXe);
            this.tpTheXe.Controls.Add(this.cboLoaiXe);
            this.tpTheXe.Controls.Add(this.lblLoaiXe);
            this.tpTheXe.Controls.Add(this.txtBienSoXe);
            this.tpTheXe.Controls.Add(this.lblBienSoXe);
            this.tpTheXe.Controls.Add(this.cboNhanVien);
            this.tpTheXe.Controls.Add(this.lblNhanVien);
            this.tpTheXe.Controls.Add(this.txtMaTheXe);
            this.tpTheXe.Controls.Add(this.lblMaTheXe);
            this.tpTheXe.Location = new System.Drawing.Point(4, 22);
            this.tpTheXe.Name = "tpTheXe";
            this.tpTheXe.Padding = new System.Windows.Forms.Padding(3);
            this.tpTheXe.Size = new System.Drawing.Size(652, 354);
            this.tpTheXe.TabIndex = 1;
            this.tpTheXe.Text = "Cấp Thẻ Giữ Xe";
            this.tpTheXe.UseVisualStyleBackColor = true;
            // 
            // lblMaTheXe
            // 
            this.lblMaTheXe.AutoSize = true;
            this.lblMaTheXe.Location = new System.Drawing.Point(15, 18);
            this.lblMaTheXe.Name = "lblMaTheXe";
            this.lblMaTheXe.Size = new System.Drawing.Size(60, 13);
            this.lblMaTheXe.Text = "Mã Thẻ xe:";
            // 
            // txtMaTheXe
            // 
            this.txtMaTheXe.Location = new System.Drawing.Point(85, 15);
            this.txtMaTheXe.Name = "txtMaTheXe";
            this.txtMaTheXe.Size = new System.Drawing.Size(130, 20);
            this.txtMaTheXe.TabIndex = 1;
            // 
            // lblNhanVien
            // 
            this.lblNhanVien.AutoSize = true;
            this.lblNhanVien.Location = new System.Drawing.Point(235, 18);
            this.lblNhanVien.Name = "lblNhanVien";
            this.lblNhanVien.Size = new System.Drawing.Size(59, 13);
            this.lblNhanVien.Text = "Nhân viên:";
            // 
            // cboNhanVien
            // 
            this.cboNhanVien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhanVien.FormattingEnabled = true;
            this.cboNhanVien.Location = new System.Drawing.Point(300, 15);
            this.cboNhanVien.Name = "cboNhanVien";
            this.cboNhanVien.Size = new System.Drawing.Size(330, 21);
            this.cboNhanVien.TabIndex = 3;
            // 
            // lblBienSoXe
            // 
            this.lblBienSoXe.AutoSize = true;
            this.lblBienSoXe.Location = new System.Drawing.Point(15, 53);
            this.lblBienSoXe.Name = "lblBienSoXe";
            this.lblBienSoXe.Size = new System.Drawing.Size(60, 13);
            this.lblBienSoXe.Text = "Biển số xe:";
            // 
            // txtBienSoXe
            // 
            this.txtBienSoXe.Location = new System.Drawing.Point(85, 50);
            this.txtBienSoXe.Name = "txtBienSoXe";
            this.txtBienSoXe.Size = new System.Drawing.Size(130, 20);
            this.txtBienSoXe.TabIndex = 5;
            // 
            // lblLoaiXe
            // 
            this.lblLoaiXe.AutoSize = true;
            this.lblLoaiXe.Location = new System.Drawing.Point(235, 53);
            this.lblLoaiXe.Name = "lblLoaiXe";
            this.lblLoaiXe.Size = new System.Drawing.Size(44, 13);
            this.lblLoaiXe.Text = "Loại xe:";
            // 
            // cboLoaiXe
            // 
            this.cboLoaiXe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiXe.FormattingEnabled = true;
            this.cboLoaiXe.Items.AddRange(new object[] {
            "Xe máy",
            "Ô tô",
            "Xe điện"});
            this.cboLoaiXe.Location = new System.Drawing.Point(300, 50);
            this.cboLoaiXe.Name = "cboLoaiXe";
            this.cboLoaiXe.Size = new System.Drawing.Size(150, 21);
            this.cboLoaiXe.TabIndex = 7;
            // 
            // btnCapTheXe
            // 
            this.btnCapTheXe.Location = new System.Drawing.Point(480, 48);
            this.btnCapTheXe.Name = "btnCapTheXe";
            this.btnCapTheXe.Size = new System.Drawing.Size(150, 25);
            this.btnCapTheXe.TabIndex = 8;
            this.btnCapTheXe.Text = "Cấp Thẻ Giữ Xe";
            this.btnCapTheXe.UseVisualStyleBackColor = true;
            this.btnCapTheXe.Click += new System.EventHandler(this.btnCapTheXe_Click);
            // 
            // dgvTheXe
            // 
            this.dgvTheXe.AllowUserToAddRows = false;
            this.dgvTheXe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheXe.Location = new System.Drawing.Point(15, 90);
            this.dgvTheXe.MultiSelect = false;
            this.dgvTheXe.Name = "dgvTheXe";
            this.dgvTheXe.ReadOnly = true;
            this.dgvTheXe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTheXe.Size = new System.Drawing.Size(615, 250);
            this.dgvTheXe.TabIndex = 9;
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(597, 400);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 25);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmNhanVienTheXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 436);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabNhanVienTheXe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmNhanVienTheXe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản Lý Nhân Viên & Cấp Thẻ Giữ Xe Cao Ốc";
            this.Load += new System.EventHandler(this.FrmNhanVienTheXe_Load);
            this.tabNhanVienTheXe.ResumeLayout(false);
            this.tpNhanVien.ResumeLayout(false);
            this.tpNhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.tpTheXe.ResumeLayout(false);
            this.tpTheXe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheXe)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabNhanVienTheXe;
        private System.Windows.Forms.TabPage tpNhanVien;
        private System.Windows.Forms.TabPage tpTheXe;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblKhachHang;
        private System.Windows.Forms.ComboBox cboKhachHang;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Label lblSoDienThoai;
        private System.Windows.Forms.TextBox txtSoDienThoai;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.Label lblMaTheXe;
        private System.Windows.Forms.TextBox txtMaTheXe;
        private System.Windows.Forms.Label lblNhanVien;
        private System.Windows.Forms.ComboBox cboNhanVien;
        private System.Windows.Forms.Label lblBienSoXe;
        private System.Windows.Forms.TextBox txtBienSoXe;
        private System.Windows.Forms.Label lblLoaiXe;
        private System.Windows.Forms.ComboBox cboLoaiXe;
        private System.Windows.Forms.Button btnCapTheXe;
        private System.Windows.Forms.DataGridView dgvTheXe;
        private System.Windows.Forms.Button btnDong;
    }
}