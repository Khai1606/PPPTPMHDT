﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmHoaDonDichVu : Form
    {
        private readonly DichVuService svc = new DichVuService();

        public FrmHoaDonDichVu()
        {
            InitializeComponent();
        }

        private void FrmHoaDonDichVu_Load(object sender, EventArgs e)
        {
            txtThangNam.Text = DateTime.Today.ToString("MM/yyyy");
            FormHelper.Nap(cboPhong, svc.LayPhongDaThue(), "HienThi", "MaPhong");
            TaiDanhSach();
        }

        private void TaiDanhSach()
        {
            dgvHoaDonDV.DataSource = svc.LayDanhSachHoaDonDV();
        }

        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string maPhong = FormHelper.Gia(cboPhong);
            var k = svc.LapHoaDonDV(txtMaHDDV.Text, maPhong, txtThangNam.Text,
                                    numDienCu.Value, numDienMoi.Value,
                                    numNuocCu.Value, numNuocMoi.Value,
                                    numInternet.Value);
            if (FormHelper.Bao(k)) TaiDanhSach();
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string maHDDV = FormHelper.O(dgvHoaDonDV, "MaHoaDonDV");
            if (string.IsNullOrEmpty(maHDDV))
            {
                MessageBox.Show("Vui lòng chọn hóa đơn dịch vụ cần thanh toán từ danh sách bên dưới.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var k = svc.XacNhanThanhToanDV(maHDDV);
            if (FormHelper.Bao(k)) TaiDanhSach();
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}