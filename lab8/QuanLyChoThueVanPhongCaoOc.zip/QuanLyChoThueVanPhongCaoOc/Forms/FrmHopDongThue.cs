﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmHopDongThue : Form
    {
        private readonly HopDongThueService svc = new HopDongThueService();

        public FrmHopDongThue()
        {
            InitializeComponent();
        }

        private void FrmHopDongThue_Load(object sender, EventArgs e)
        {
            dtNgayBatDau.Value = DateTime.Today;
            TaiPhongTrong();
            TaiDanhSach();
        }

        private void TaiDanhSach()
        {
            dgvHopDong.DataSource = svc.LayDanhSach();
        }

        private void TaiPhongTrong()
        {
            clbPhongTrong.DataSource = svc.LayPhongTrong();
            clbPhongTrong.DisplayMember = "HienThi";
            clbPhongTrong.ValueMember = "MaPhong";
        }

        private void btnKyHopDong_Click(object sender, EventArgs e)
        {
            List<string> dsPhongChon = new List<string>();
            foreach (var item in clbPhongTrong.CheckedItems)
            {
                var row = item as System.Data.DataRowView;
                if (row != null) dsPhongChon.Add(row["MaPhong"].ToString());
            }

            var k = svc.KyHopDong(txtMaHopDong.Text, txtMaKH.Text, txtTenCongTy.Text,
                                 txtSoDienThoai.Text, txtEmail.Text, txtMaSoThue.Text,
                                 txtDiaChi.Text, dtNgayBatDau.Value, (int)numThoiHanThue.Value,
                                 numTienCoc.Value, dsPhongChon);

            if (FormHelper.Bao(k))
            {
                TaiPhongTrong();
                TaiDanhSach();
            }
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}