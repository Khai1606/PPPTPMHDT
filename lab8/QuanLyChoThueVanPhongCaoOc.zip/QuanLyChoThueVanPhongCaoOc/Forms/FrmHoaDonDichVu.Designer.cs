﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmHoaDonDichVu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblMaHDDV = new System.Windows.Forms.Label();
            this.txtMaHDDV = new System.Windows.Forms.TextBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblThangNam = new System.Windows.Forms.Label();
            this.txtThangNam = new System.Windows.Forms.TextBox();
            this.grpDien = new System.Windows.Forms.GroupBox();
            this.lblDienCu = new System.Windows.Forms.Label();
            this.numDienCu = new System.Windows.Forms.NumericUpDown();
            this.lblDienMoi = new System.Windows.Forms.Label();
            this.numDienMoi = new System.Windows.Forms.NumericUpDown();
            this.grpNuoc = new System.Windows.Forms.GroupBox();
            this.lblNuocCu = new System.Windows.Forms.Label();
            this.numNuocCu = new System.Windows.Forms.NumericUpDown();
            this.lblNuocMoi = new System.Windows.Forms.Label();
            this.numNuocMoi = new System.Windows.Forms.NumericUpDown();
            this.lblInternet = new System.Windows.Forms.Label();
            this.numInternet = new System.Windows.Forms.NumericUpDown();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvHoaDonDV = new System.Windows.Forms.DataGridView();
            this.grpDien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDienCu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDienMoi)).BeginInit();
            this.grpNuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNuocCu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNuocMoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInternet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDonDV)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaHDDV
            // 
            this.lblMaHDDV.AutoSize = true;
            this.lblMaHDDV.Location = new System.Drawing.Point(15, 20);
            this.lblMaHDDV.Name = "lblMaHDDV";
            this.lblMaHDDV.Size = new System.Drawing.Size(60, 13);
            this.lblMaHDDV.Text = "Mã HD DV:";
            // 
            // txtMaHDDV
            // 
            this.txtMaHDDV.Location = new System.Drawing.Point(85, 17);
            this.txtMaHDDV.Name = "txtMaHDDV";
            this.txtMaHDDV.Size = new System.Drawing.Size(120, 20);
            this.txtMaHDDV.TabIndex = 1;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(220, 20);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(41, 13);
            this.lblPhong.Text = "Phòng:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(265, 17);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(180, 21);
            this.cboPhong.TabIndex = 3;
            // 
            // lblThangNam
            // 
            this.lblThangNam.AutoSize = true;
            this.lblThangNam.Location = new System.Drawing.Point(460, 20);
            this.lblThangNam.Name = "lblThangNam";
            this.lblThangNam.Size = new System.Drawing.Size(65, 13);
            this.lblThangNam.Text = "Tháng/Năm:";
            // 
            // txtThangNam
            // 
            this.txtThangNam.Location = new System.Drawing.Point(530, 17);
            this.txtThangNam.Name = "txtThangNam";
            this.txtThangNam.Size = new System.Drawing.Size(100, 20);
            this.txtThangNam.TabIndex = 5;
            // 
            // grpDien
            // 
            this.grpDien.Controls.Add(this.numDienMoi);
            this.grpDien.Controls.Add(this.lblDienMoi);
            this.grpDien.Controls.Add(this.numDienCu);
            this.grpDien.Controls.Add(this.lblDienCu);
            this.grpDien.Location = new System.Drawing.Point(15, 50);
            this.grpDien.Name = "grpDien";
            this.grpDien.Size = new System.Drawing.Size(300, 55);
            this.grpDien.TabIndex = 6;
            this.grpDien.TabStop = false;
            this.grpDien.Text = "Điện sinh hoạt (kWh)";
            // 
            // lblDienCu
            // 
            this.lblDienCu.AutoSize = true;
            this.lblDienCu.Location = new System.Drawing.Point(10, 25);
            this.lblDienCu.Name = "lblDienCu";
            this.lblDienCu.Size = new System.Drawing.Size(23, 13);
            this.lblDienCu.Text = "Cũ:";
            // 
            // numDienCu
            // 
            this.numDienCu.Location = new System.Drawing.Point(38, 22);
            this.numDienCu.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numDienCu.Name = "numDienCu";
            this.numDienCu.Size = new System.Drawing.Size(100, 20);
            this.numDienCu.TabIndex = 1;
            // 
            // lblDienMoi
            // 
            this.lblDienMoi.AutoSize = true;
            this.lblDienMoi.Location = new System.Drawing.Point(150, 25);
            this.lblDienMoi.Name = "lblDienMoi";
            this.lblDienMoi.Size = new System.Drawing.Size(27, 13);
            this.lblDienMoi.Text = "Mới:";
            // 
            // numDienMoi
            // 
            this.numDienMoi.Location = new System.Drawing.Point(183, 22);
            this.numDienMoi.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numDienMoi.Name = "numDienMoi";
            this.numDienMoi.Size = new System.Drawing.Size(100, 20);
            this.numDienMoi.TabIndex = 3;
            // 
            // grpNuoc
            // 
            this.grpNuoc.Controls.Add(this.numNuocMoi);
            this.grpNuoc.Controls.Add(this.lblNuocMoi);
            this.grpNuoc.Controls.Add(this.numNuocCu);
            this.grpNuoc.Controls.Add(this.lblNuocCu);
            this.grpNuoc.Location = new System.Drawing.Point(330, 50);
            this.grpNuoc.Name = "grpNuoc";
            this.grpNuoc.Size = new System.Drawing.Size(300, 55);
            this.grpNuoc.TabIndex = 7;
            this.grpNuoc.TabStop = false;
            this.grpNuoc.Text = "Nước sinh hoạt (m3)";
            // 
            // lblNuocCu
            // 
            this.lblNuocCu.AutoSize = true;
            this.lblNuocCu.Location = new System.Drawing.Point(10, 25);
            this.lblNuocCu.Name = "lblNuocCu";
            this.lblNuocCu.Size = new System.Drawing.Size(23, 13);
            this.lblNuocCu.Text = "Cũ:";
            // 
            // numNuocCu
            // 
            this.numNuocCu.Location = new System.Drawing.Point(38, 22);
            this.numNuocCu.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numNuocCu.Name = "numNuocCu";
            this.numNuocCu.Size = new System.Drawing.Size(100, 20);
            this.numNuocCu.TabIndex = 1;
            // 
            // lblNuocMoi
            // 
            this.lblNuocMoi.AutoSize = true;
            this.lblNuocMoi.Location = new System.Drawing.Point(150, 25);
            this.lblNuocMoi.Name = "lblNuocMoi";
            this.lblNuocMoi.Size = new System.Drawing.Size(27, 13);
            this.lblNuocMoi.Text = "Mới:";
            // 
            // numNuocMoi
            // 
            this.numNuocMoi.Location = new System.Drawing.Point(183, 22);
            this.numNuocMoi.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numNuocMoi.Name = "numNuocMoi";
            this.numNuocMoi.Size = new System.Drawing.Size(100, 20);
            this.numNuocMoi.TabIndex = 3;
            // 
            // lblInternet
            // 
            this.lblInternet.AutoSize = true;
            this.lblInternet.Location = new System.Drawing.Point(15, 120);
            this.lblInternet.Name = "lblInternet";
            this.lblInternet.Size = new System.Drawing.Size(80, 13);
            this.lblInternet.Text = "Cước Internet:";
            // 
            // numInternet
            // 
            this.numInternet.Location = new System.Drawing.Point(100, 117);
            this.numInternet.Maximum = new decimal(new int[] { 50000000, 0, 0, 0 });
            this.numInternet.Name = "numInternet";
            this.numInternet.Size = new System.Drawing.Size(130, 20);
            this.numInternet.TabIndex = 9;
            this.numInternet.ThousandsSeparator = true;
            this.numInternet.Value = new decimal(new int[] { 500000, 0, 0, 0 });
            // 
            // btnLapHoaDon
            // 
            this.btnLapHoaDon.Location = new System.Drawing.Point(250, 114);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(125, 26);
            this.btnLapHoaDon.TabIndex = 10;
            this.btnLapHoaDon.Text = "Lập Hóa Đơn DV";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;
            this.btnLapHoaDon.Click += new System.EventHandler(this.btnLapHoaDon_Click);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Location = new System.Drawing.Point(385, 114);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(135, 26);
            this.btnThanhToan.TabIndex = 11;
            this.btnThanhToan.Text = "Xác Nhận Thanh Toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(555, 114);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 26);
            this.btnDong.TabIndex = 12;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvHoaDonDV
            // 
            this.dgvHoaDonDV.AllowUserToAddRows = false;
            this.dgvHoaDonDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDonDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDonDV.Location = new System.Drawing.Point(15, 155);
            this.dgvHoaDonDV.MultiSelect = false;
            this.dgvHoaDonDV.Name = "dgvHoaDonDV";
            this.dgvHoaDonDV.ReadOnly = true;
            this.dgvHoaDonDV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoaDonDV.Size = new System.Drawing.Size(615, 235);
            this.dgvHoaDonDV.TabIndex = 13;
            // 
            // FrmHoaDonDichVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 402);
            this.Controls.Add(this.dgvHoaDonDV);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.numInternet);
            this.Controls.Add(this.lblInternet);
            this.Controls.Add(this.grpNuoc);
            this.Controls.Add(this.grpDien);
            this.Controls.Add(this.txtThangNam);
            this.Controls.Add(this.lblThangNam);
            this.Controls.Add(this.cboPhong);
            this.Controls.Add(this.lblPhong);
            this.Controls.Add(this.txtMaHDDV);
            this.Controls.Add(this.lblMaHDDV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmHoaDonDichVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Chốt Chỉ Số & Thu Chi Phí Dịch Vụ Văn Phòng";
            this.Load += new System.EventHandler(this.FrmHoaDonDichVu_Load);
            this.grpDien.ResumeLayout(false);
            this.grpDien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDienCu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDienMoi)).EndInit();
            this.grpNuoc.ResumeLayout(false);
            this.grpNuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNuocCu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNuocMoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInternet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDonDV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaHDDV;
        private System.Windows.Forms.TextBox txtMaHDDV;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblThangNam;
        private System.Windows.Forms.TextBox txtThangNam;
        private System.Windows.Forms.GroupBox grpDien;
        private System.Windows.Forms.Label lblDienCu;
        private System.Windows.Forms.NumericUpDown numDienCu;
        private System.Windows.Forms.Label lblDienMoi;
        private System.Windows.Forms.NumericUpDown numDienMoi;
        private System.Windows.Forms.GroupBox grpNuoc;
        private System.Windows.Forms.Label lblNuocCu;
        private System.Windows.Forms.NumericUpDown numNuocCu;
        private System.Windows.Forms.Label lblNuocMoi;
        private System.Windows.Forms.NumericUpDown numNuocMoi;
        private System.Windows.Forms.Label lblInternet;
        private System.Windows.Forms.NumericUpDown numInternet;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.DataGridView dgvHoaDonDV;
    }
}