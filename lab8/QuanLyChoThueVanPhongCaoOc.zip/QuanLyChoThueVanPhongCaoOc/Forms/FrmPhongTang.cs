﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmPhongTang : Form
    {
        private readonly PhongTangService svc = new PhongTangService();

        public FrmPhongTang()
        {
            InitializeComponent();
        }

        private void FrmPhongTang_Load(object sender, EventArgs e)
        {
            TaiTang();
            TaiPhong();
        }

        private void TaiTang()
        {
            dgvTang.DataSource = svc.LayDanhSachTang();
            FormHelper.Nap(cboTang, svc.LayDanhSachTang(), "TenTang", "MaTang");
        }

        private void TaiPhong()
        {
            dgvPhong.DataSource = svc.LayDanhSachPhong();
        }

        private void btnThemTang_Click(object sender, EventArgs e)
        {
            var k = svc.ThemTang(txtMaTang.Text, txtTenTang.Text, (int)numSoLuongPhong.Value, (double)numViTriDoCao.Value);
            if (FormHelper.Bao(k)) TaiTang();
        }

        private void btnThemPhong_Click(object sender, EventArgs e)
        {
            var k = svc.ThemPhong(txtMaPhong.Text, FormHelper.Gia(cboTang), txtHuongPhong.Text, (double)numDienTich.Value, numDonGiaThue.Value);
            if (FormHelper.Bao(k)) TaiPhong();
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}