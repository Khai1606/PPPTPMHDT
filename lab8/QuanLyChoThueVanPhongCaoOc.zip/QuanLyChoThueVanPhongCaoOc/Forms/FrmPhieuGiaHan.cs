﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmPhieuGiaHan : Form
    {
        private readonly GiaHanService svc = new GiaHanService();

        public FrmPhieuGiaHan()
        {
            InitializeComponent();
        }

        private void FrmPhieuGiaHan_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboHopDong, svc.LayHopDongHieuLuc(), "HienThi", "MaHopDong");
            TaiDanhSach();
        }

        private void TaiDanhSach()
        {
            dgvPhieuGiaHan.DataSource = svc.LayDanhSach();
        }

        private void btnLapPhieuGiaHan_Click(object sender, EventArgs e)
        {
            string maHD = FormHelper.Gia(cboHopDong);
            var k = svc.LapPhieuGiaHan(txtMaPhieuGH.Text, maHD, (int)numThoiGianGiaHan.Value);

            if (FormHelper.Bao(k))
            {
                TaiDanhSach();
            }
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}