﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmNhanVienTheXe : Form
    {
        private readonly NhanVienTheXeService svc = new NhanVienTheXeService();

        public FrmNhanVienTheXe()
        {
            InitializeComponent();
        }

        private void FrmNhanVienTheXe_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboKhachHang, svc.LayDanhSachKhachHang(), "TenCongTy", "MaKH");
            FormHelper.Nap(cboPhong, svc.LayDanhSachPhong(), "HienThi", "MaPhong");
            cboLoaiXe.SelectedIndex = 0;

            TaiNhanVien();
            TaiTheXe();
        }

        private void TaiNhanVien()
        {
            dgvNhanVien.DataSource = svc.LayDanhSachNhanVien();
            FormHelper.Nap(cboNhanVien, svc.LayNhanVienChuaCoTheXe(), "HienThi", "MaNV");
        }

        private void TaiTheXe()
        {
            dgvTheXe.DataSource = svc.LayDanhSachTheXe();
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            var k = svc.ThemNhanVien(txtMaNV.Text, FormHelper.Gia(cboKhachHang), FormHelper.Gia(cboPhong),
                                     txtHoTen.Text, txtChucVu.Text, txtSoDienThoai.Text);
            if (FormHelper.Bao(k)) TaiNhanVien();
        }

        private void btnCapTheXe_Click(object sender, EventArgs e)
        {
            var k = svc.CapTheXe(txtMaTheXe.Text, FormHelper.Gia(cboNhanVien), txtBienSoXe.Text, cboLoaiXe.Text);
            if (FormHelper.Bao(k))
            {
                TaiTheXe();
                TaiNhanVien();
            }
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}