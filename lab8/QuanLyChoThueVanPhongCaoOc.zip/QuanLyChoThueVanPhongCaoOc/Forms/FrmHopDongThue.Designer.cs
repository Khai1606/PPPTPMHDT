﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmHopDongThue
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpKhachHang = new System.Windows.Forms.GroupBox();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblTenCongTy = new System.Windows.Forms.Label();
            this.txtTenCongTy = new System.Windows.Forms.TextBox();
            this.lblSoDienThoai = new System.Windows.Forms.Label();
            this.txtSoDienThoai = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblMaSoThue = new System.Windows.Forms.Label();
            this.txtMaSoThue = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.grpHopDong = new System.Windows.Forms.GroupBox();
            this.lblMaHopDong = new System.Windows.Forms.Label();
            this.txtMaHopDong = new System.Windows.Forms.TextBox();
            this.lblNgayBatDau = new System.Windows.Forms.Label();
            this.dtNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.lblThoiHanThue = new System.Windows.Forms.Label();
            this.numThoiHanThue = new System.Windows.Forms.NumericUpDown();
            this.lblTienCoc = new System.Windows.Forms.Label();
            this.numTienCoc = new System.Windows.Forms.NumericUpDown();
            this.lblPhongTrong = new System.Windows.Forms.Label();
            this.clbPhongTrong = new System.Windows.Forms.CheckedListBox();
            this.btnKyHopDong = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.grpKhachHang.SuspendLayout();
            this.grpHopDong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHanThue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTienCoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            this.SuspendLayout();
            // 
            // grpKhachHang
            // 
            this.grpKhachHang.Controls.Add(this.txtDiaChi);
            this.grpKhachHang.Controls.Add(this.lblDiaChi);
            this.grpKhachHang.Controls.Add(this.txtMaSoThue);
            this.grpKhachHang.Controls.Add(this.lblMaSoThue);
            this.grpKhachHang.Controls.Add(this.txtEmail);
            this.grpKhachHang.Controls.Add(this.lblEmail);
            this.grpKhachHang.Controls.Add(this.txtSoDienThoai);
            this.grpKhachHang.Controls.Add(this.lblSoDienThoai);
            this.grpKhachHang.Controls.Add(this.txtTenCongTy);
            this.grpKhachHang.Controls.Add(this.lblTenCongTy);
            this.grpKhachHang.Controls.Add(this.txtMaKH);
            this.grpKhachHang.Controls.Add(this.lblMaKH);
            this.grpKhachHang.Location = new System.Drawing.Point(12, 12);
            this.grpKhachHang.Name = "grpKhachHang";
            this.grpKhachHang.Size = new System.Drawing.Size(760, 110);
            this.grpKhachHang.TabIndex = 0;
            this.grpKhachHang.TabStop = false;
            this.grpKhachHang.Text = "Thông tin Khách hàng / Công ty";
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Location = new System.Drawing.Point(15, 25);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(43, 13);
            this.lblMaKH.Text = "Mã KH:";
            // 
            // txtMaKH
            // 
            this.txtMaKH.Location = new System.Drawing.Point(85, 22);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(150, 20);
            this.txtMaKH.TabIndex = 1;
            // 
            // lblTenCongTy
            // 
            this.lblTenCongTy.AutoSize = true;
            this.lblTenCongTy.Location = new System.Drawing.Point(260, 25);
            this.lblTenCongTy.Name = "lblTenCongTy";
            this.lblTenCongTy.Size = new System.Drawing.Size(67, 13);
            this.lblTenCongTy.Text = "Tên Cty/KH:";
            // 
            // txtTenCongTy
            // 
            this.txtTenCongTy.Location = new System.Drawing.Point(335, 22);
            this.txtTenCongTy.Name = "txtTenCongTy";
            this.txtTenCongTy.Size = new System.Drawing.Size(405, 20);
            this.txtTenCongTy.TabIndex = 3;
            // 
            // lblSoDienThoai
            // 
            this.lblSoDienThoai.AutoSize = true;
            this.lblSoDienThoai.Location = new System.Drawing.Point(15, 53);
            this.lblSoDienThoai.Name = "lblSoDienThoai";
            this.lblSoDienThoai.Size = new System.Drawing.Size(31, 13);
            this.lblSoDienThoai.Text = "SĐT:";
            // 
            // txtSoDienThoai
            // 
            this.txtSoDienThoai.Location = new System.Drawing.Point(85, 50);
            this.txtSoDienThoai.Name = "txtSoDienThoai";
            this.txtSoDienThoai.Size = new System.Drawing.Size(150, 20);
            this.txtSoDienThoai.TabIndex = 5;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(260, 53);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.Text = "Email:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(335, 50);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(180, 20);
            this.txtEmail.TabIndex = 7;
            // 
            // lblMaSoThue
            // 
            this.lblMaSoThue.AutoSize = true;
            this.lblMaSoThue.Location = new System.Drawing.Point(530, 53);
            this.lblMaSoThue.Name = "lblMaSoThue";
            this.lblMaSoThue.Size = new System.Drawing.Size(33, 13);
            this.lblMaSoThue.Text = "MST:";
            // 
            // txtMaSoThue
            // 
            this.txtMaSoThue.Location = new System.Drawing.Point(570, 50);
            this.txtMaSoThue.Name = "txtMaSoThue";
            this.txtMaSoThue.Size = new System.Drawing.Size(170, 20);
            this.txtMaSoThue.TabIndex = 9;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 81);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(43, 13);
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(85, 78);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(655, 20);
            this.txtDiaChi.TabIndex = 11;
            // 
            // grpHopDong
            // 
            this.grpHopDong.Controls.Add(this.clbPhongTrong);
            this.grpHopDong.Controls.Add(this.lblPhongTrong);
            this.grpHopDong.Controls.Add(this.numTienCoc);
            this.grpHopDong.Controls.Add(this.lblTienCoc);
            this.grpHopDong.Controls.Add(this.numThoiHanThue);
            this.grpHopDong.Controls.Add(this.lblThoiHanThue);
            this.grpHopDong.Controls.Add(this.dtNgayBatDau);
            this.grpHopDong.Controls.Add(this.lblNgayBatDau);
            this.grpHopDong.Controls.Add(this.txtMaHopDong);
            this.grpHopDong.Controls.Add(this.lblMaHopDong);
            this.grpHopDong.Location = new System.Drawing.Point(12, 130);
            this.grpHopDong.Name = "grpHopDong";
            this.grpHopDong.Size = new System.Drawing.Size(760, 160);
            this.grpHopDong.TabIndex = 1;
            this.grpHopDong.TabStop = false;
            this.grpHopDong.Text = "Thông tin Hợp đồng & Chọn phòng";
            // 
            // lblMaHopDong
            // 
            this.lblMaHopDong.AutoSize = true;
            this.lblMaHopDong.Location = new System.Drawing.Point(15, 25);
            this.lblMaHopDong.Name = "lblMaHopDong";
            this.lblMaHopDong.Size = new System.Drawing.Size(44, 13);
            this.lblMaHopDong.Text = "Mã HĐ:";
            // 
            // txtMaHopDong
            // 
            this.txtMaHopDong.Location = new System.Drawing.Point(85, 22);
            this.txtMaHopDong.Name = "txtMaHopDong";
            this.txtMaHopDong.Size = new System.Drawing.Size(150, 20);
            this.txtMaHopDong.TabIndex = 1;
            // 
            // lblNgayBatDau
            // 
            this.lblNgayBatDau.AutoSize = true;
            this.lblNgayBatDau.Location = new System.Drawing.Point(260, 25);
            this.lblNgayBatDau.Name = "lblNgayBatDau";
            this.lblNgayBatDau.Size = new System.Drawing.Size(75, 13);
            this.lblNgayBatDau.Text = "Ngày bắt đầu:";
            // 
            // dtNgayBatDau
            // 
            this.dtNgayBatDau.CustomFormat = "dd/MM/yyyy";
            this.dtNgayBatDau.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayBatDau.Location = new System.Drawing.Point(340, 22);
            this.dtNgayBatDau.Name = "dtNgayBatDau";
            this.dtNgayBatDau.Size = new System.Drawing.Size(120, 20);
            this.dtNgayBatDau.TabIndex = 3;
            // 
            // lblThoiHanThue
            // 
            this.lblThoiHanThue.AutoSize = true;
            this.lblThoiHanThue.Location = new System.Drawing.Point(15, 55);
            this.lblThoiHanThue.Name = "lblThoiHanThue";
            this.lblThoiHanThue.Size = new System.Drawing.Size(73, 13);
            this.lblThoiHanThue.Text = "Thời hạn (T):";
            // 
            // numThoiHanThue
            // 
            this.numThoiHanThue.Location = new System.Drawing.Point(85, 53);
            this.numThoiHanThue.Minimum = new decimal(new int[] { 6, 0, 0, 0 });
            this.numThoiHanThue.Name = "numThoiHanThue";
            this.numThoiHanThue.Size = new System.Drawing.Size(150, 20);
            this.numThoiHanThue.TabIndex = 5;
            this.numThoiHanThue.Value = new decimal(new int[] { 12, 0, 0, 0 });
            // 
            // lblTienCoc
            // 
            this.lblTienCoc.AutoSize = true;
            this.lblTienCoc.Location = new System.Drawing.Point(260, 55);
            this.lblTienCoc.Name = "lblTienCoc";
            this.lblTienCoc.Size = new System.Drawing.Size(52, 13);
            this.lblTienCoc.Text = "Tiền cọc:";
            // 
            // numTienCoc
            // 
            this.numTienCoc.ThousandsSeparator = true;
            this.numTienCoc.Location = new System.Drawing.Point(340, 53);
            this.numTienCoc.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numTienCoc.Name = "numTienCoc";
            this.numTienCoc.Size = new System.Drawing.Size(150, 20);
            this.numTienCoc.TabIndex = 7;
            // 
            // lblPhongTrong
            // 
            this.lblPhongTrong.AutoSize = true;
            this.lblPhongTrong.Location = new System.Drawing.Point(15, 85);
            this.lblPhongTrong.Name = "lblPhongTrong";
            this.lblPhongTrong.Size = new System.Drawing.Size(68, 13);
            this.lblPhongTrong.Text = "Chọn phòng:";
            // 
            // clbPhongTrong
            // 
            this.clbPhongTrong.FormattingEnabled = true;
            this.clbPhongTrong.Location = new System.Drawing.Point(85, 85);
            this.clbPhongTrong.Name = "clbPhongTrong";
            this.clbPhongTrong.Size = new System.Drawing.Size(655, 64);
            this.clbPhongTrong.TabIndex = 9;
            // 
            // btnKyHopDong
            // 
            this.btnKyHopDong.Location = new System.Drawing.Point(12, 298);
            this.btnKyHopDong.Name = "btnKyHopDong";
            this.btnKyHopDong.Size = new System.Drawing.Size(223, 30);
            this.btnKyHopDong.TabIndex = 2;
            this.btnKyHopDong.Text = "Ký Hợp Đồng && Thu Tiền 6 Tháng";
            this.btnKyHopDong.UseVisualStyleBackColor = true;
            this.btnKyHopDong.Click += new System.EventHandler(this.btnKyHopDong_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(697, 298);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 30);
            this.btnDong.TabIndex = 3;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.AllowUserToAddRows = false;
            this.dgvHopDong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Location = new System.Drawing.Point(12, 335);
            this.dgvHopDong.MultiSelect = false;
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.ReadOnly = true;
            this.dgvHopDong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHopDong.Size = new System.Drawing.Size(760, 215);
            this.dgvHopDong.TabIndex = 4;
            // 
            // FrmHopDongThue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.dgvHopDong);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnKyHopDong);
            this.Controls.Add(this.grpHopDong);
            this.Controls.Add(this.grpKhachHang);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmHopDongThue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Lập & Ký Hợp Đồng Thuê Văn Phòng";
            this.Load += new System.EventHandler(this.FrmHopDongThue_Load);
            this.grpKhachHang.ResumeLayout(false);
            this.grpKhachHang.PerformLayout();
            this.grpHopDong.ResumeLayout(false);
            this.grpHopDong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHanThue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTienCoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpKhachHang;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.Label lblTenCongTy;
        private System.Windows.Forms.TextBox txtTenCongTy;
        private System.Windows.Forms.Label lblSoDienThoai;
        private System.Windows.Forms.TextBox txtSoDienThoai;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblMaSoThue;
        private System.Windows.Forms.TextBox txtMaSoThue;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.GroupBox grpHopDong;
        private System.Windows.Forms.Label lblMaHopDong;
        private System.Windows.Forms.TextBox txtMaHopDong;
        private System.Windows.Forms.Label lblNgayBatDau;
        private System.Windows.Forms.DateTimePicker dtNgayBatDau;
        private System.Windows.Forms.Label lblThoiHanThue;
        private System.Windows.Forms.NumericUpDown numThoiHanThue;
        private System.Windows.Forms.Label lblTienCoc;
        private System.Windows.Forms.NumericUpDown numTienCoc;
        private System.Windows.Forms.Label lblPhongTrong;
        private System.Windows.Forms.CheckedListBox clbPhongTrong;
        private System.Windows.Forms.Button btnKyHopDong;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.DataGridView dgvHopDong;
    }
}