﻿using System;
using System.Windows.Forms;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void MoForm(Form f)
        {
            using (f) f.ShowDialog(this);
        }

        private void btnPhongTang_Click(object sender, EventArgs e) { MoForm(new FrmPhongTang()); }
        private void btnHopDongThue_Click(object sender, EventArgs e) { MoForm(new FrmHopDongThue()); }
        private void btnPhieuGiaHan_Click(object sender, EventArgs e) { MoForm(new FrmPhieuGiaHan()); }
        private void btnThanhToanThue_Click(object sender, EventArgs e) { MoForm(new FrmThanhToanThue()); }
        private void btnHoaDonDichVu_Click(object sender, EventArgs e) { MoForm(new FrmHoaDonDichVu()); }
        private void btnNhanVienTheXe_Click(object sender, EventArgs e) { MoForm(new FrmNhanVienTheXe()); }
        private void btnKiemTraBaoTri_Click(object sender, EventArgs e) { MoForm(new FrmKiemTraBaoTri()); }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát ứng dụng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}