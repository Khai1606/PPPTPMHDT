﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmThanhToanThue : Form
    {
        private readonly HoaDonThueService svc = new HoaDonThueService();

        public FrmThanhToanThue()
        {
            InitializeComponent();
        }

        private void FrmThanhToanThue_Load(object sender, EventArgs e)
        {
            txtThangNam.Text = DateTime.Today.ToString("MM/yyyy");
            FormHelper.Nap(cboHopDong, svc.LayHopDongThue(), "HienThi", "MaHopDong");
            TaiDanhSach();
        }

        private void TaiDanhSach()
        {
            dgvHoaDon.DataSource = svc.LayDanhSachHoaDon();
        }

        private void cboHopDong_SelectedIndexChanged(object sender, EventArgs e)
        {
            var row = cboHopDong.SelectedItem as DataRowView;
            if (row != null && row["TongTienThang"] != DBNull.Value)
            {
                numSoTien.Value = Convert.ToDecimal(row["TongTienThang"]);
            }
        }

        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string maHD = FormHelper.Gia(cboHopDong);
            var k = svc.LapHoaDonThue(txtMaHDThue.Text, maHD, txtThangNam.Text, numSoTien.Value);
            if (FormHelper.Bao(k)) TaiDanhSach();
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string maHDThue = FormHelper.O(dgvHoaDon, "MaHDThue");
            if (string.IsNullOrEmpty(maHDThue))
            {
                MessageBox.Show("Vui lòng chọn hóa đơn cần thanh toán từ danh sách bên dưới.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var k = svc.XacNhanThanhToan(maHDThue);
            if (FormHelper.Bao(k)) TaiDanhSach();
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}