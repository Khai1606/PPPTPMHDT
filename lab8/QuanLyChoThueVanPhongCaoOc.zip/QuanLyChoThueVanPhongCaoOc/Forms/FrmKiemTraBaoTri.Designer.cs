﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmKiemTraBaoTri
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblMaPhieuKT = new System.Windows.Forms.Label();
            this.txtMaPhieuKT = new System.Windows.Forms.TextBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblNgayKiemTra = new System.Windows.Forms.Label();
            this.dtNgayKiemTra = new System.Windows.Forms.DateTimePicker();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.txtTinhTrang = new System.Windows.Forms.TextBox();
            this.chkCoViPham = new System.Windows.Forms.CheckBox();
            this.lblTienPhat = new System.Windows.Forms.Label();
            this.numTienPhat = new System.Windows.Forms.NumericUpDown();
            this.btnLapBienBan = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvKiemTra = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numTienPhat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKiemTra)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaPhieuKT
            // 
            this.lblMaPhieuKT.AutoSize = true;
            this.lblMaPhieuKT.Location = new System.Drawing.Point(15, 20);
            this.lblMaPhieuKT.Name = "lblMaPhieuKT";
            this.lblMaPhieuKT.Size = new System.Drawing.Size(71, 13);
            this.lblMaPhieuKT.Text = "Mã Phiếu KT:";
            // 
            // txtMaPhieuKT
            // 
            this.txtMaPhieuKT.Location = new System.Drawing.Point(95, 17);
            this.txtMaPhieuKT.Name = "txtMaPhieuKT";
            this.txtMaPhieuKT.Size = new System.Drawing.Size(120, 20);
            this.txtMaPhieuKT.TabIndex = 1;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(235, 20);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(41, 13);
            this.lblPhong.Text = "Phòng:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(280, 17);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(150, 21);
            this.cboPhong.TabIndex = 3;
            // 
            // lblNgayKiemTra
            // 
            this.lblNgayKiemTra.AutoSize = true;
            this.lblNgayKiemTra.Location = new System.Drawing.Point(450, 20);
            this.lblNgayKiemTra.Name = "lblNgayKiemTra";
            this.lblNgayKiemTra.Size = new System.Drawing.Size(51, 13);
            this.lblNgayKiemTra.Text = "Ngày KT:";
            // 
            // dtNgayKiemTra
            // 
            this.dtNgayKiemTra.CustomFormat = "dd/MM/yyyy";
            this.dtNgayKiemTra.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayKiemTra.Location = new System.Drawing.Point(510, 17);
            this.dtNgayKiemTra.Name = "dtNgayKiemTra";
            this.dtNgayKiemTra.Size = new System.Drawing.Size(110, 20);
            this.dtNgayKiemTra.TabIndex = 5;
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.Location = new System.Drawing.Point(15, 55);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(58, 13);
            this.lblTinhTrang.Text = "Tình trạng:";
            // 
            // txtTinhTrang
            // 
            this.txtTinhTrang.Location = new System.Drawing.Point(95, 52);
            this.txtTinhTrang.Name = "txtTinhTrang";
            this.txtTinhTrang.Size = new System.Drawing.Size(525, 20);
            this.txtTinhTrang.TabIndex = 7;
            // 
            // chkCoViPham
            // 
            this.chkCoViPham.AutoSize = true;
            this.chkCoViPham.Location = new System.Drawing.Point(15, 90);
            this.chkCoViPham.Name = "chkCoViPham";
            this.chkCoViPham.Size = new System.Drawing.Size(223, 17);
            this.chkCoViPham.TabIndex = 8;
            this.chkCoViPham.Text = "Tự ý thay đổi, sửa chữa kết cấu phòng";
            this.chkCoViPham.UseVisualStyleBackColor = true;
            this.chkCoViPham.CheckedChanged += new System.EventHandler(this.chkCoViPham_CheckedChanged);
            // 
            // lblTienPhat
            // 
            this.lblTienPhat.AutoSize = true;
            this.lblTienPhat.Location = new System.Drawing.Point(260, 91);
            this.lblTienPhat.Name = "lblTienPhat";
            this.lblTienPhat.Size = new System.Drawing.Size(55, 13);
            this.lblTienPhat.Text = "Tiền phạt:";
            // 
            // numTienPhat
            // 
            this.numTienPhat.Location = new System.Drawing.Point(320, 89);
            this.numTienPhat.Maximum = new decimal(new int[] { 500000000, 0, 0, 0 });
            this.numTienPhat.Name = "numTienPhat";
            this.numTienPhat.Size = new System.Drawing.Size(130, 20);
            this.numTienPhat.TabIndex = 10;
            this.numTienPhat.ThousandsSeparator = true;
            // 
            // btnLapBienBan
            // 
            this.btnLapBienBan.Location = new System.Drawing.Point(470, 85);
            this.btnLapBienBan.Name = "btnLapBienBan";
            this.btnLapBienBan.Size = new System.Drawing.Size(150, 26);
            this.btnLapBienBan.TabIndex = 11;
            this.btnLapBienBan.Text = "Lập Biên Bản Kiểm Tra";
            this.btnLapBienBan.UseVisualStyleBackColor = true;
            this.btnLapBienBan.Click += new System.EventHandler(this.btnLapBienBan_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(545, 370);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 25);
            this.btnDong.TabIndex = 12;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvKiemTra
            // 
            this.dgvKiemTra.AllowUserToAddRows = false;
            this.dgvKiemTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKiemTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKiemTra.Location = new System.Drawing.Point(15, 125);
            this.dgvKiemTra.MultiSelect = false;
            this.dgvKiemTra.Name = "dgvKiemTra";
            this.dgvKiemTra.ReadOnly = true;
            this.dgvKiemTra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKiemTra.Size = new System.Drawing.Size(605, 230);
            this.dgvKiemTra.TabIndex = 13;
            // 
            // FrmKiemTraBaoTri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 405);
            this.Controls.Add(this.dgvKiemTra);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLapBienBan);
            this.Controls.Add(this.numTienPhat);
            this.Controls.Add(this.lblTienPhat);
            this.Controls.Add(this.chkCoViPham);
            this.Controls.Add(this.txtTinhTrang);
            this.Controls.Add(this.lblTinhTrang);
            this.Controls.Add(this.dtNgayKiemTra);
            this.Controls.Add(this.lblNgayKiemTra);
            this.Controls.Add(this.cboPhong);
            this.Controls.Add(this.lblPhong);
            this.Controls.Add(this.txtMaPhieuKT);
            this.Controls.Add(this.lblMaPhieuKT);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmKiemTraBaoTri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Kiểm Tra Định Kỳ & Xử Lý Vi Phạm Kết Cấu";
            this.Load += new System.EventHandler(this.FrmKiemTraBaoTri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTienPhat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKiemTra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaPhieuKT;
        private System.Windows.Forms.TextBox txtMaPhieuKT;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblNgayKiemTra;
        private System.Windows.Forms.DateTimePicker dtNgayKiemTra;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.TextBox txtTinhTrang;
        private System.Windows.Forms.CheckBox chkCoViPham;
        private System.Windows.Forms.Label lblTienPhat;
        private System.Windows.Forms.NumericUpDown numTienPhat;
        private System.Windows.Forms.Button btnLapBienBan;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.DataGridView dgvKiemTra;
    }
}