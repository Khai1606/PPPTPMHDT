﻿using System;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Services;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmKiemTraBaoTri : Form
    {
        private readonly KiemTraBaoTriService svc = new KiemTraBaoTriService();

        public FrmKiemTraBaoTri()
        {
            InitializeComponent();
        }

        private void FrmKiemTraBaoTri_Load(object sender, EventArgs e)
        {
            dtNgayKiemTra.Value = DateTime.Today;
            FormHelper.Nap(cboPhong, svc.LayDanhSachPhong(), "HienThi", "MaPhong");
            numTienPhat.Enabled = false;
            TaiDanhSach();
        }

        private void TaiDanhSach()
        {
            dgvKiemTra.DataSource = svc.LayDanhSachKiemTra();
        }

        private void chkCoViPham_CheckedChanged(object sender, EventArgs e)
        {
            numTienPhat.Enabled = chkCoViPham.Checked;
            if (!chkCoViPham.Checked) numTienPhat.Value = 0;
        }

        private void btnLapBienBan_Click(object sender, EventArgs e)
        {
            var k = svc.LapPhieuKiemTra(txtMaPhieuKT.Text, FormHelper.Gia(cboPhong),
                                       dtNgayKiemTra.Value, txtTinhTrang.Text,
                                       chkCoViPham.Checked, numTienPhat.Value);
            if (FormHelper.Bao(k)) TaiDanhSach();
        }

        private void btnDong_Click(object sender, EventArgs e) { Close(); }
    }
}