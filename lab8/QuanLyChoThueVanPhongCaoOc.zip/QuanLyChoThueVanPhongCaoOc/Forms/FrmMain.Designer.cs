﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnPhongTang = new System.Windows.Forms.Button();
            this.btnHopDongThue = new System.Windows.Forms.Button();
            this.btnPhieuGiaHan = new System.Windows.Forms.Button();
            this.btnThanhToanThue = new System.Windows.Forms.Button();
            this.btnHoaDonDichVu = new System.Windows.Forms.Button();
            this.btnNhanVienTheXe = new System.Windows.Forms.Button();
            this.btnKiemTraBaoTri = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.Navy;
            this.lblTieuDe.Location = new System.Drawing.Point(75, 25);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(480, 26);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ CHO THUÊ CAO ỐC";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPhongTang
            // 
            this.btnPhongTang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhongTang.Location = new System.Drawing.Point(50, 80);
            this.btnPhongTang.Name = "btnPhongTang";
            this.btnPhongTang.Size = new System.Drawing.Size(240, 50);
            this.btnPhongTang.TabIndex = 1;
            this.btnPhongTang.Text = "Quản Lý Tầng & Phòng";
            this.btnPhongTang.UseVisualStyleBackColor = true;
            this.btnPhongTang.Click += new System.EventHandler(this.btnPhongTang_Click);
            // 
            // btnHopDongThue
            // 
            this.btnHopDongThue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHopDongThue.Location = new System.Drawing.Point(330, 80);
            this.btnHopDongThue.Name = "btnHopDongThue";
            this.btnHopDongThue.Size = new System.Drawing.Size(240, 50);
            this.btnHopDongThue.TabIndex = 2;
            this.btnHopDongThue.Text = "Hợp Đồng Thuê Văn Phòng";
            this.btnHopDongThue.UseVisualStyleBackColor = true;
            this.btnHopDongThue.Click += new System.EventHandler(this.btnHopDongThue_Click);
            // 
            // btnPhieuGiaHan
            // 
            this.btnPhieuGiaHan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhieuGiaHan.Location = new System.Drawing.Point(50, 150);
            this.btnPhieuGiaHan.Name = "btnPhieuGiaHan";
            this.btnPhieuGiaHan.Size = new System.Drawing.Size(240, 50);
            this.btnPhieuGiaHan.TabIndex = 3;
            this.btnPhieuGiaHan.Text = "Lập Phiếu Gia Hạn";
            this.btnPhieuGiaHan.UseVisualStyleBackColor = true;
            this.btnPhieuGiaHan.Click += new System.EventHandler(this.btnPhieuGiaHan_Click);
            // 
            // btnThanhToanThue
            // 
            this.btnThanhToanThue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToanThue.Location = new System.Drawing.Point(330, 150);
            this.btnThanhToanThue.Name = "btnThanhToanThue";
            this.btnThanhToanThue.Size = new System.Drawing.Size(240, 50);
            this.btnThanhToanThue.TabIndex = 4;
            this.btnThanhToanThue.Text = "Thu Tiền Thuê Hàng Tháng";
            this.btnThanhToanThue.UseVisualStyleBackColor = true;
            this.btnThanhToanThue.Click += new System.EventHandler(this.btnThanhToanThue_Click);
            // 
            // btnHoaDonDichVu
            // 
            this.btnHoaDonDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoaDonDichVu.Location = new System.Drawing.Point(50, 220);
            this.btnHoaDonDichVu.Name = "btnHoaDonDichVu";
            this.btnHoaDonDichVu.Size = new System.Drawing.Size(240, 50);
            this.btnHoaDonDichVu.TabIndex = 5;
            this.btnHoaDonDichVu.Text = "Hóa Đơn Chi Phí Dịch Vụ";
            this.btnHoaDonDichVu.UseVisualStyleBackColor = true;
            this.btnHoaDonDichVu.Click += new System.EventHandler(this.btnHoaDonDichVu_Click);
            // 
            // btnNhanVienTheXe
            // 
            this.btnNhanVienTheXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhanVienTheXe.Location = new System.Drawing.Point(330, 220);
            this.btnNhanVienTheXe.Name = "btnNhanVienTheXe";
            this.btnNhanVienTheXe.Size = new System.Drawing.Size(240, 50);
            this.btnNhanVienTheXe.TabIndex = 6;
            this.btnNhanVienTheXe.Text = "Nhân Viên & Thẻ Giữ Xe";
            this.btnNhanVienTheXe.UseVisualStyleBackColor = true;
            this.btnNhanVienTheXe.Click += new System.EventHandler(this.btnNhanVienTheXe_Click);
            // 
            // btnKiemTraBaoTri
            // 
            this.btnKiemTraBaoTri.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiemTraBaoTri.Location = new System.Drawing.Point(50, 290);
            this.btnKiemTraBaoTri.Name = "btnKiemTraBaoTri";
            this.btnKiemTraBaoTri.Size = new System.Drawing.Size(240, 50);
            this.btnKiemTraBaoTri.TabIndex = 7;
            this.btnKiemTraBaoTri.Text = "Kiểm Tra & Xử Lý Vi Phạm";
            this.btnKiemTraBaoTri.UseVisualStyleBackColor = true;
            this.btnKiemTraBaoTri.Click += new System.EventHandler(this.btnKiemTraBaoTri_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(330, 290);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(240, 50);
            this.btnThoat.TabIndex = 8;
            this.btnThoat.Text = "Thoát Ứng Dụng";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 375);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnKiemTraBaoTri);
            this.Controls.Add(this.btnNhanVienTheXe);
            this.Controls.Add(this.btnHoaDonDichVu);
            this.Controls.Add(this.btnThanhToanThue);
            this.Controls.Add(this.btnPhieuGiaHan);
            this.Controls.Add(this.btnHopDongThue);
            this.Controls.Add(this.btnPhongTang);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang Chủ - Quản Lý Cho Thuê Văn Phòng Cao Ốc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnPhongTang;
        private System.Windows.Forms.Button btnHopDongThue;
        private System.Windows.Forms.Button btnPhieuGiaHan;
        private System.Windows.Forms.Button btnThanhToanThue;
        private System.Windows.Forms.Button btnHoaDonDichVu;
        private System.Windows.Forms.Button btnNhanVienTheXe;
        private System.Windows.Forms.Button btnKiemTraBaoTri;
        private System.Windows.Forms.Button btnThoat;
    }
}