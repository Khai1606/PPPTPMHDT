﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmPhongTang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabPhongTang = new System.Windows.Forms.TabControl();
            this.tpTang = new System.Windows.Forms.TabPage();
            this.lblMaTang = new System.Windows.Forms.Label();
            this.txtMaTang = new System.Windows.Forms.TextBox();
            this.lblTenTang = new System.Windows.Forms.Label();
            this.txtTenTang = new System.Windows.Forms.TextBox();
            this.lblSoLuongPhong = new System.Windows.Forms.Label();
            this.numSoLuongPhong = new System.Windows.Forms.NumericUpDown();
            this.lblViTriDoCao = new System.Windows.Forms.Label();
            this.numViTriDoCao = new System.Windows.Forms.NumericUpDown();
            this.btnThemTang = new System.Windows.Forms.Button();
            this.dgvTang = new System.Windows.Forms.DataGridView();
            this.tpPhong = new System.Windows.Forms.TabPage();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.lblTang = new System.Windows.Forms.Label();
            this.cboTang = new System.Windows.Forms.ComboBox();
            this.lblHuongPhong = new System.Windows.Forms.Label();
            this.txtHuongPhong = new System.Windows.Forms.TextBox();
            this.lblDienTich = new System.Windows.Forms.Label();
            this.numDienTich = new System.Windows.Forms.NumericUpDown();
            this.lblDonGiaThue = new System.Windows.Forms.Label();
            this.numDonGiaThue = new System.Windows.Forms.NumericUpDown();
            this.btnThemPhong = new System.Windows.Forms.Button();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabPhongTang.SuspendLayout();
            this.tpTang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuongPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numViTriDoCao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTang)).BeginInit();
            this.tpPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDienTich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGiaThue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPhongTang
            // 
            this.tabPhongTang.Controls.Add(this.tpTang);
            this.tabPhongTang.Controls.Add(this.tpPhong);
            this.tabPhongTang.Location = new System.Drawing.Point(12, 12);
            this.tabPhongTang.Name = "tabPhongTang";
            this.tabPhongTang.SelectedIndex = 0;
            this.tabPhongTang.Size = new System.Drawing.Size(660, 380);
            this.tabPhongTang.TabIndex = 0;
            // 
            // tpTang
            // 
            this.tpTang.Controls.Add(this.dgvTang);
            this.tpTang.Controls.Add(this.btnThemTang);
            this.tpTang.Controls.Add(this.numViTriDoCao);
            this.tpTang.Controls.Add(this.lblViTriDoCao);
            this.tpTang.Controls.Add(this.numSoLuongPhong);
            this.tpTang.Controls.Add(this.lblSoLuongPhong);
            this.tpTang.Controls.Add(this.txtTenTang);
            this.tpTang.Controls.Add(this.lblTenTang);
            this.tpTang.Controls.Add(this.txtMaTang);
            this.tpTang.Controls.Add(this.lblMaTang);
            this.tpTang.Location = new System.Drawing.Point(4, 22);
            this.tpTang.Name = "tpTang";
            this.tpTang.Padding = new System.Windows.Forms.Padding(3);
            this.tpTang.Size = new System.Drawing.Size(652, 354);
            this.tpTang.TabIndex = 0;
            this.tpTang.Text = "Danh Mục Tầng";
            this.tpTang.UseVisualStyleBackColor = true;
            // 
            // lblMaTang
            // 
            this.lblMaTang.AutoSize = true;
            this.lblMaTang.Location = new System.Drawing.Point(15, 18);
            this.lblMaTang.Name = "lblMaTang";
            this.lblMaTang.Size = new System.Drawing.Size(49, 13);
            this.lblMaTang.Text = "Mã tầng:";
            // 
            // txtMaTang
            // 
            this.txtMaTang.Location = new System.Drawing.Point(85, 15);
            this.txtMaTang.Name = "txtMaTang";
            this.txtMaTang.Size = new System.Drawing.Size(120, 20);
            this.txtMaTang.TabIndex = 1;
            // 
            // lblTenTang
            // 
            this.lblTenTang.AutoSize = true;
            this.lblTenTang.Location = new System.Drawing.Point(230, 18);
            this.lblTenTang.Name = "lblTenTang";
            this.lblTenTang.Size = new System.Drawing.Size(53, 13);
            this.lblTenTang.Text = "Tên tầng:";
            // 
            // txtTenTang
            // 
            this.txtTenTang.Location = new System.Drawing.Point(295, 15);
            this.txtTenTang.Name = "txtTenTang";
            this.txtTenTang.Size = new System.Drawing.Size(180, 20);
            this.txtTenTang.TabIndex = 3;
            // 
            // lblSoLuongPhong
            // 
            this.lblSoLuongPhong.AutoSize = true;
            this.lblSoLuongPhong.Location = new System.Drawing.Point(15, 53);
            this.lblSoLuongPhong.Name = "lblSoLuongPhong";
            this.lblSoLuongPhong.Size = new System.Drawing.Size(56, 13);
            this.lblSoLuongPhong.Text = "Số phòng:";
            // 
            // numSoLuongPhong
            // 
            this.numSoLuongPhong.Location = new System.Drawing.Point(85, 50);
            this.numSoLuongPhong.Name = "numSoLuongPhong";
            this.numSoLuongPhong.Size = new System.Drawing.Size(120, 20);
            this.numSoLuongPhong.TabIndex = 5;
            this.numSoLuongPhong.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // lblViTriDoCao
            // 
            this.lblViTriDoCao.AutoSize = true;
            this.lblViTriDoCao.Location = new System.Drawing.Point(230, 53);
            this.lblViTriDoCao.Name = "lblViTriDoCao";
            this.lblViTriDoCao.Size = new System.Drawing.Size(62, 13);
            this.lblViTriDoCao.Text = "Độ cao (m):";
            // 
            // numViTriDoCao
            // 
            this.numViTriDoCao.DecimalPlaces = 1;
            this.numViTriDoCao.Location = new System.Drawing.Point(295, 50);
            this.numViTriDoCao.Name = "numViTriDoCao";
            this.numViTriDoCao.Size = new System.Drawing.Size(180, 20);
            this.numViTriDoCao.TabIndex = 7;
            // 
            // btnThemTang
            // 
            this.btnThemTang.Location = new System.Drawing.Point(510, 48);
            this.btnThemTang.Name = "btnThemTang";
            this.btnThemTang.Size = new System.Drawing.Size(120, 25);
            this.btnThemTang.TabIndex = 8;
            this.btnThemTang.Text = "Thêm Tầng";
            this.btnThemTang.UseVisualStyleBackColor = true;
            this.btnThemTang.Click += new System.EventHandler(this.btnThemTang_Click);
            // 
            // dgvTang
            // 
            this.dgvTang.AllowUserToAddRows = false;
            this.dgvTang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTang.Location = new System.Drawing.Point(15, 90);
            this.dgvTang.MultiSelect = false;
            this.dgvTang.Name = "dgvTang";
            this.dgvTang.ReadOnly = true;
            this.dgvTang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTang.Size = new System.Drawing.Size(615, 250);
            this.dgvTang.TabIndex = 9;
            // 
            // tpPhong
            // 
            this.tpPhong.Controls.Add(this.dgvPhong);
            this.tpPhong.Controls.Add(this.btnThemPhong);
            this.tpPhong.Controls.Add(this.numDonGiaThue);
            this.tpPhong.Controls.Add(this.lblDonGiaThue);
            this.tpPhong.Controls.Add(this.numDienTich);
            this.tpPhong.Controls.Add(this.lblDienTich);
            this.tpPhong.Controls.Add(this.txtHuongPhong);
            this.tpPhong.Controls.Add(this.lblHuongPhong);
            this.tpPhong.Controls.Add(this.cboTang);
            this.tpPhong.Controls.Add(this.lblTang);
            this.tpPhong.Controls.Add(this.txtMaPhong);
            this.tpPhong.Controls.Add(this.lblMaPhong);
            this.tpPhong.Location = new System.Drawing.Point(4, 22);
            this.tpPhong.Name = "tpPhong";
            this.tpPhong.Padding = new System.Windows.Forms.Padding(3);
            this.tpPhong.Size = new System.Drawing.Size(652, 354);
            this.tpPhong.TabIndex = 1;
            this.tpPhong.Text = "Danh Mục Phòng Văn Phòng";
            this.tpPhong.UseVisualStyleBackColor = true;
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(15, 18);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(58, 13);
            this.lblMaPhong.Text = "Mã phòng:";
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(85, 15);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(120, 20);
            this.txtMaPhong.TabIndex = 1;
            // 
            // lblTang
            // 
            this.lblTang.AutoSize = true;
            this.lblTang.Location = new System.Drawing.Point(230, 18);
            this.lblTang.Name = "lblTang";
            this.lblTang.Size = new System.Drawing.Size(35, 13);
            this.lblTang.Text = "Tầng:";
            // 
            // cboTang
            // 
            this.cboTang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTang.FormattingEnabled = true;
            this.cboTang.Location = new System.Drawing.Point(280, 15);
            this.cboTang.Name = "cboTang";
            this.cboTang.Size = new System.Drawing.Size(150, 21);
            this.cboTang.TabIndex = 3;
            // 
            // lblHuongPhong
            // 
            this.lblHuongPhong.AutoSize = true;
            this.lblHuongPhong.Location = new System.Drawing.Point(450, 18);
            this.lblHuongPhong.Name = "lblHuongPhong";
            this.lblHuongPhong.Size = new System.Drawing.Size(42, 13);
            this.lblHuongPhong.Text = "Hướng:";
            // 
            // txtHuongPhong
            // 
            this.txtHuongPhong.Location = new System.Drawing.Point(500, 15);
            this.txtHuongPhong.Name = "txtHuongPhong";
            this.txtHuongPhong.Size = new System.Drawing.Size(130, 20);
            this.txtHuongPhong.TabIndex = 5;
            // 
            // lblDienTich
            // 
            this.lblDienTich.AutoSize = true;
            this.lblDienTich.Location = new System.Drawing.Point(15, 53);
            this.lblDienTich.Name = "lblDienTich";
            this.lblDienTich.Size = new System.Drawing.Size(58, 13);
            this.lblDienTich.Text = "Diện tích:";
            // 
            // numDienTich
            // 
            this.numDienTich.DecimalPlaces = 1;
            this.numDienTich.Location = new System.Drawing.Point(85, 50);
            this.numDienTich.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numDienTich.Name = "numDienTich";
            this.numDienTich.Size = new System.Drawing.Size(120, 20);
            this.numDienTich.TabIndex = 7;
            this.numDienTich.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // lblDonGiaThue
            // 
            this.lblDonGiaThue.AutoSize = true;
            this.lblDonGiaThue.Location = new System.Drawing.Point(230, 53);
            this.lblDonGiaThue.Name = "lblDonGiaThue";
            this.lblDonGiaThue.Size = new System.Drawing.Size(47, 13);
            this.lblDonGiaThue.Text = "Đơn giá:";
            // 
            // numDonGiaThue
            // 
            this.numDonGiaThue.Location = new System.Drawing.Point(280, 50);
            this.numDonGiaThue.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numDonGiaThue.Name = "numDonGiaThue";
            this.numDonGiaThue.Size = new System.Drawing.Size(150, 20);
            this.numDonGiaThue.TabIndex = 9;
            this.numDonGiaThue.ThousandsSeparator = true;
            // 
            // btnThemPhong
            // 
            this.btnThemPhong.Location = new System.Drawing.Point(500, 48);
            this.btnThemPhong.Name = "btnThemPhong";
            this.btnThemPhong.Size = new System.Drawing.Size(130, 25);
            this.btnThemPhong.TabIndex = 10;
            this.btnThemPhong.Text = "Thêm Phòng";
            this.btnThemPhong.UseVisualStyleBackColor = true;
            this.btnThemPhong.Click += new System.EventHandler(this.btnThemPhong_Click);
            // 
            // dgvPhong
            // 
            this.dgvPhong.AllowUserToAddRows = false;
            this.dgvPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(15, 90);
            this.dgvPhong.MultiSelect = false;
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.ReadOnly = true;
            this.dgvPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhong.Size = new System.Drawing.Size(615, 250);
            this.dgvPhong.TabIndex = 11;
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(597, 400);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 25);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmPhongTang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 436);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabPhongTang);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPhongTang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản Lý Danh Mục Tầng & Phòng Văn Phòng";
            this.Load += new System.EventHandler(this.FrmPhongTang_Load);
            this.tabPhongTang.ResumeLayout(false);
            this.tpTang.ResumeLayout(false);
            this.tpTang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuongPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numViTriDoCao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTang)).EndInit();
            this.tpPhong.ResumeLayout(false);
            this.tpPhong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDienTich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGiaThue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabPhongTang;
        private System.Windows.Forms.TabPage tpTang;
        private System.Windows.Forms.TabPage tpPhong;
        private System.Windows.Forms.Label lblMaTang;
        private System.Windows.Forms.TextBox txtMaTang;
        private System.Windows.Forms.Label lblTenTang;
        private System.Windows.Forms.TextBox txtTenTang;
        private System.Windows.Forms.Label lblSoLuongPhong;
        private System.Windows.Forms.NumericUpDown numSoLuongPhong;
        private System.Windows.Forms.Label lblViTriDoCao;
        private System.Windows.Forms.NumericUpDown numViTriDoCao;
        private System.Windows.Forms.Button btnThemTang;
        private System.Windows.Forms.DataGridView dgvTang;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.Label lblTang;
        private System.Windows.Forms.ComboBox cboTang;
        private System.Windows.Forms.Label lblHuongPhong;
        private System.Windows.Forms.TextBox txtHuongPhong;
        private System.Windows.Forms.Label lblDienTich;
        private System.Windows.Forms.NumericUpDown numDienTich;
        private System.Windows.Forms.Label lblDonGiaThue;
        private System.Windows.Forms.NumericUpDown numDonGiaThue;
        private System.Windows.Forms.Button btnThemPhong;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.Button btnDong;
    }
}