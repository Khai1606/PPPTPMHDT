﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmThanhToanThue
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblMaHDThue = new System.Windows.Forms.Label();
            this.txtMaHDThue = new System.Windows.Forms.TextBox();
            this.lblHopDong = new System.Windows.Forms.Label();
            this.cboHopDong = new System.Windows.Forms.ComboBox();
            this.lblThangNam = new System.Windows.Forms.Label();
            this.txtThangNam = new System.Windows.Forms.TextBox();
            this.lblSoTien = new System.Windows.Forms.Label();
            this.numSoTien = new System.Windows.Forms.NumericUpDown();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaHDThue
            // 
            this.lblMaHDThue.AutoSize = true;
            this.lblMaHDThue.Location = new System.Drawing.Point(15, 20);
            this.lblMaHDThue.Name = "lblMaHDThue";
            this.lblMaHDThue.Size = new System.Drawing.Size(71, 13);
            this.lblMaHDThue.Text = "Mã HD Thúe:";
            // 
            // txtMaHDThue
            // 
            this.txtMaHDThue.Location = new System.Drawing.Point(95, 17);
            this.txtMaHDThue.Name = "txtMaHDThue";
            this.txtMaHDThue.Size = new System.Drawing.Size(130, 20);
            this.txtMaHDThue.TabIndex = 1;
            // 
            // lblHopDong
            // 
            this.lblHopDong.AutoSize = true;
            this.lblHopDong.Location = new System.Drawing.Point(245, 20);
            this.lblHopDong.Name = "lblHopDong";
            this.lblHopDong.Size = new System.Drawing.Size(58, 13);
            this.lblHopDong.Text = "Hợp đồng:";
            // 
            // cboHopDong
            // 
            this.cboHopDong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHopDong.FormattingEnabled = true;
            this.cboHopDong.Location = new System.Drawing.Point(310, 17);
            this.cboHopDong.Name = "cboHopDong";
            this.cboHopDong.Size = new System.Drawing.Size(320, 21);
            this.cboHopDong.TabIndex = 3;
            this.cboHopDong.SelectedIndexChanged += new System.EventHandler(this.cboHopDong_SelectedIndexChanged);
            // 
            // lblThangNam
            // 
            this.lblThangNam.AutoSize = true;
            this.lblThangNam.Location = new System.Drawing.Point(15, 55);
            this.lblThangNam.Name = "lblThangNam";
            this.lblThangNam.Size = new System.Drawing.Size(65, 13);
            this.lblThangNam.Text = "Tháng/Năm:";
            // 
            // txtThangNam
            // 
            this.txtThangNam.Location = new System.Drawing.Point(95, 52);
            this.txtThangNam.Name = "txtThangNam";
            this.txtThangNam.Size = new System.Drawing.Size(130, 20);
            this.txtThangNam.TabIndex = 5;
            // 
            // lblSoTien
            // 
            this.lblSoTien.AutoSize = true;
            this.lblSoTien.Location = new System.Drawing.Point(245, 55);
            this.lblSoTien.Name = "lblSoTien";
            this.lblSoTien.Size = new System.Drawing.Size(43, 13);
            this.lblSoTien.Text = "Số tiền:";
            // 
            // numSoTien
            // 
            this.numSoTien.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numSoTien.Name = "numSoTien";
            this.numSoTien.Size = new System.Drawing.Size(160, 20);
            this.numSoTien.TabIndex = 7;
            this.numSoTien.ThousandsSeparator = true;
            this.numSoTien.Location = new System.Drawing.Point(310, 52);
            // 
            // btnLapHoaDon
            // 
            this.btnLapHoaDon.Location = new System.Drawing.Point(15, 90);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(120, 28);
            this.btnLapHoaDon.TabIndex = 8;
            this.btnLapHoaDon.Text = "Lập Hóa Đơn Thuê";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;
            this.btnLapHoaDon.Click += new System.EventHandler(this.btnLapHoaDon_Click);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Location = new System.Drawing.Point(145, 90);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(130, 28);
            this.btnThanhToan.TabIndex = 9;
            this.btnThanhToan.Text = "Xác Nhận Thanh Toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(555, 90);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 28);
            this.btnDong.TabIndex = 10;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.AllowUserToAddRows = false;
            this.dgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(15, 130);
            this.dgvHoaDon.MultiSelect = false;
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.ReadOnly = true;
            this.dgvHoaDon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoaDon.Size = new System.Drawing.Size(615, 260);
            this.dgvHoaDon.TabIndex = 11;
            // 
            // FrmThanhToanThue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 405);
            this.Controls.Add(this.dgvHoaDon);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.numSoTien);
            this.Controls.Add(this.lblSoTien);
            this.Controls.Add(this.txtThangNam);
            this.Controls.Add(this.lblThangNam);
            this.Controls.Add(this.cboHopDong);
            this.Controls.Add(this.lblHopDong);
            this.Controls.Add(this.txtMaHDThue);
            this.Controls.Add(this.lblMaHDThue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmThanhToanThue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản Lý & Thu Tiền Thuê Văn Phòng Hàng Tháng";
            this.Load += new System.EventHandler(this.FrmThanhToanThue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numSoTien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaHDThue;
        private System.Windows.Forms.TextBox txtMaHDThue;
        private System.Windows.Forms.Label lblHopDong;
        private System.Windows.Forms.ComboBox cboHopDong;
        private System.Windows.Forms.Label lblThangNam;
        private System.Windows.Forms.TextBox txtThangNam;
        private System.Windows.Forms.Label lblSoTien;
        private System.Windows.Forms.NumericUpDown numSoTien;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.DataGridView dgvHoaDon;
    }
}