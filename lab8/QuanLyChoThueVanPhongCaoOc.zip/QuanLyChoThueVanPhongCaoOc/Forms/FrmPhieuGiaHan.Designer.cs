﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmPhieuGiaHan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblMaPhieuGH = new System.Windows.Forms.Label();
            this.txtMaPhieuGH = new System.Windows.Forms.TextBox();
            this.lblHopDong = new System.Windows.Forms.Label();
            this.cboHopDong = new System.Windows.Forms.ComboBox();
            this.lblThoiGianGiaHan = new System.Windows.Forms.Label();
            this.numThoiGianGiaHan = new System.Windows.Forms.NumericUpDown();
            this.btnLapPhieuGiaHan = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvPhieuGiaHan = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianGiaHan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuGiaHan)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaPhieuGH
            // 
            this.lblMaPhieuGH.AutoSize = true;
            this.lblMaPhieuGH.Location = new System.Drawing.Point(15, 20);
            this.lblMaPhieuGH.Name = "lblMaPhieuGH";
            this.lblMaPhieuGH.Size = new System.Drawing.Size(73, 13);
            this.lblMaPhieuGH.Text = "Mã Phiếu GH:";
            // 
            // txtMaPhieuGH
            // 
            this.txtMaPhieuGH.Location = new System.Drawing.Point(110, 17);
            this.txtMaPhieuGH.Name = "txtMaPhieuGH";
            this.txtMaPhieuGH.Size = new System.Drawing.Size(150, 20);
            this.txtMaPhieuGH.TabIndex = 1;
            // 
            // lblHopDong
            // 
            this.lblHopDong.AutoSize = true;
            this.lblHopDong.Location = new System.Drawing.Point(280, 20);
            this.lblHopDong.Name = "lblHopDong";
            this.lblHopDong.Size = new System.Drawing.Size(58, 13);
            this.lblHopDong.Text = "Hợp đồng:";
            // 
            // cboHopDong
            // 
            this.cboHopDong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHopDong.FormattingEnabled = true;
            this.cboHopDong.Location = new System.Drawing.Point(345, 17);
            this.cboHopDong.Name = "cboHopDong";
            this.cboHopDong.Size = new System.Drawing.Size(260, 21);
            this.cboHopDong.TabIndex = 3;
            // 
            // lblThoiGianGiaHan
            // 
            this.lblThoiGianGiaHan.AutoSize = true;
            this.lblThoiGianGiaHan.Location = new System.Drawing.Point(15, 55);
            this.lblThoiGianGiaHan.Name = "lblThoiGianGiaHan";
            this.lblThoiGianGiaHan.Size = new System.Drawing.Size(92, 13);
            this.lblThoiGianGiaHan.Text = "Thời gian GH (T):";
            // 
            // numThoiGianGiaHan
            // 
            this.numThoiGianGiaHan.Location = new System.Drawing.Point(110, 53);
            this.numThoiGianGiaHan.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThoiGianGiaHan.Name = "numThoiGianGiaHan";
            this.numThoiGianGiaHan.Size = new System.Drawing.Size(150, 20);
            this.numThoiGianGiaHan.TabIndex = 5;
            this.numThoiGianGiaHan.Value = new decimal(new int[] { 6, 0, 0, 0 });
            // 
            // btnLapPhieuGiaHan
            // 
            this.btnLapPhieuGiaHan.Location = new System.Drawing.Point(345, 50);
            this.btnLapPhieuGiaHan.Name = "btnLapPhieuGiaHan";
            this.btnLapPhieuGiaHan.Size = new System.Drawing.Size(130, 25);
            this.btnLapPhieuGiaHan.TabIndex = 6;
            this.btnLapPhieuGiaHan.Text = "Lập Phiếu Gia Hạn";
            this.btnLapPhieuGiaHan.UseVisualStyleBackColor = true;
            this.btnLapPhieuGiaHan.Click += new System.EventHandler(this.btnLapPhieuGiaHan_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(530, 50);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(75, 25);
            this.btnDong.TabIndex = 7;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvPhieuGiaHan
            // 
            this.dgvPhieuGiaHan.AllowUserToAddRows = false;
            this.dgvPhieuGiaHan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuGiaHan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuGiaHan.Location = new System.Drawing.Point(12, 90);
            this.dgvPhieuGiaHan.MultiSelect = false;
            this.dgvPhieuGiaHan.Name = "dgvPhieuGiaHan";
            this.dgvPhieuGiaHan.ReadOnly = true;
            this.dgvPhieuGiaHan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuGiaHan.Size = new System.Drawing.Size(593, 260);
            this.dgvPhieuGiaHan.TabIndex = 8;
            // 
            // FrmPhieuGiaHan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 362);
            this.Controls.Add(this.dgvPhieuGiaHan);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLapPhieuGiaHan);
            this.Controls.Add(this.numThoiGianGiaHan);
            this.Controls.Add(this.lblThoiGianGiaHan);
            this.Controls.Add(this.cboHopDong);
            this.Controls.Add(this.lblHopDong);
            this.Controls.Add(this.txtMaPhieuGH);
            this.Controls.Add(this.lblMaPhieuGH);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPhieuGiaHan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Lập Phiếu Gia Hạn Hợp Đồng Thuê";
            this.Load += new System.EventHandler(this.FrmPhieuGiaHan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianGiaHan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuGiaHan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaPhieuGH;
        private System.Windows.Forms.TextBox txtMaPhieuGH;
        private System.Windows.Forms.Label lblHopDong;
        private System.Windows.Forms.ComboBox cboHopDong;
        private System.Windows.Forms.Label lblThoiGianGiaHan;
        private System.Windows.Forms.NumericUpDown numThoiGianGiaHan;
        private System.Windows.Forms.Button btnLapPhieuGiaHan;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.DataGridView dgvPhieuGiaHan;
    }
}