﻿using System;
using System.Data;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class PhongTangService
    {
        public DataTable LayDanhSachTang()
        {
            return Db.Query("SELECT MaTang, TenTang, SoLuongPhong, ViTriDoCao FROM Tang ORDER BY MaTang");
        }

        public DataTable LayDanhSachPhong()
        {
            return Db.Query(@"SELECT p.MaPhong, t.TenTang, p.HuongPhong, p.DienTich, p.DonGiaThue, p.TrangThai 
                              FROM Phong p 
                              JOIN Tang t ON p.MaTang = t.MaTang 
                              ORDER BY p.MaPhong");
        }

        public KetQuaXuLy ThemTang(string maTang, string tenTang, int soLuongPhong, double viTriDoCao)
        {
            if (string.IsNullOrWhiteSpace(maTang) || string.IsNullOrWhiteSpace(tenTang))
                return KetQuaXuLy.Fail("Mã tầng và tên tầng không được để trống.");

            try
            {
                Db.Execute(@"INSERT INTO Tang(MaTang, TenTang, SoLuongPhong, ViTriDoCao) 
                             VALUES(@m, @t, @sl, @dc)",
                    Db.P("@m", maTang), Db.P("@t", tenTang), Db.P("@sl", soLuongPhong), Db.P("@dc", viTriDoCao));

                return KetQuaXuLy.Ok("Thêm tầng mới thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy ThemPhong(string maPhong, string maTang, string huongPhong, double dienTich, decimal donGiaThue)
        {
            if (string.IsNullOrWhiteSpace(maPhong) || string.IsNullOrWhiteSpace(maTang))
                return KetQuaXuLy.Fail("Mã phòng và tầng chọn không được để trống.");

            try
            {
                Db.Execute(@"INSERT INTO Phong(MaPhong, MaTang, HuongPhong, DienTich, DonGiaThue, TrangThai) 
                             VALUES(@p, @t, @h, @dt, @g, @st)",
                    Db.P("@p", maPhong), Db.P("@t", maTang), Db.P("@h", huongPhong),
                    Db.P("@dt", dienTich), Db.P("@g", donGiaThue), Db.P("@st", QuyDinh.TrangThaiPhongTrong));

                return KetQuaXuLy.Ok("Thêm phòng mới thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}