﻿using System;
using System.Data;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class KiemTraBaoTriService
    {
        public DataTable LayDanhSachPhong()
        {
            return Db.Query("SELECT MaPhong, MaPhong + ' - ' + HuongPhong AS HienThi FROM Phong ORDER BY MaPhong");
        }

        public DataTable LayDanhSachKiemTra()
        {
            return Db.Query(@"SELECT pk.MaPhieuKT, pk.MaPhong, pk.NgayKiemTra, pk.TinhTrangPhong, 
                                     CASE WHEN pk.CoViPhamKetCau = 1 THEN N'Có vi phạm' ELSE N'Không' END AS ViPham, 
                                     pk.TienPhat 
                              FROM PhieuKiemTra pk 
                              ORDER BY pk.NgayKiemTra DESC");
        }

        public KetQuaXuLy LapPhieuKiemTra(string maPhieuKT, string maPhong, DateTime ngayKT, string tinhTrang, bool coViPham, decimal tienPhat)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKT) || string.IsNullOrWhiteSpace(maPhong) || string.IsNullOrWhiteSpace(tinhTrang))
                return KetQuaXuLy.Fail("Mã phiếu, phòng và tình trạng phòng không được để trống.");

            try
            {
                // Kiểm tra chu kỳ kiểm tra định kỳ 1 năm/lần
                object objNgayKTCu = Db.Scalar("SELECT TOP 1 NgayKiemTra FROM PhieuKiemTra WHERE MaPhong = @p ORDER BY NgayKiemTra DESC", Db.P("@p", maPhong));
                if (objNgayKTCu != null && objNgayKTCu != DBNull.Value)
                {
                    DateTime ngayKTCu = Convert.ToDateTime(objNgayKTCu);
                    if ((ngayKT - ngayKTCu).TotalDays < 365)
                    {
                        return KetQuaXuLy.Fail("Phòng " + maPhong + " đã được kiểm tra vào ngày " + ngayKTCu.ToString("dd/MM/yyyy") + ". Chu kỳ kiểm tra định kỳ là 1 năm/lần.");
                    }
                }

                Db.Execute(@"INSERT INTO PhieuKiemTra(MaPhieuKT, MaPhong, NgayKiemTra, TinhTrangPhong, CoViPhamKetCau, TienPhat) 
                             VALUES(@p, @mp, @ngay, @tt, @vp, @phat)",
                    Db.P("@p", maPhieuKT), Db.P("@mp", maPhong), Db.P("@ngay", ngayKT.Date),
                    Db.P("@tt", tinhTrang), Db.P("@vp", coViPham ? 1 : 0), Db.P("@phat", coViPham ? tienPhat : 0));

                return KetQuaXuLy.Ok("Lập biên bản kiểm tra bảo trì thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}