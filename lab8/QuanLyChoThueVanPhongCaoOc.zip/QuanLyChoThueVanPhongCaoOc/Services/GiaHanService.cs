﻿using System;
using System.Data;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class GiaHanService
    {
        public DataTable LayDanhSach()
        {
            return Db.Query(@"SELECT p.MaPhieuGH, p.MaHopDong, k.TenCongTy, p.NgayLap, p.ThoiGianGiaHan, p.TrangThaiDuyet 
                              FROM PhieuGiaHan p 
                              JOIN HopDongThue h ON p.MaHopDong = h.MaHopDong 
                              JOIN KhachHang k ON h.MaKH = k.MaKH 
                              ORDER BY p.NgayLap DESC");
        }

        public DataTable LayHopDongHieuLuc()
        {
            return Db.Query(@"SELECT h.MaHopDong, h.MaHopDong + ' - ' + k.TenCongTy AS HienThi, h.ThoiHanThue 
                              FROM HopDongThue h 
                              JOIN KhachHang k ON h.MaKH = k.MaKH 
                              WHERE h.TrangThai = @tt", Db.P("@tt", QuyDinh.TrangThaiHDDangHieuLuc));
        }

        public KetQuaXuLy LapPhieuGiaHan(string maPhieuGH, string maHopDong, int thoiGianGiaHan)
        {
            if (string.IsNullOrWhiteSpace(maPhieuGH) || string.IsNullOrWhiteSpace(maHopDong) || thoiGianGiaHan <= 0)
                return KetQuaXuLy.Fail("Thông tin phiếu gia hạn không hợp lệ.");

            try
            {
                // 1. Kiểm tra công nợ tiền thuê mặt bằng
                int noTienThue = Convert.ToInt32(Db.Scalar(
                    "SELECT COUNT(*) FROM HoaDonTienThue WHERE MaHopDong = @hd AND TrangThaiThanhToan = 0",
                    Db.P("@hd", maHopDong)));
                if (noTienThue > 0)
                    return KetQuaXuLy.Fail("Hợp đồng còn nợ tiền thuê mặt bằng, không thể lập phiếu gia hạn.");

                // 2. Kiểm tra công nợ chi phí dịch vụ (điện, nước, internet)
                int noTienDV = Convert.ToInt32(Db.Scalar(
                    @"SELECT COUNT(*) FROM HoaDonDichVu hd 
                      JOIN ChiTietHopDong ct ON hd.MaPhong = ct.MaPhong 
                      WHERE ct.MaHopDong = @hd AND hd.TrangThaiThanhToan = 0",
                    Db.P("@hd", maHopDong)));
                if (noTienDV > 0)
                    return KetQuaXuLy.Fail("Hợp đồng còn nợ chi phí dịch vụ, không thể lập phiếu gia hạn.");

                // 3. Kiểm tra điều kiện thời gian gia hạn <= 1/2 thời hạn hợp đồng ban đầu
                object objThoiHanGoc = Db.Scalar("SELECT ThoiHanThue FROM HopDongThue WHERE MaHopDong = @hd", Db.P("@hd", maHopDong));
                if (objThoiHanGoc == null) return KetQuaXuLy.Fail("Hợp đồng không tồn tại.");

                int thoiHanGoc = Convert.ToInt32(objThoiHanGoc);
                if (thoiGianGiaHan > (thoiHanGoc / 2))
                {
                    return KetQuaXuLy.Fail(string.Format("Thời gian gia hạn ({0} tháng) vượt quá 1/2 thời hạn hợp đồng ban đầu (tối đa {1} tháng).",
                        thoiGianGiaHan, thoiHanGoc / 2));
                }

                // 4. Ghi nhận phiếu gia hạn
                Db.Execute(@"INSERT INTO PhieuGiaHan(MaPhieuGH, MaHopDong, NgayLap, ThoiGianGiaHan, TrangThaiDuyet) 
                             VALUES(@p, @hd, SYSDATETIME(), @tg, 1)",
                    Db.P("@p", maPhieuGH), Db.P("@hd", maHopDong), Db.P("@tg", thoiGianGiaHan));

                return KetQuaXuLy.Ok("Lập phiếu gia hạn thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}