﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class HopDongThueService
    {
        public DataTable LayDanhSach()
        {
            return Db.Query(@"SELECT h.MaHopDong, k.TenCongTy, h.NgayLap, h.NgayBatDau, 
                                     h.ThoiHanThue, h.TienCoc, h.TrangThai 
                              FROM HopDongThue h 
                              JOIN KhachHang k ON h.MaKH = k.MaKH 
                              ORDER BY h.NgayLap DESC");
        }

        public DataTable LayPhongTrong()
        {
            return Db.Query("SELECT MaPhong, MaPhong + ' - ' + HuongPhong + ' (' + CAST(DienTich AS varchar) + 'm2)' AS HienThi, DonGiaThue FROM Phong WHERE TrangThai = @tt",
                Db.P("@tt", QuyDinh.TrangThaiPhongTrong));
        }

        public KetQuaXuLy KyHopDong(string maHD, string maKH, string tenCty, string sdt, string email,
                                   string mst, string diaChi, DateTime ngayBatDau, int thoiHanThue,
                                   decimal tienCoc, List<string> dsMaPhong)
        {
            if (string.IsNullOrWhiteSpace(maHD) || string.IsNullOrWhiteSpace(maKH) || string.IsNullOrWhiteSpace(tenCty) || dsMaPhong == null || dsMaPhong.Count == 0)
                return KetQuaXuLy.Fail("Thông tin hợp đồng hoặc danh sách phòng chưa đầy đủ.");

            if (thoiHanThue < QuyDinh.ThoiHanThueToiThieu)
                return KetQuaXuLy.Fail("Thời hạn thuê tối thiểu là 6 tháng.");

            if (tienCoc <= 0)
                return KetQuaXuLy.Fail("Hợp đồng phải có tiền đặt cọc.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // 1. Thêm/Cập nhật thông tin Khách hàng
                    Exec(cn, tr, @"IF EXISTS(SELECT 1 FROM KhachHang WHERE MaKH = @m)
                                       UPDATE KhachHang SET TenCongTy = @t, SoDienThoai = @p, Email = @e, MaSoThue = @mst, DiaChi = @dc WHERE MaKH = @m
                                   ELSE 
                                       INSERT INTO KhachHang(MaKH, TenCongTy, SoDienThoai, Email, MaSoThue, DiaChi) VALUES(@m, @t, @p, @e, @mst, @dc)",
                        Db.P("@m", maKH), Db.P("@t", tenCty), Db.P("@p", sdt), Db.P("@e", email), Db.P("@mst", mst), Db.P("@dc", diaChi));

                    // 2. Lập Hợp đồng thuê
                    Exec(cn, tr, @"INSERT INTO HopDongThue(MaHopDong, MaKH, NgayLap, NgayBatDau, ThoiHanThue, TienCoc, TrangThai)
                                   VALUES(@hd, @kh, SYSDATETIME(), @bd, @th, @coc, @tt)",
                        Db.P("@hd", maHD), Db.P("@kh", maKH), Db.P("@bd", ngayBatDau.Date), Db.P("@th", thoiHanThue), Db.P("@coc", tienCoc), Db.P("@tt", QuyDinh.TrangThaiHDDangHieuLuc));

                    decimal tongTien6Thang = 0;

                    // 3. Lập Chi tiết hợp đồng & Đổi trạng thái Phòng sang "Đã thuê"
                    foreach (var maPhong in dsMaPhong)
                    {
                        object objGia = Scalar(cn, tr, "SELECT DonGiaThue FROM Phong WHERE MaPhong = @p AND TrangThai = @tt",
                            Db.P("@p", maPhong), Db.P("@tt", QuyDinh.TrangThaiPhongTrong));

                        if (objGia == null)
                        {
                            tr.Rollback();
                            return KetQuaXuLy.Fail("Phòng " + maPhong + " không tồn tại hoặc đã được thuê.");
                        }

                        decimal donGia = Convert.ToDecimal(objGia);
                        tongTien6Thang += donGia * QuyDinh.SoThangTraTruocDauKy;

                        string maCTHD = "CT_" + maHD + "_" + maPhong;
                        Exec(cn, tr, "INSERT INTO ChiTietHopDong(MaCTHD, MaHopDong, MaPhong, DonGiaApDung) VALUES(@ct, @hd, @p, @g)",
                            Db.P("@ct", maCTHD), Db.P("@hd", maHD), Db.P("@p", maPhong), Db.P("@g", donGia));

                        Exec(cn, tr, "UPDATE Phong SET TrangThai = @tt WHERE MaPhong = @p",
                            Db.P("@tt", QuyDinh.TrangThaiPhongDaThue), Db.P("@p", maPhong));
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Ký hợp đồng thành công! Tiền thuê 6 tháng đầu đã thu: " + tongTien6Thang.ToString("N0") + " VNĐ.");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        private static void Exec(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr)) { cmd.Parameters.AddRange(ps); cmd.ExecuteNonQuery(); }
        }

        private static object Scalar(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr)) { cmd.Parameters.AddRange(ps); return cmd.ExecuteScalar(); }
        }
    }
}