﻿using System;

namespace QuanLyChoThueCaoOc.Services
{
    /// <summary>
    /// Kết quả trả về của mọi phương thức Service; Form chỉ đọc ThanhCong và ThongBao.
    /// </summary>
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; private set; }
        public string ThongBao { get; private set; }

        public static KetQuaXuLy Ok(string thongBao)
        {
            return new KetQuaXuLy { ThanhCong = true, ThongBao = thongBao };
        }

        public static KetQuaXuLy Fail(string thongBao)
        {
            return new KetQuaXuLy { ThanhCong = false, ThongBao = thongBao };
        }
    }

    /// <summary>
    /// Hằng số quy định nghiệp vụ bài Quản lý cao ốc văn phòng.
    /// </summary>
    public static class QuyDinh
    {
        public const int ThoiHanThueToiThieu = 6;  // Hợp đồng tối thiểu 6 tháng
        public const int SoThangTraTruocDauKy = 6; // Bắt buộc đóng trước 6 tháng khi ký HD
        public const string TrangThaiPhongTrong = "Trống";
        public const string TrangThaiPhongDaThue = "Đã thuê";
        public const string TrangThaiHDDangHieuLuc = "Đang hiệu lực";
    }
}