﻿using System;
using System.Data;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class NhanVienTheXeService
    {
        public DataTable LayDanhSachKhachHang()
        {
            return Db.Query("SELECT MaKH, TenCongTy FROM KhachHang ORDER BY TenCongTy");
        }

        public DataTable LayDanhSachPhong()
        {
            return Db.Query("SELECT MaPhong, MaPhong + ' - ' + HuongPhong AS HienThi FROM Phong WHERE TrangThai = @tt",
                Db.P("@tt", QuyDinh.TrangThaiPhongDaThue));
        }

        public DataTable LayDanhSachNhanVien()
        {
            return Db.Query(@"SELECT nv.MaNV, k.TenCongTy, nv.MaPhong, nv.HoTen, nv.ChucVu, nv.SoDienThoai 
                              FROM NhanVienCongTy nv 
                              JOIN KhachHang k ON nv.MaKH = k.MaKH 
                              ORDER BY nv.HoTen");
        }

        public DataTable LayNhanVienChuaCoTheXe()
        {
            return Db.Query(@"SELECT nv.MaNV, nv.MaNV + ' - ' + nv.HoTen AS HienThi 
                              FROM NhanVienCongTy nv 
                              WHERE NOT EXISTS (SELECT 1 FROM TheXe tx WHERE tx.MaNV = nv.MaNV) 
                              ORDER BY nv.HoTen");
        }

        public DataTable LayDanhSachTheXe()
        {
            return Db.Query(@"SELECT tx.MaTheXe, nv.HoTen, k.TenCongTy, tx.BienSoXe, tx.LoaiXe, tx.NgayCap 
                              FROM TheXe tx 
                              JOIN NhanVienCongTy nv ON tx.MaNV = nv.MaNV 
                              JOIN KhachHang k ON nv.MaKH = k.MaKH 
                              ORDER BY tx.NgayCap DESC");
        }

        public KetQuaXuLy ThemNhanVien(string maNV, string maKH, string maPhong, string hoTen, string chucVu, string sdt)
        {
            if (string.IsNullOrWhiteSpace(maNV) || string.IsNullOrWhiteSpace(maKH) || string.IsNullOrWhiteSpace(hoTen))
                return KetQuaXuLy.Fail("Mã NV, Công ty và Họ tên không được để trống.");

            try
            {
                Db.Execute(@"INSERT INTO NhanVienCongTy(MaNV, MaKH, MaPhong, HoTen, ChucVu, SoDienThoai) 
                             VALUES(@m, @kh, @p, @ht, @cv, @sdt)",
                    Db.P("@m", maNV), Db.P("@kh", maKH), Db.P("@p", maPhong), Db.P("@ht", hoTen), Db.P("@cv", chucVu), Db.P("@sdt", sdt));

                return KetQuaXuLy.Ok("Thêm nhân viên thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy CapTheXe(string maTheXe, string maNV, string bienSoXe, string loaiXe)
        {
            if (string.IsNullOrWhiteSpace(maTheXe) || string.IsNullOrWhiteSpace(maNV) || string.IsNullOrWhiteSpace(bienSoXe))
                return KetQuaXuLy.Fail("Thông tin cấp thẻ xe không được để trống.");

            try
            {
                int tonTaiNV = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM TheXe WHERE MaNV = @nv", Db.P("@nv", maNV)));
                if (tonTaiNV > 0)
                    return KetQuaXuLy.Fail("Mỗi nhân viên chỉ được cấp tối đa 1 thẻ xe.");

                Db.Execute(@"INSERT INTO TheXe(MaTheXe, MaNV, BienSoXe, LoaiXe, NgayCap) 
                             VALUES(@tx, @nv, @bs, @lx, CAST(GETDATE() AS date))",
                    Db.P("@tx", maTheXe), Db.P("@nv", maNV), Db.P("@bs", bienSoXe), Db.P("@lx", loaiXe));

                return KetQuaXuLy.Ok("Cấp thẻ xe thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}