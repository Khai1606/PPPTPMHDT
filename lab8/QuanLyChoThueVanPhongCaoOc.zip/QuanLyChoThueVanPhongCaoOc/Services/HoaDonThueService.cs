﻿using System;
using System.Data;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class HoaDonThueService
    {
        public DataTable LayDanhSachHoaDon()
        {
            return Db.Query(@"SELECT h.MaHDThue, h.MaHopDong, k.TenCongTy, h.ThangNam, h.NgayLap, h.SoTien, 
                                     CASE WHEN h.TrangThaiThanhToan = 1 THEN N'Đã thanh toán' ELSE N'Chưa thanh toán' END AS TrangThai
                              FROM HoaDonTienThue h
                              JOIN HopDongThue hd ON h.MaHopDong = hd.MaHopDong
                              JOIN KhachHang k ON hd.MaKH = k.MaKH
                              ORDER BY h.NgayLap DESC");
        }

        public DataTable LayHopDongThue()
        {
            return Db.Query(@"SELECT hd.MaHopDong, hd.MaHopDong + ' - ' + k.TenCongTy AS HienThi,
                                     ISNULL(SUM(ct.DonGiaApDung), 0) AS TongTienThang
                              FROM HopDongThue hd
                              JOIN KhachHang k ON hd.MaKH = k.MaKH
                              JOIN ChiTietHopDong ct ON hd.MaHopDong = ct.MaHopDong
                              WHERE hd.TrangThai = @tt
                              GROUP BY hd.MaHopDong, k.TenCongTy", Db.P("@tt", QuyDinh.TrangThaiHDDangHieuLuc));
        }

        public KetQuaXuLy LapHoaDonThue(string maHDThue, string maHopDong, string thangNam, decimal soTien)
        {
            if (string.IsNullOrWhiteSpace(maHDThue) || string.IsNullOrWhiteSpace(maHopDong) || string.IsNullOrWhiteSpace(thangNam) || soTien <= 0)
                return KetQuaXuLy.Fail("Thông tin hóa đơn tiền thuê không hợp lệ.");

            try
            {
                int tonTai = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM HoaDonTienThue WHERE MaHopDong = @hd AND ThangNam = @tn",
                    Db.P("@hd", maHopDong), Db.P("@tn", thangNam)));
                if (tonTai > 0)
                    return KetQuaXuLy.Fail("Hợp đồng này đã được phát hành hóa đơn tiền thuê cho tháng " + thangNam + ".");

                Db.Execute(@"INSERT INTO HoaDonTienThue(MaHDThue, MaHopDong, ThangNam, NgayLap, SoTien, TrangThaiThanhToan)
                             VALUES(@m, @hd, @tn, CAST(GETDATE() AS date), @st, 0)",
                    Db.P("@m", maHDThue), Db.P("@hd", maHopDong), Db.P("@tn", thangNam), Db.P("@st", soTien));

                return KetQuaXuLy.Ok("Lập hóa đơn tiền thuê tháng " + thangNam + " thành công!");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy XacNhanThanhToan(string maHDThue)
        {
            if (string.IsNullOrWhiteSpace(maHDThue)) return KetQuaXuLy.Fail("Chưa chọn hóa đơn cần thanh toán.");

            try
            {
                int rows = Db.Execute("UPDATE HoaDonTienThue SET TrangThaiThanhToan = 1 WHERE MaHDThue = @m", Db.P("@m", maHDThue));
                return rows > 0 ? KetQuaXuLy.Ok("Xác nhận thanh toán hóa đơn " + maHDThue + " thành công!") : KetQuaXuLy.Fail("Không tìm thấy hóa đơn.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}