﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Services
{
    public class DichVuService
    {
        public DataTable LayDanhSachHoaDonDV()
        {
            return Db.Query(@"SELECT h.MaHoaDonDV, h.MaPhong, h.ThangNam, h.NgayLap, h.TongTienDV,
                                     CASE WHEN h.TrangThaiThanhToan = 1 THEN N'Đã thanh toán' ELSE N'Chưa thanh toán' END AS TrangThai
                              FROM HoaDonDichVu h
                              ORDER BY h.NgayLap DESC");
        }

        public DataTable LayPhongDaThue()
        {
            return Db.Query("SELECT MaPhong, MaPhong + ' - ' + HuongPhong AS HienThi FROM Phong WHERE TrangThai = @tt",
                Db.P("@tt", QuyDinh.TrangThaiPhongDaThue));
        }

        public KetQuaXuLy LapHoaDonDV(string maHDDV, string maPhong, string thangNam,
                                     decimal dienCu, decimal dienMoi,
                                     decimal nuocCu, decimal nuocMoi,
                                     decimal cuocInternet)
        {
            if (string.IsNullOrWhiteSpace(maHDDV) || string.IsNullOrWhiteSpace(maPhong) || string.IsNullOrWhiteSpace(thangNam))
                return KetQuaXuLy.Fail("Thông tin hóa đơn dịch vụ chưa đầy đủ.");

            if (dienMoi < dienCu || nuocMoi < nuocCu)
                return KetQuaXuLy.Fail("Chỉ số mới phải lớn hơn hoặc bằng chỉ số cũ.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    decimal donGiaDien = Convert.ToDecimal(Scalar(cn, tr, "SELECT DonGia FROM DichVu WHERE MaDichVu = 'DV01'"));
                    decimal donGiaNuoc = Convert.ToDecimal(Scalar(cn, tr, "SELECT DonGia FROM DichVu WHERE MaDichVu = 'DV02'"));

                    decimal tienDien = (dienMoi - dienCu) * donGiaDien;
                    decimal tienNuoc = (nuocMoi - nuocCu) * donGiaNuoc;
                    decimal tongTienDV = tienDien + tienNuoc + cuocInternet;

                    Exec(cn, tr, @"INSERT INTO HoaDonDichVu(MaHoaDonDV, MaPhong, ThangNam, NgayLap, TongTienDV, TrangThaiThanhToan)
                                   VALUES(@m, @p, @tn, CAST(GETDATE() AS date), @tt, 0)",
                        Db.P("@m", maHDDV), Db.P("@p", maPhong), Db.P("@tn", thangNam), Db.P("@tt", tongTienDV));

                    Exec(cn, tr, @"INSERT INTO ChiTietHoaDonDV(MaCTHDDV, MaHoaDonDV, MaDichVu, ChiSoCu, ChiSoMoi, ThanhTien)
                                   VALUES(@ct, @m, 'DV01', @cu, @moi, @tt)",
                        Db.P("@ct", maHDDV + "_DV01"), Db.P("@m", maHDDV), Db.P("@cu", dienCu), Db.P("@moi", dienMoi), Db.P("@tt", tienDien));

                    Exec(cn, tr, @"INSERT INTO ChiTietHoaDonDV(MaCTHDDV, MaHoaDonDV, MaDichVu, ChiSoCu, ChiSoMoi, ThanhTien)
                                   VALUES(@ct, @m, 'DV02', @cu, @moi, @tt)",
                        Db.P("@ct", maHDDV + "_DV02"), Db.P("@m", maHDDV), Db.P("@cu", nuocCu), Db.P("@moi", nuocMoi), Db.P("@tt", tienNuoc));

                    if (cuocInternet > 0)
                    {
                        Exec(cn, tr, @"INSERT INTO ChiTietHoaDonDV(MaCTHDDV, MaHoaDonDV, MaDichVu, ChiSoCu, ChiSoMoi, ThanhTien)
                                       VALUES(@ct, @m, 'DV03', 1, 1, @tt)",
                            Db.P("@ct", maHDDV + "_DV03"), Db.P("@m", maHDDV), Db.P("@tt", cuocInternet));
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Lập hóa đơn dịch vụ cho phòng " + maPhong + " thành công! Tổng tiền: " + tongTienDV.ToString("N0") + " VNĐ.");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        public KetQuaXuLy XacNhanThanhToanDV(string maHDDV)
        {
            if (string.IsNullOrWhiteSpace(maHDDV)) return KetQuaXuLy.Fail("Chưa chọn hóa đơn cần thanh toán.");

            try
            {
                int rows = Db.Execute("UPDATE HoaDonDichVu SET TrangThaiThanhToan = 1 WHERE MaHoaDonDV = @m", Db.P("@m", maHDDV));
                return rows > 0 ? KetQuaXuLy.Ok("Xác nhận thanh toán hóa đơn dịch vụ " + maHDDV + " thành công!") : KetQuaXuLy.Fail("Không tìm thấy hóa đơn.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        private static void Exec(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr)) { cmd.Parameters.AddRange(ps); cmd.ExecuteNonQuery(); }
        }

        private static object Scalar(SqlConnection cn, SqlTransaction tr, string sql, params SqlParameter[] ps)
        {
            using (var cmd = new SqlCommand(sql, cn, tr)) { cmd.Parameters.AddRange(ps); return cmd.ExecuteScalar(); }
        }
    }
}