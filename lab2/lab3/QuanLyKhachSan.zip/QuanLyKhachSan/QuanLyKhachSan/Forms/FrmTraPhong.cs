﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmTraPhong : Form
    {
        private readonly TraPhongService _tpService = new TraPhongService();
        private string _maTienNghiDangChon = "";

        public FrmTraPhong()
        {
            InitializeComponent();
        }

        private void FrmTraPhong_Load(object sender, EventArgs e)
        {
            LamMoiMaChungTu();
            CaiDatGoiYPhieu();

            // Tìm phiếu đang ở gần nhất trong CSDL
            object phieuDangO = Db.Scalar("SELECT TOP 1 MaPhieuDat FROM PhieuDatPhong WHERE TrangThai = N'Đang ở' ORDER BY NgayDat DESC");
            if (phieuDangO != null)
            {
                txtPhieuDangO.Text = phieuDangO.ToString();
            }
            else
            {
                // Nếu chưa có ai đang ở, thử tìm phiếu bất kỳ có sẵn
                object phieuBatKy = Db.Scalar("SELECT TOP 1 MaPhieuDat FROM PhieuDatPhong ORDER BY NgayDat DESC");
                if (phieuBatKy != null)
                {
                    txtPhieuDangO.Text = phieuBatKy.ToString();
                }
                else
                {
                    // Nếu DB hoàn toàn trống phiếu, đặt mặc định DP001 để hỗ trợ kiểm thử
                    txtPhieuDangO.Text = "DP001";
                }
            }

            NapTatCaDuLieu();
        }

        // Tự sinh mã phiếu đền bù và mã hóa đơn kế tiếp
        private void LamMoiMaChungTu()
        {
            int soDB = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDenBu"));
            txtSoPhieuDenBu.Text = string.Format("DB{0:D3}", soDB + 1);

            int soHD = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM HoaDon"));
            txtSoHoaDon.Text = string.Format("HD{0:D3}", soHD + 1);

            txtMucDo.Clear();
            txtSoTienDenBu.Clear();
            txtSoTienThanhToan.Clear();
            txtSoNgayTinhTien.Text = "1";
            txtHinhThuc.Text = "Tiền mặt";
        }

        // Tự động bật danh sách gợi ý phiếu đặt khi gõ phím
        private void CaiDatGoiYPhieu()
        {
            DataTable dtPhieu = Db.Query("SELECT MaPhieuDat FROM PhieuDatPhong");
            AutoCompleteStringCollection goiY = new AutoCompleteStringCollection();
            foreach (DataRow r in dtPhieu.Rows)
            {
                goiY.Add(r["MaPhieuDat"].ToString());
            }

            if (goiY.Count == 0)
            {
                goiY.AddRange(new string[] { "DP001", "DP002", "DP003" });
            }

            txtPhieuDangO.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtPhieuDangO.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtPhieuDangO.AutoCompleteCustomSource = goiY;
        }

        private void txtPhieuDangO_TextChanged(object sender, EventArgs e)
        {
            NapTatCaDuLieu();
        }

        private void NapTatCaDuLieu()
        {
            string maPhieu = txtPhieuDangO.Text.Trim();
            if (string.IsNullOrWhiteSpace(maPhieu))
            {
                dgvPhong.DataSource = null;
                dgvTienNghi.DataSource = null;
                dgvDenBu.DataSource = null;
                dgvHoaDon.DataSource = null;
                return;
            }

            // 1. Nạp bảng phòng thực tế
            DataTable dtP = _tpService.LayThongTinPhong(maPhieu);
            DataTable dtHienThiP = new DataTable();
            dtHienThiP.Columns.Add("Phong", typeof(string));
            dtHienThiP.Columns.Add("DonGia", typeof(string));

            foreach (DataRow r in dtP.Rows)
            {
                decimal.TryParse(r["DonGia"]?.ToString(), out decimal gia);
                dtHienThiP.Rows.Add(r["Phong"], gia > 0 ? gia.ToString("N0") : "0");
            }
            dgvPhong.DataSource = dtHienThiP;

            // 2. Nạp bảng tiện nghi trong phòng
            DataTable dtTN = _tpService.LayTienNghiTrongPhong(maPhieu);
            dgvTienNghi.DataSource = dtTN;

            // 3. Nạp bảng đền bù thực tế
            DataTable dtDB = _tpService.LayDanhSachDenBu(maPhieu);
            DataTable dtHienThiDB = new DataTable();
            dtHienThiDB.Columns.Add("TienNghiDenBu", typeof(string));
            dtHienThiDB.Columns.Add("MucDo", typeof(string));
            dtHienThiDB.Columns.Add("SoTien", typeof(string));

            foreach (DataRow r in dtDB.Rows)
            {
                decimal.TryParse(r["SoTien"]?.ToString(), out decimal tien);
                dtHienThiDB.Rows.Add(r["TienNghiDenBu"], r["MucDo"], tien > 0 ? tien.ToString("N0") : "0");
            }
            dgvDenBu.DataSource = dtHienThiDB;

            // 4. Tính toán số ngày ở thực tế từ ngày nhận đến hiện tại
            object ngayNhanObj = Db.Scalar("SELECT NgayNhan FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu));
            if (ngayNhanObj != null && DateTime.TryParse(ngayNhanObj.ToString(), out DateTime ngayNhan))
            {
                int soNgay = (DateTime.Today - ngayNhan.Date).Days;
                txtSoNgayTinhTien.Text = soNgay > 0 ? soNgay.ToString() : "1";
            }

            // 5. Nạp danh sách hóa đơn
            NapDanhSachHoaDon();
        }

        private void NapDanhSachHoaDon()
        {
            string maPhieu = txtPhieuDangO.Text.Trim();
            DataTable dtHD = _tpService.LayDanhSachHoaDon(maPhieu);
            DataTable dtHienThiHD = new DataTable();
            dtHienThiHD.Columns.Add("HoaDon", typeof(string));
            dtHienThiHD.Columns.Add("PhieuDat", typeof(string));
            dtHienThiHD.Columns.Add("TienPhong", typeof(string));
            dtHienThiHD.Columns.Add("TienDichVu", typeof(string));
            dtHienThiHD.Columns.Add("TongTien", typeof(string));
            dtHienThiHD.Columns.Add("TrangThai", typeof(string));

            foreach (DataRow r in dtHD.Rows)
            {
                decimal.TryParse(r["TienPhong"]?.ToString(), out decimal tienP);
                decimal.TryParse(r["TienDichVu"]?.ToString(), out decimal tienDV);
                decimal.TryParse(r["TongTien"]?.ToString(), out decimal tong);

                dtHienThiHD.Rows.Add(
                    r["MaHoaDon"],
                    r["MaPhieuDat"],
                    tienP > 0 ? tienP.ToString("N0") : "0",
                    tienDV > 0 ? tienDV.ToString("N0") : "0",
                    tong > 0 ? tong.ToString("N0") : "0",
                    r["TrangThai"]
                );
            }
            dgvHoaDon.DataSource = dtHienThiHD;
        }

        // Nhấp vào thiết bị để tự điền mã và gợi ý số tiền đền bù
        private void dgvTienNghi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvTienNghi.Rows[e.RowIndex];
                _maTienNghiDangChon = row.Cells["colTN_TienNghi"].Value?.ToString();

                string tenLoai = row.Cells["colTN_Loai"].Value?.ToString();
                object giaGoiY = Db.Scalar(@"SELECT TOP 1 qd.GiaDenBu 
                                             FROM QuyDinhDenBu qd 
                                             JOIN LoaiTienNghi ltn ON qd.MaLoaiTienNghi = ltn.MaLoaiTienNghi 
                                             WHERE ltn.TenLoaiTienNghi = @ten", new SqlParameter("@ten", tenLoai ?? ""));

                txtSoTienDenBu.Text = giaGoiY != null ? Convert.ToDecimal(giaGoiY).ToString("0") : "200000";
                txtMucDo.Text = "Hư hỏng nhẹ";
            }
        }

        private void dgvHoaDon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvHoaDon.Rows[e.RowIndex];
                txtSoHoaDon.Text = row.Cells["colHD_HoaDon"].Value?.ToString();
                txtSoTienThanhToan.Text = row.Cells["colHD_TongTien"].Value?.ToString()?.Replace(",", "");
            }
        }

        // Lập phiếu đền bù hư hỏng (BR08)
        private void btnLapPhieuDenBu_Click(object sender, EventArgs e)
        {
            string maDB = txtSoPhieuDenBu.Text.Trim();
            string maPhieu = txtPhieuDangO.Text.Trim();
            string mucDo = txtMucDo.Text.Trim();
            decimal.TryParse(txtSoTienDenBu.Text.Replace(",", "").Trim(), out decimal soTien);

            if (string.IsNullOrWhiteSpace(maPhieu))
            {
                MessageBox.Show("Vui lòng nhập hoặc chọn Phiếu đang ở.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (ok, msg) = _tpService.LapPhieuDenBu(maDB, maPhieu, _maTienNghiDangChon, mucDo, soTien);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi đền bù", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapTatCaDuLieu();
                int soDB = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDenBu"));
                txtSoPhieuDenBu.Text = string.Format("DB{0:D3}", soDB + 1);
                txtMucDo.Clear();
                txtSoTienDenBu.Clear();
            }
        }

        // Lập hóa đơn tính tiền (BR09)
        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string maHD = txtSoHoaDon.Text.Trim();
            string maPhieu = txtPhieuDangO.Text.Trim();
            int.TryParse(txtSoNgayTinhTien.Text.Trim(), out int soNgay);

            if (string.IsNullOrWhiteSpace(maPhieu))
            {
                MessageBox.Show("Vui lòng nhập Phiếu đang ở để lập hóa đơn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (ok, msg) = _tpService.LapHoaDon(maHD, maPhieu, soNgay > 0 ? soNgay : 1);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi lập hóa đơn", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachHoaDon();
                object tongTienMoi = Db.Scalar("SELECT TongTien FROM HoaDon WHERE MaHoaDon = @ma", new SqlParameter("@ma", maHD));
                if (tongTienMoi != null)
                {
                    txtSoTienThanhToan.Text = Convert.ToDecimal(tongTienMoi).ToString("0");
                }
            }
        }

        // Ghi nhận thanh toán (BR10)
        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string maHD = txtSoHoaDon.Text.Trim();
            string hinhThuc = txtHinhThuc.Text.Trim();
            decimal.TryParse(txtSoTienThanhToan.Text.Replace(",", "").Trim(), out decimal soTien);

            if (string.IsNullOrWhiteSpace(maHD))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Mã hóa đơn cần thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (ok, msg) = _tpService.ThanhToan(maHD, hinhThuc, soTien);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi thanh toán", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachHoaDon();
            }
        }

        // Hoàn tất trả phòng và trả trạng thái phòng về Trống
        private void btnHoanTatTraPhong_Click(object sender, EventArgs e)
        {
            string maPhieu = txtPhieuDangO.Text.Trim();
            if (string.IsNullOrWhiteSpace(maPhieu))
            {
                MessageBox.Show("Vui lòng nhập Phiếu đang ở để hoàn tất thủ tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (ok, msg) = _tpService.HoanTatTraPhong(maPhieu);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi trả phòng", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapTatCaDuLieu();
                LamMoiMaChungTu();
            }
        }
    }
}