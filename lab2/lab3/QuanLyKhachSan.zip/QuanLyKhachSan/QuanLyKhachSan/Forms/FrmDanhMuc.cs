﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private enum CheDoDanhMuc
        {
            KhuVuc,
            NhanVien,
            LoaiTienNghi,
            DichVu,
            QuyDinhDenBu
        }

        private CheDoDanhMuc _cheDoHienTai = CheDoDanhMuc.KhuVuc;

        public FrmDanhMuc()
        {
            InitializeComponent();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            // Mặc định nạp danh mục đầu tiên: Khu vực
            ChonCheDo(CheDoDanhMuc.KhuVuc);
        }

        private void ChonCheDo(CheDoDanhMuc cheDo)
        {
            _cheDoHienTai = cheDo;
            CapNhatMauNutNav();
            NapDuLieuLenBang();

            // Làm sạch các ô nhập liệu, không gán số liệu cứng
            txtMa.Clear();
            txtTen.Clear();
            txtDonViVaiTro.Clear();
        }

        private void CapNhatMauNutNav()
        {
            Color mauBinhThuong = Color.Black;
            Color mauDangChon = Color.FromArgb(26, 59, 93);
            Font fontBinhThuong = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            Font fontDangChon = new Font("Segoe UI", 9.5F, FontStyle.Bold);

            Button[] danhSachNut = { btnNavKhuVuc, btnNavNhanVien, btnNavLoaiTN, btnNavDichVu, btnNavQuyDinh };
            foreach (var btn in danhSachNut)
            {
                btn.ForeColor = mauBinhThuong;
                btn.Font = fontBinhThuong;
            }

            switch (_cheDoHienTai)
            {
                case CheDoDanhMuc.KhuVuc:
                    btnNavKhuVuc.ForeColor = mauDangChon;
                    btnNavKhuVuc.Font = fontDangChon;
                    lblDonViVaiTro.Text = "Ghi chú:";
                    break;
                case CheDoDanhMuc.NhanVien:
                    btnNavNhanVien.ForeColor = mauDangChon;
                    btnNavNhanVien.Font = fontDangChon;
                    lblDonViVaiTro.Text = "Vai trò (Chức vụ):";
                    break;
                case CheDoDanhMuc.LoaiTienNghi:
                    btnNavLoaiTN.ForeColor = mauDangChon;
                    btnNavLoaiTN.Font = fontDangChon;
                    lblDonViVaiTro.Text = "Ghi chú:";
                    break;
                case CheDoDanhMuc.DichVu:
                    btnNavDichVu.ForeColor = mauDangChon;
                    btnNavDichVu.Font = fontDangChon;
                    lblDonViVaiTro.Text = "Đơn vị / Vai trò:";
                    break;
                case CheDoDanhMuc.QuyDinhDenBu:
                    btnNavQuyDinh.ForeColor = mauDangChon;
                    btnNavQuyDinh.Font = fontDangChon;
                    lblDonViVaiTro.Text = "Mức độ hư hại:";
                    break;
            }
        }

        private void NapDuLieuLenBang()
        {
            DataTable dtHienThi = new DataTable();
            dtHienThi.Columns.Add("Ma", typeof(string));
            dtHienThi.Columns.Add("Ten", typeof(string));
            dtHienThi.Columns.Add("LoaiVaiTro", typeof(string));
            dtHienThi.Columns.Add("DonVi", typeof(string));
            dtHienThi.Columns.Add("DonGiaMuc", typeof(string));

            switch (_cheDoHienTai)
            {
                case CheDoDanhMuc.KhuVuc:
                    DataTable dtKV = Db.Query("SELECT MaKhuVuc, TenKhuVuc FROM KhuVuc ORDER BY MaKhuVuc");
                    foreach (DataRow r in dtKV.Rows)
                        dtHienThi.Rows.Add(r["MaKhuVuc"], r["TenKhuVuc"], "Khu vực", "", "");
                    break;

                case CheDoDanhMuc.NhanVien:
                    DataTable dtNV = Db.Query("SELECT MaNV, HoTen, ChucVu, SoDienThoai FROM NhanVien ORDER BY MaNV");
                    foreach (DataRow r in dtNV.Rows)
                        dtHienThi.Rows.Add(r["MaNV"], r["HoTen"], r["ChucVu"], r["SoDienThoai"], "");
                    break;

                case CheDoDanhMuc.LoaiTienNghi:
                    DataTable dtLTN = Db.Query("SELECT MaLoaiTienNghi, TenLoaiTienNghi FROM LoaiTienNghi ORDER BY MaLoaiTienNghi");
                    foreach (DataRow r in dtLTN.Rows)
                        dtHienThi.Rows.Add(r["MaLoaiTienNghi"], r["TenLoaiTienNghi"], "Tiện nghi", "Cái/Bộ", "");
                    break;

                case CheDoDanhMuc.DichVu:
                    DataTable dtDV = Db.Query("SELECT MaDichVu, TenDichVu, DonGia FROM DichVu ORDER BY MaDichVu");
                    foreach (DataRow r in dtDV.Rows)
                    {
                        decimal.TryParse(r["DonGia"]?.ToString(), out decimal gia);
                        dtHienThi.Rows.Add(r["MaDichVu"], r["TenDichVu"], "Dịch vụ", "Lượt/Suất", gia > 0 ? gia.ToString("N0") : "");
                    }
                    break;

                case CheDoDanhMuc.QuyDinhDenBu:
                    DataTable dtQD = Db.Query(@"SELECT qd.MaQuyDinh, ltn.TenLoaiTienNghi, qd.MucDoHuHong, qd.GiaDenBu 
                                              FROM QuyDinhDenBu qd 
                                              JOIN LoaiTienNghi ltn ON qd.MaLoaiTienNghi = ltn.MaLoaiTienNghi 
                                              ORDER BY qd.MaQuyDinh");
                    foreach (DataRow r in dtQD.Rows)
                    {
                        decimal.TryParse(r["GiaDenBu"]?.ToString(), out decimal gia);
                        dtHienThi.Rows.Add(r["MaQuyDinh"], r["TenLoaiTienNghi"], r["MucDoHuHong"], "", gia > 0 ? gia.ToString("N0") : "");
                    }
                    break;
            }

            dgvDanhMuc.DataSource = dtHienThi;
        }

        private void dgvDanhMuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvDanhMuc.Rows[e.RowIndex];
                txtMa.Text = row.Cells["colMa"].Value?.ToString();
                txtTen.Text = row.Cells["colTen"].Value?.ToString();

                string donVi = row.Cells["colDonVi"].Value?.ToString();
                string vaiTro = row.Cells["colLoaiVaiTro"].Value?.ToString();
                txtDonViVaiTro.Text = !string.IsNullOrEmpty(donVi) ? donVi : vaiTro;
            }
        }

        #region Các sự kiện chuyển đổi danh mục
        private void btnNavKhuVuc_Click(object sender, EventArgs e) => ChonCheDo(CheDoDanhMuc.KhuVuc);
        private void btnNavNhanVien_Click(object sender, EventArgs e) => ChonCheDo(CheDoDanhMuc.NhanVien);
        private void btnNavLoaiTN_Click(object sender, EventArgs e) => ChonCheDo(CheDoDanhMuc.LoaiTienNghi);
        private void btnNavDichVu_Click(object sender, EventArgs e) => ChonCheDo(CheDoDanhMuc.DichVu);
        private void btnNavQuyDinh_Click(object sender, EventArgs e) => ChonCheDo(CheDoDanhMuc.QuyDinhDenBu);
        #endregion

        #region Sự kiện Thêm danh mục
        private void btnThem_Click(object sender, EventArgs e)
        {
            string ma = txtMa.Text.Trim();
            string ten = txtTen.Text.Trim();
            string donViVaiTro = txtDonViVaiTro.Text.Trim();

            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Mã và Tên danh mục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                switch (_cheDoHienTai)
                {
                    case CheDoDanhMuc.KhuVuc:
                        Db.Execute("INSERT INTO KhuVuc (MaKhuVuc, TenKhuVuc) VALUES (@ma, @ten)",
                            new SqlParameter("@ma", ma), new SqlParameter("@ten", ten));
                        break;

                    case CheDoDanhMuc.NhanVien:
                        Db.Execute("INSERT INTO NhanVien (MaNV, HoTen, ChucVu, SoDienThoai) VALUES (@ma, @ten, @cv, @sdt)",
                            new SqlParameter("@ma", ma), new SqlParameter("@ten", ten),
                            new SqlParameter("@cv", string.IsNullOrWhiteSpace(donViVaiTro) ? "Nhân viên" : donViVaiTro),
                            new SqlParameter("@sdt", ""));
                        break;

                    case CheDoDanhMuc.LoaiTienNghi:
                        Db.Execute("INSERT INTO LoaiTienNghi (MaLoaiTienNghi, TenLoaiTienNghi) VALUES (@ma, @ten)",
                            new SqlParameter("@ma", ma), new SqlParameter("@ten", ten));
                        break;

                    case CheDoDanhMuc.DichVu:
                        int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM DichVu WHERE MaDichVu = @ma", new SqlParameter("@ma", ma)));
                        if (daCo > 0)
                        {
                            Db.Execute("UPDATE DichVu SET TenDichVu = @ten WHERE MaDichVu = @ma",
                                new SqlParameter("@ten", ten), new SqlParameter("@ma", ma));
                        }
                        else
                        {
                            Db.Execute("INSERT INTO DichVu (MaDichVu, TenDichVu, DonGia) VALUES (@ma, @ten, 0)",
                                new SqlParameter("@ma", ma), new SqlParameter("@ten", ten));
                        }
                        break;

                    case CheDoDanhMuc.QuyDinhDenBu:
                        object firstLoai = Db.Scalar("SELECT TOP 1 MaLoaiTienNghi FROM LoaiTienNghi");
                        string maLoai = firstLoai != null ? firstLoai.ToString() : "TN_TV";
                        Db.Execute("INSERT INTO QuyDinhDenBu (MaQuyDinh, MaLoaiTienNghi, MucDoHuHong, GiaDenBu) VALUES (@ma, @loai, @mucDo, 0)",
                            new SqlParameter("@ma", ma), new SqlParameter("@loai", maLoai), new SqlParameter("@mucDo", ten));
                        break;
                }

                MessageBox.Show("Thêm danh mục mới thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                NapDuLieuLenBang();
                txtMa.Clear();
                txtTen.Clear();
                txtDonViVaiTro.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lưu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
    }
}