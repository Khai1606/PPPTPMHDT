﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDatPhong : Form
    {
        private enum CheDoXem
        {
            KhachHang,
            DatPhong,
            NhanPhong
        }

        private CheDoXem _cheDoHienTai = CheDoXem.DatPhong;
        private readonly DatPhongService _service = new DatPhongService();
        private DataTable _dtPhongChon = new DataTable();

        public FrmDatPhong()
        {
            InitializeComponent();
        }

        private void FrmDatPhong_Load(object sender, EventArgs e)
        {
            KhoiTaoBangPhongChon();
            ChonCheDo(CheDoXem.DatPhong);
        }

        private void KhoiTaoBangPhongChon()
        {
            _dtPhongChon = new DataTable();
            _dtPhongChon.Columns.Add("PhongChon", typeof(string));
            _dtPhongChon.Columns.Add("SoNguoi", typeof(int));
            _dtPhongChon.Columns.Add("DonGiaNgay", typeof(string));
            dgvPhongChon.DataSource = _dtPhongChon;
        }

        private void ChonCheDo(CheDoXem cheDo)
        {
            _cheDoHienTai = cheDo;
            CapNhatGiaoDienTheoCheDo();
            NapDuLieu();
        }

        // Cập nhật vị trí động - chống lỗi co giãn màn hình (DPI Scaling) che mất nút
        private void CapNhatGiaoDienTheoCheDo()
        {
            Color mauBinhThuong = Color.Black;
            Color mauDangChon = Color.FromArgb(26, 59, 93);
            Font fontBinhThuong = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            Font fontDangChon = new Font("Segoe UI", 9.5F, FontStyle.Bold);

            btnNavKhachHang.ForeColor = mauBinhThuong;
            btnNavKhachHang.Font = fontBinhThuong;
            btnNavDatPhong.ForeColor = mauBinhThuong;
            btnNavDatPhong.Font = fontBinhThuong;
            btnNavNhanPhong.ForeColor = mauBinhThuong;
            btnNavNhanPhong.Font = fontBinhThuong;

            txtSoPhieu.Clear();
            txtKhach.Clear();
            txtKenhDat.Clear();
            txtTienCoc.Clear();
            _dtPhongChon.Clear();

            switch (_cheDoHienTai)
            {
                // 1. Chế độ [Khách hàng]
                case CheDoXem.KhachHang:
                    btnNavKhachHang.ForeColor = mauDangChon;
                    btnNavKhachHang.Font = fontDangChon;

                    lblSoPhieu.Text = "Mã khách:";
                    lblKhach.Text = "Họ và tên:";
                    lblKenhDat.Text = "CCCD:";
                    lblTienCoc.Text = "Số điện thoại:";

                    txtSoPhieu.Text = _service.SinhMaKhachTuDong();

                    dgvPhongTrong.Visible = false;
                    dgvPhongChon.Visible = false;

                    // Canh vị trí dưới hàng nhập liệu
                    lblPhieuDat.Text = "Danh sách khách hàng (KhachHang):";
                    lblPhieuDat.Top = txtKhach.Bottom + 16;
                    lblPhieuDat.Left = dgvPhongTrong.Left;

                    btnLapPhieuDat.Text = "Lưu khách hàng";
                    btnLapPhieuDat.Size = new Size(180, 36);
                    btnLapPhieuDat.Top = txtKhach.Bottom + 10;
                    btnLapPhieuDat.Left = dgvPhongChon.Right - btnLapPhieuDat.Width;
                    btnLapPhieuDat.Visible = true;
                    btnLapPhieuDat.BringToFront();

                    dgvPhieuDat.Top = btnLapPhieuDat.Bottom + 10;
                    dgvPhieuDat.Left = dgvPhongTrong.Left;
                    dgvPhieuDat.Width = dgvPhongChon.Right - dgvPhongTrong.Left;
                    dgvPhieuDat.Height = this.ClientSize.Height - dgvPhieuDat.Top - 15;
                    dgvPhieuDat.BringToFront();
                    break;

                // 2. Chế độ [Đặt phòng]
                case CheDoXem.DatPhong:
                    btnNavDatPhong.ForeColor = mauDangChon;
                    btnNavDatPhong.Font = fontDangChon;

                    lblSoPhieu.Text = "Số phiếu đặt:";
                    lblKhach.Text = "Khách:";
                    lblKenhDat.Text = "Kênh đặt:";
                    lblTienCoc.Text = "Tiền cọc:";

                    txtSoPhieu.Text = _service.SinhMaPhieuDatTuDong();
                    txtKenhDat.Text = "Trực tiếp";

                    dgvPhongTrong.Visible = true;
                    dgvPhongChon.Visible = true;

                    // Canh vị trí tự động bám theo mép dưới thực tế của 2 bảng phòng
                    lblPhieuDat.Text = "Phiếu đặt phòng:";
                    lblPhieuDat.Top = dgvPhongTrong.Bottom + 14;
                    lblPhieuDat.Left = dgvPhongTrong.Left;

                    btnLapPhieuDat.Text = "Lập phiếu đặt";
                    btnLapPhieuDat.Size = new Size(180, 36);
                    btnLapPhieuDat.Top = dgvPhongChon.Bottom + 8;
                    btnLapPhieuDat.Left = dgvPhongChon.Right - btnLapPhieuDat.Width;
                    btnLapPhieuDat.Visible = true;
                    btnLapPhieuDat.BringToFront(); // Luôn nổi lên trên, không bao giờ bị che

                    dgvPhieuDat.Top = btnLapPhieuDat.Bottom + 8;
                    dgvPhieuDat.Left = dgvPhongTrong.Left;
                    dgvPhieuDat.Width = dgvPhongChon.Right - dgvPhongTrong.Left;
                    dgvPhieuDat.Height = this.ClientSize.Height - dgvPhieuDat.Top - 15;
                    dgvPhieuDat.BringToFront();
                    break;

                // 3. Chế độ [Nhận phòng / Người lưu trú]
                case CheDoXem.NhanPhong:
                    btnNavNhanPhong.ForeColor = mauDangChon;
                    btnNavNhanPhong.Font = fontDangChon;

                    lblSoPhieu.Text = "Số phiếu đặt:";
                    lblKhach.Text = "Người lưu trú:";
                    lblKenhDat.Text = "CCCD:";
                    lblTienCoc.Text = "Quốc tịch:";

                    txtTienCoc.Text = "Việt Nam";

                    dgvPhongTrong.Visible = false;
                    dgvPhongChon.Visible = false;

                    lblPhieuDat.Text = "Phiếu đặt chờ nhận phòng (Chọn dòng để lưu người lưu trú BR06 & Nhận phòng):";
                    lblPhieuDat.Top = txtKhach.Bottom + 16;
                    lblPhieuDat.Left = dgvPhongTrong.Left;

                    btnLapPhieuDat.Text = "Nhận phòng & Lưu";
                    btnLapPhieuDat.Size = new Size(200, 36);
                    btnLapPhieuDat.Top = txtKhach.Bottom + 10;
                    btnLapPhieuDat.Left = dgvPhongChon.Right - btnLapPhieuDat.Width;
                    btnLapPhieuDat.Visible = true;
                    btnLapPhieuDat.BringToFront();

                    dgvPhieuDat.Top = btnLapPhieuDat.Bottom + 10;
                    dgvPhieuDat.Left = dgvPhongTrong.Left;
                    dgvPhieuDat.Width = dgvPhongChon.Right - dgvPhongTrong.Left;
                    dgvPhieuDat.Height = this.ClientSize.Height - dgvPhieuDat.Top - 15;
                    dgvPhieuDat.BringToFront();
                    break;
            }
        }

        private void NapDuLieu()
        {
            if (_cheDoHienTai == CheDoXem.KhachHang)
            {
                DataTable dtKH = _service.LayDanhSachKhachHang();
                DataTable dtHienThi = new DataTable();
                dtHienThi.Columns.Add("SoPhieu", typeof(string));
                dtHienThi.Columns.Add("Khach", typeof(string));
                dtHienThi.Columns.Add("NgayNhan", typeof(string));
                dtHienThi.Columns.Add("NgayTraDuKien", typeof(string));
                dtHienThi.Columns.Add("Coc", typeof(string));
                dtHienThi.Columns.Add("Kenh", typeof(string));
                dtHienThi.Columns.Add("TrangThai", typeof(string));

                colSoPhieu.HeaderText = "Mã khách";
                colTenKhach.HeaderText = "Họ và tên";
                colNgayNhan.HeaderText = "CCCD";
                colNgayTra.HeaderText = "Số điện thoại";
                colCoc.HeaderText = "Email";
                colKenh.HeaderText = "";
                colTrangThai.HeaderText = "";

                foreach (DataRow r in dtKH.Rows)
                {
                    dtHienThi.Rows.Add(r["MaKhach"], r["HoTen"], r["CCCD"], r["SoDienThoai"], r["Email"], "", "");
                }
                dgvPhieuDat.DataSource = dtHienThi;
            }
            else
            {
                if (_cheDoHienTai == CheDoXem.DatPhong)
                {
                    DataTable dtPhong = _service.LayDanhSachPhongTrong();
                    DataTable dtHienThiPhong = new DataTable();
                    dtHienThiPhong.Columns.Add("Phong", typeof(string));
                    dtHienThiPhong.Columns.Add("Khu", typeof(string));
                    dtHienThiPhong.Columns.Add("SucChua", typeof(string));
                    dtHienThiPhong.Columns.Add("DonGia", typeof(string));

                    foreach (DataRow r in dtPhong.Rows)
                    {
                        decimal.TryParse(r["DonGia"]?.ToString(), out decimal gia);
                        dtHienThiPhong.Rows.Add(r["Phong"], r["Khu"], r["SucChua"], gia > 0 ? gia.ToString("N0") : "0");
                    }
                    dgvPhongTrong.DataSource = dtHienThiPhong;
                }

                colSoPhieu.HeaderText = "Số phiếu";
                colTenKhach.HeaderText = "Khách";
                colNgayNhan.HeaderText = "Ngày nhận";
                colNgayTra.HeaderText = "Ngày trả dự kiến";
                colCoc.HeaderText = "Cọc";
                colKenh.HeaderText = "Kênh";
                colTrangThai.HeaderText = "Trạng thái";

                bool chiLayChoNhan = (_cheDoHienTai == CheDoXem.NhanPhong);
                DataTable dtPhieu = _service.LayDanhSachPhieuDat(chiLayChoNhan);
                DataTable dtHienThiPhieu = new DataTable();
                dtHienThiPhieu.Columns.Add("SoPhieu", typeof(string));
                dtHienThiPhieu.Columns.Add("Khach", typeof(string));
                dtHienThiPhieu.Columns.Add("NgayNhan", typeof(string));
                dtHienThiPhieu.Columns.Add("NgayTraDuKien", typeof(string));
                dtHienThiPhieu.Columns.Add("Coc", typeof(string));
                dtHienThiPhieu.Columns.Add("Kenh", typeof(string));
                dtHienThiPhieu.Columns.Add("TrangThai", typeof(string));

                foreach (DataRow r in dtPhieu.Rows)
                {
                    DateTime.TryParse(r["NgayNhan"]?.ToString(), out DateTime nhan);
                    DateTime.TryParse(r["NgayTraDuKien"]?.ToString(), out DateTime tra);
                    decimal.TryParse(r["Coc"]?.ToString(), out decimal coc);

                    dtHienThiPhieu.Rows.Add(
                        r["SoPhieu"],
                        r["Khach"],
                        nhan.ToString("dd/MM/yyyy"),
                        tra.ToString("dd/MM/yyyy"),
                        coc > 0 ? coc.ToString("N0") : "0",
                        r["Kenh"],
                        r["TrangThai"]
                    );
                }
                dgvPhieuDat.DataSource = dtHienThiPhieu;
            }
        }

        private void btnNavKhachHang_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.KhachHang);
        private void btnNavDatPhong_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.DatPhong);
        private void btnNavNhanPhong_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.NhanPhong);

        private void dgvPhongTrong_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvPhongTrong.Rows[e.RowIndex];
                string phong = row.Cells["colPhong"].Value?.ToString();
                string gia = row.Cells["colDonGia"].Value?.ToString();

                foreach (DataRow r in _dtPhongChon.Rows)
                {
                    if (r["PhongChon"]?.ToString() == phong)
                    {
                        MessageBox.Show($"Phòng {phong} đã có trong danh sách chọn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                _dtPhongChon.Rows.Add(phong, 2, gia);
            }
        }

        private void dgvPhieuDat_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvPhieuDat.Rows[e.RowIndex];
                txtSoPhieu.Text = row.Cells["colSoPhieu"].Value?.ToString();
                txtKhach.Text = row.Cells["colTenKhach"].Value?.ToString();

                if (_cheDoHienTai == CheDoXem.KhachHang)
                {
                    txtKenhDat.Text = row.Cells["colNgayNhan"].Value?.ToString();
                    txtTienCoc.Text = row.Cells["colNgayTra"].Value?.ToString();
                }
                else if (_cheDoHienTai == CheDoXem.NhanPhong)
                {
                    txtKhach.Text = row.Cells["colTenKhach"].Value?.ToString();
                    txtKenhDat.Clear();
                    txtTienCoc.Text = "Việt Nam";
                }
                else
                {
                    txtKenhDat.Text = row.Cells["colKenh"].Value?.ToString();
                    txtTienCoc.Text = row.Cells["colCoc"].Value?.ToString()?.Replace(",", "");
                }
            }
        }

        private void btnLapPhieuDat_Click(object sender, EventArgs e)
        {
            // 1. Lưu khách hàng
            if (_cheDoHienTai == CheDoXem.KhachHang)
            {
                string maKH = txtSoPhieu.Text.Trim();
                string hoTen = txtKhach.Text.Trim();
                string cccd = txtKenhDat.Text.Trim();
                string sdt = txtTienCoc.Text.Trim();

                var (okKH, msgKH) = _service.LuuKhachHang(maKH, hoTen, cccd, sdt);
                MessageBox.Show(msgKH, okKH ? "Thông báo" : "Lỗi", MessageBoxButtons.OK, okKH ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                if (okKH)
                {
                    NapDuLieu();
                    txtSoPhieu.Text = _service.SinhMaKhachTuDong();
                    txtKhach.Clear();
                    txtKenhDat.Clear();
                    txtTienCoc.Clear();
                }
                return;
            }

            // 2. Nhận phòng & Lưu người lưu trú
            if (_cheDoHienTai == CheDoXem.NhanPhong)
            {
                string soPhieu = txtSoPhieu.Text.Trim();
                string nguoiO = txtKhach.Text.Trim();
                string cccd = txtKenhDat.Text.Trim();
                string quocTich = txtTienCoc.Text.Trim();

                var (okNhan, msgNhan) = _service.NhanPhongVaLuuNguoiLuuTru(soPhieu, nguoiO, cccd, quocTich);
                MessageBox.Show(msgNhan, okNhan ? "Thông báo" : "Lỗi", MessageBoxButtons.OK, okNhan ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                if (okNhan)
                {
                    NapDuLieu();
                    txtSoPhieu.Clear();
                    txtKhach.Clear();
                    txtKenhDat.Clear();
                }
                return;
            }

            // 3. Lập phiếu đặt phòng
            string maPhieu = txtSoPhieu.Text.Trim();
            string tenKhach = txtKhach.Text.Trim();
            string kenhDat = txtKenhDat.Text.Trim();
            decimal.TryParse(txtTienCoc.Text.Replace(",", "").Trim(), out decimal tienCoc);

            if (_dtPhongChon.Rows.Count == 0)
            {
                MessageBox.Show("Vui lòng nhấp đúp chọn ít nhất một phòng từ bảng phòng trống bên trái.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<(string SoPhong, int SoNguoi, decimal DonGia)> dsPhong = new List<(string, int, decimal)>();
            foreach (DataRow r in _dtPhongChon.Rows)
            {
                string p = r["PhongChon"].ToString();
                int.TryParse(r["SoNguoi"]?.ToString(), out int soNguoi);
                decimal.TryParse(r["DonGiaNgay"]?.ToString()?.Replace(",", ""), out decimal gia);
                dsPhong.Add((p, soNguoi > 0 ? soNguoi : 1, gia));
            }

            DateTime ngayNhan = DateTime.Today;
            DateTime ngayTra = DateTime.Today.AddDays(1);

            var (okDat, msgDat) = _service.DatPhong(maPhieu, tenKhach, kenhDat, tienCoc, ngayNhan, ngayTra, dsPhong);
            MessageBox.Show(msgDat, okDat ? "Thông báo" : "Cảnh báo quy tắc", MessageBoxButtons.OK, okDat ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (okDat)
            {
                txtSoPhieu.Text = _service.SinhMaPhieuDatTuDong();
                txtKhach.Clear();
                txtTienCoc.Clear();
                _dtPhongChon.Clear();
                NapDuLieu();
            }
        }
    }
}