﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmTraPhong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblPhieuDangO = new System.Windows.Forms.Label();
            this.txtPhieuDangO = new System.Windows.Forms.TextBox();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.colP_Phong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colP_DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvTienNghi = new System.Windows.Forms.DataGridView();
            this.colTN_TienNghi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTN_Loai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTN_TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDenBu = new System.Windows.Forms.DataGridView();
            this.colDB_TienNghi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDB_MucDo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDB_SoTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSoPhieuDenBu = new System.Windows.Forms.Label();
            this.txtSoPhieuDenBu = new System.Windows.Forms.TextBox();
            this.lblMucDo = new System.Windows.Forms.Label();
            this.txtMucDo = new System.Windows.Forms.TextBox();
            this.lblSoTienDenBu = new System.Windows.Forms.Label();
            this.txtSoTienDenBu = new System.Windows.Forms.TextBox();
            this.btnLapPhieuDenBu = new System.Windows.Forms.Button();
            this.lblSoHoaDon = new System.Windows.Forms.Label();
            this.txtSoHoaDon = new System.Windows.Forms.TextBox();
            this.lblSoNgayTinhTien = new System.Windows.Forms.Label();
            this.txtSoNgayTinhTien = new System.Windows.Forms.TextBox();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.colHD_HoaDon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHD_PhieuDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHD_TienPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHD_TienDichVu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHD_TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHD_TrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.txtHinhThuc = new System.Windows.Forms.TextBox();
            this.lblSoTienThanhToan = new System.Windows.Forms.Label();
            this.txtSoTienThanhToan = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnHoanTatTraPhong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDenBu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPhieuDangO
            // 
            this.lblPhieuDangO.AutoSize = true;
            this.lblPhieuDangO.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhieuDangO.Location = new System.Drawing.Point(24, 20);
            this.lblPhieuDangO.Name = "lblPhieuDangO";
            this.lblPhieuDangO.Size = new System.Drawing.Size(104, 21);
            this.lblPhieuDangO.TabIndex = 0;
            this.lblPhieuDangO.Text = "Phiếu đang ở:";
            // 
            // txtPhieuDangO
            // 
            this.txtPhieuDangO.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhieuDangO.Location = new System.Drawing.Point(135, 17);
            this.txtPhieuDangO.Name = "txtPhieuDangO";
            this.txtPhieuDangO.Size = new System.Drawing.Size(130, 29);
            this.txtPhieuDangO.TabIndex = 1;
            this.txtPhieuDangO.TextChanged += new System.EventHandler(this.txtPhieuDangO_TextChanged);
            // 
            // dgvPhong
            // 
            this.dgvPhong.AllowUserToAddRows = false;
            this.dgvPhong.AllowUserToDeleteRows = false;
            this.dgvPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhong.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPhong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPhong.ColumnHeadersHeight = 30;
            this.dgvPhong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colP_Phong,
            this.colP_DonGia});
            this.dgvPhong.EnableHeadersVisualStyles = false;
            this.dgvPhong.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPhong.Location = new System.Drawing.Point(24, 60);
            this.dgvPhong.MultiSelect = false;
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.ReadOnly = true;
            this.dgvPhong.RowHeadersVisible = false;
            this.dgvPhong.RowHeadersWidth = 51;
            this.dgvPhong.RowTemplate.Height = 28;
            this.dgvPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhong.Size = new System.Drawing.Size(240, 150);
            this.dgvPhong.TabIndex = 2;
            // 
            // colP_Phong
            // 
            this.colP_Phong.DataPropertyName = "Phong";
            this.colP_Phong.FillWeight = 90F;
            this.colP_Phong.HeaderText = "Phòng";
            this.colP_Phong.MinimumWidth = 6;
            this.colP_Phong.Name = "colP_Phong";
            this.colP_Phong.ReadOnly = true;
            // 
            // colP_DonGia
            // 
            this.colP_DonGia.DataPropertyName = "DonGia";
            this.colP_DonGia.FillWeight = 110F;
            this.colP_DonGia.HeaderText = "Đơn giá/ngày";
            this.colP_DonGia.MinimumWidth = 6;
            this.colP_DonGia.Name = "colP_DonGia";
            this.colP_DonGia.ReadOnly = true;
            // 
            // dgvTienNghi
            // 
            this.dgvTienNghi.AllowUserToAddRows = false;
            this.dgvTienNghi.AllowUserToDeleteRows = false;
            this.dgvTienNghi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTienNghi.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTienNghi.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTienNghi.ColumnHeadersHeight = 30;
            this.dgvTienNghi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTN_TienNghi,
            this.colTN_Loai,
            this.colTN_TinhTrang});
            this.dgvTienNghi.EnableHeadersVisualStyles = false;
            this.dgvTienNghi.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvTienNghi.Location = new System.Drawing.Point(280, 60);
            this.dgvTienNghi.MultiSelect = false;
            this.dgvTienNghi.Name = "dgvTienNghi";
            this.dgvTienNghi.ReadOnly = true;
            this.dgvTienNghi.RowHeadersVisible = false;
            this.dgvTienNghi.RowHeadersWidth = 51;
            this.dgvTienNghi.RowTemplate.Height = 28;
            this.dgvTienNghi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTienNghi.Size = new System.Drawing.Size(290, 150);
            this.dgvTienNghi.TabIndex = 3;
            this.dgvTienNghi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTienNghi_CellClick);
            // 
            // colTN_TienNghi
            // 
            this.colTN_TienNghi.DataPropertyName = "TienNghi";
            this.colTN_TienNghi.FillWeight = 85F;
            this.colTN_TienNghi.HeaderText = "Tiện nghi";
            this.colTN_TienNghi.MinimumWidth = 6;
            this.colTN_TienNghi.Name = "colTN_TienNghi";
            this.colTN_TienNghi.ReadOnly = true;
            // 
            // colTN_Loai
            // 
            this.colTN_Loai.DataPropertyName = "Loai";
            this.colTN_Loai.FillWeight = 110F;
            this.colTN_Loai.HeaderText = "Loại";
            this.colTN_Loai.MinimumWidth = 6;
            this.colTN_Loai.Name = "colTN_Loai";
            this.colTN_Loai.ReadOnly = true;
            // 
            // colTN_TinhTrang
            // 
            this.colTN_TinhTrang.DataPropertyName = "TinhTrang";
            this.colTN_TinhTrang.FillWeight = 105F;
            this.colTN_TinhTrang.HeaderText = "Tình trạng";
            this.colTN_TinhTrang.MinimumWidth = 6;
            this.colTN_TinhTrang.Name = "colTN_TinhTrang";
            this.colTN_TinhTrang.ReadOnly = true;
            // 
            // dgvDenBu
            // 
            this.dgvDenBu.AllowUserToAddRows = false;
            this.dgvDenBu.AllowUserToDeleteRows = false;
            this.dgvDenBu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDenBu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDenBu.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDenBu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDenBu.ColumnHeadersHeight = 30;
            this.dgvDenBu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDB_TienNghi,
            this.colDB_MucDo,
            this.colDB_SoTien});
            this.dgvDenBu.EnableHeadersVisualStyles = false;
            this.dgvDenBu.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvDenBu.Location = new System.Drawing.Point(585, 60);
            this.dgvDenBu.MultiSelect = false;
            this.dgvDenBu.Name = "dgvDenBu";
            this.dgvDenBu.ReadOnly = true;
            this.dgvDenBu.RowHeadersVisible = false;
            this.dgvDenBu.RowHeadersWidth = 51;
            this.dgvDenBu.RowTemplate.Height = 28;
            this.dgvDenBu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDenBu.Size = new System.Drawing.Size(280, 150);
            this.dgvDenBu.TabIndex = 4;
            // 
            // colDB_TienNghi
            // 
            this.colDB_TienNghi.DataPropertyName = "TienNghiDenBu";
            this.colDB_TienNghi.FillWeight = 110F;
            this.colDB_TienNghi.HeaderText = "Tiện nghi đền bù";
            this.colDB_TienNghi.MinimumWidth = 6;
            this.colDB_TienNghi.Name = "colDB_TienNghi";
            this.colDB_TienNghi.ReadOnly = true;
            // 
            // colDB_MucDo
            // 
            this.colDB_MucDo.DataPropertyName = "MucDo";
            this.colDB_MucDo.FillWeight = 100F;
            this.colDB_MucDo.HeaderText = "Mức độ";
            this.colDB_MucDo.MinimumWidth = 6;
            this.colDB_MucDo.Name = "colDB_MucDo";
            this.colDB_MucDo.ReadOnly = true;
            // 
            // colDB_SoTien
            // 
            this.colDB_SoTien.DataPropertyName = "SoTien";
            this.colDB_SoTien.FillWeight = 90F;
            this.colDB_SoTien.HeaderText = "Số tiền";
            this.colDB_SoTien.MinimumWidth = 6;
            this.colDB_SoTien.Name = "colDB_SoTien";
            this.colDB_SoTien.ReadOnly = true;
            // 
            // lblSoPhieuDenBu
            // 
            this.lblSoPhieuDenBu.AutoSize = true;
            this.lblSoPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoPhieuDenBu.Location = new System.Drawing.Point(24, 230);
            this.lblSoPhieuDenBu.Name = "lblSoPhieuDenBu";
            this.lblSoPhieuDenBu.Size = new System.Drawing.Size(126, 21);
            this.lblSoPhieuDenBu.TabIndex = 5;
            this.lblSoPhieuDenBu.Text = "Số phiếu đền bù:";
            // 
            // txtSoPhieuDenBu
            // 
            this.txtSoPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoPhieuDenBu.Location = new System.Drawing.Point(155, 227);
            this.txtSoPhieuDenBu.Name = "txtSoPhieuDenBu";
            this.txtSoPhieuDenBu.Size = new System.Drawing.Size(110, 29);
            this.txtSoPhieuDenBu.TabIndex = 6;
            // 
            // lblMucDo
            // 
            this.lblMucDo.AutoSize = true;
            this.lblMucDo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMucDo.Location = new System.Drawing.Point(280, 230);
            this.lblMucDo.Name = "lblMucDo";
            this.lblMucDo.Size = new System.Drawing.Size(67, 21);
            this.lblMucDo.TabIndex = 7;
            this.lblMucDo.Text = "Mức độ:";
            // 
            // txtMucDo
            // 
            this.txtMucDo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMucDo.Location = new System.Drawing.Point(350, 227);
            this.txtMucDo.Name = "txtMucDo";
            this.txtMucDo.Size = new System.Drawing.Size(130, 29);
            this.txtMucDo.TabIndex = 8;
            // 
            // lblSoTienDenBu
            // 
            this.lblSoTienDenBu.AutoSize = true;
            this.lblSoTienDenBu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoTienDenBu.Location = new System.Drawing.Point(500, 230);
            this.lblSoTienDenBu.Name = "lblSoTienDenBu";
            this.lblSoTienDenBu.Size = new System.Drawing.Size(61, 21);
            this.lblSoTienDenBu.TabIndex = 9;
            this.lblSoTienDenBu.Text = "Số tiền:";
            // 
            // txtSoTienDenBu
            // 
            this.txtSoTienDenBu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoTienDenBu.Location = new System.Drawing.Point(570, 227);
            this.txtSoTienDenBu.Name = "txtSoTienDenBu";
            this.txtSoTienDenBu.Size = new System.Drawing.Size(115, 29);
            this.txtSoTienDenBu.TabIndex = 10;
            // 
            // btnLapPhieuDenBu
            // 
            this.btnLapPhieuDenBu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLapPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapPhieuDenBu.Location = new System.Drawing.Point(715, 225);
            this.btnLapPhieuDenBu.Name = "btnLapPhieuDenBu";
            this.btnLapPhieuDenBu.Size = new System.Drawing.Size(150, 32);
            this.btnLapPhieuDenBu.TabIndex = 11;
            this.btnLapPhieuDenBu.Text = "Lập phiếu đền bù";
            this.btnLapPhieuDenBu.UseVisualStyleBackColor = true;
            this.btnLapPhieuDenBu.Click += new System.EventHandler(this.btnLapPhieuDenBu_Click);
            // 
            // lblSoHoaDon
            // 
            this.lblSoHoaDon.AutoSize = true;
            this.lblSoHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoHoaDon.Location = new System.Drawing.Point(24, 275);
            this.lblSoHoaDon.Name = "lblSoHoaDon";
            this.lblSoHoaDon.Size = new System.Drawing.Size(92, 21);
            this.lblSoHoaDon.TabIndex = 12;
            this.lblSoHoaDon.Text = "Số hóa đơn:";
            // 
            // txtSoHoaDon
            // 
            this.txtSoHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoHoaDon.Location = new System.Drawing.Point(120, 272);
            this.txtSoHoaDon.Name = "txtSoHoaDon";
            this.txtSoHoaDon.Size = new System.Drawing.Size(125, 29);
            this.txtSoHoaDon.TabIndex = 13;
            // 
            // lblSoNgayTinhTien
            // 
            this.lblSoNgayTinhTien.AutoSize = true;
            this.lblSoNgayTinhTien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoNgayTinhTien.Location = new System.Drawing.Point(265, 275);
            this.lblSoNgayTinhTien.Name = "lblSoNgayTinhTien";
            this.lblSoNgayTinhTien.Size = new System.Drawing.Size(133, 21);
            this.lblSoNgayTinhTien.TabIndex = 14;
            this.lblSoNgayTinhTien.Text = "Số ngày tính tiền:";
            // 
            // txtSoNgayTinhTien
            // 
            this.txtSoNgayTinhTien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoNgayTinhTien.Location = new System.Drawing.Point(405, 272);
            this.txtSoNgayTinhTien.Name = "txtSoNgayTinhTien";
            this.txtSoNgayTinhTien.Size = new System.Drawing.Size(75, 29);
            this.txtSoNgayTinhTien.TabIndex = 15;
            this.txtSoNgayTinhTien.Text = "1";
            // 
            // btnLapHoaDon
            // 
            this.btnLapHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapHoaDon.Location = new System.Drawing.Point(505, 270);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(120, 32);
            this.btnLapHoaDon.TabIndex = 16;
            this.btnLapHoaDon.Text = "Lập hóa đơn";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;
            this.btnLapHoaDon.Click += new System.EventHandler(this.btnLapHoaDon_Click);
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.AllowUserToAddRows = false;
            this.dgvHoaDon.AllowUserToDeleteRows = false;
            this.dgvHoaDon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDon.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHoaDon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvHoaDon.ColumnHeadersHeight = 30;
            this.dgvHoaDon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colHD_HoaDon,
            this.colHD_PhieuDat,
            this.colHD_TienPhong,
            this.colHD_TienDichVu,
            this.colHD_TongTien,
            this.colHD_TrangThai});
            this.dgvHoaDon.EnableHeadersVisualStyles = false;
            this.dgvHoaDon.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvHoaDon.Location = new System.Drawing.Point(24, 315);
            this.dgvHoaDon.MultiSelect = false;
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.ReadOnly = true;
            this.dgvHoaDon.RowHeadersVisible = false;
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.RowTemplate.Height = 28;
            this.dgvHoaDon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoaDon.Size = new System.Drawing.Size(841, 150);
            this.dgvHoaDon.TabIndex = 17;
            this.dgvHoaDon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHoaDon_CellClick);
            // 
            // colHD_HoaDon
            // 
            this.colHD_HoaDon.DataPropertyName = "HoaDon";
            this.colHD_HoaDon.FillWeight = 85F;
            this.colHD_HoaDon.HeaderText = "Hóa đơn";
            this.colHD_HoaDon.MinimumWidth = 6;
            this.colHD_HoaDon.Name = "colHD_HoaDon";
            this.colHD_HoaDon.ReadOnly = true;
            // 
            // colHD_PhieuDat
            // 
            this.colHD_PhieuDat.DataPropertyName = "PhieuDat";
            this.colHD_PhieuDat.FillWeight = 90F;
            this.colHD_PhieuDat.HeaderText = "Phiếu đặt";
            this.colHD_PhieuDat.MinimumWidth = 6;
            this.colHD_PhieuDat.Name = "colHD_PhieuDat";
            this.colHD_PhieuDat.ReadOnly = true;
            // 
            // colHD_TienPhong
            // 
            this.colHD_TienPhong.DataPropertyName = "TienPhong";
            this.colHD_TienPhong.FillWeight = 100F;
            this.colHD_TienPhong.HeaderText = "Tiền phòng";
            this.colHD_TienPhong.MinimumWidth = 6;
            this.colHD_TienPhong.Name = "colHD_TienPhong";
            this.colHD_TienPhong.ReadOnly = true;
            // 
            // colHD_TienDichVu
            // 
            this.colHD_TienDichVu.DataPropertyName = "TienDichVu";
            this.colHD_TienDichVu.FillWeight = 100F;
            this.colHD_TienDichVu.HeaderText = "Tiền dịch vụ";
            this.colHD_TienDichVu.MinimumWidth = 6;
            this.colHD_TienDichVu.Name = "colHD_TienDichVu";
            this.colHD_TienDichVu.ReadOnly = true;
            // 
            // colHD_TongTien
            // 
            this.colHD_TongTien.DataPropertyName = "TongTien";
            this.colHD_TongTien.FillWeight = 100F;
            this.colHD_TongTien.HeaderText = "Tổng tiền";
            this.colHD_TongTien.MinimumWidth = 6;
            this.colHD_TongTien.Name = "colHD_TongTien";
            this.colHD_TongTien.ReadOnly = true;
            // 
            // colHD_TrangThai
            // 
            this.colHD_TrangThai.DataPropertyName = "TrangThai";
            this.colHD_TrangThai.FillWeight = 95F;
            this.colHD_TrangThai.HeaderText = "Trạng thái";
            this.colHD_TrangThai.MinimumWidth = 6;
            this.colHD_TrangThai.Name = "colHD_TrangThai";
            this.colHD_TrangThai.ReadOnly = true;
            // 
            // lblHinhThuc
            // 
            this.lblHinhThuc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHinhThuc.Location = new System.Drawing.Point(24, 485);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(81, 21);
            this.lblHinhThuc.TabIndex = 18;
            this.lblHinhThuc.Text = "Hình thức:";
            // 
            // txtHinhThuc
            // 
            this.txtHinhThuc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtHinhThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHinhThuc.Location = new System.Drawing.Point(110, 482);
            this.txtHinhThuc.Name = "txtHinhThuc";
            this.txtHinhThuc.Size = new System.Drawing.Size(125, 29);
            this.txtHinhThuc.TabIndex = 19;
            this.txtHinhThuc.Text = "Tiền mặt";
            // 
            // lblSoTienThanhToan
            // 
            this.lblSoTienThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSoTienThanhToan.AutoSize = true;
            this.lblSoTienThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoTienThanhToan.Location = new System.Drawing.Point(255, 485);
            this.lblSoTienThanhToan.Name = "lblSoTienThanhToan";
            this.lblSoTienThanhToan.Size = new System.Drawing.Size(61, 21);
            this.lblSoTienThanhToan.TabIndex = 20;
            this.lblSoTienThanhToan.Text = "Số tiền:";
            // 
            // txtSoTienThanhToan
            // 
            this.txtSoTienThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtSoTienThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoTienThanhToan.Location = new System.Drawing.Point(325, 482);
            this.txtSoTienThanhToan.Name = "txtSoTienThanhToan";
            this.txtSoTienThanhToan.Size = new System.Drawing.Size(110, 29);
            this.txtSoTienThanhToan.TabIndex = 21;
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThanhToan.Location = new System.Drawing.Point(460, 480);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(120, 33);
            this.btnThanhToan.TabIndex = 22;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnHoanTatTraPhong
            // 
            this.btnHoanTatTraPhong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnHoanTatTraPhong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnHoanTatTraPhong.Location = new System.Drawing.Point(600, 480);
            this.btnHoanTatTraPhong.Name = "btnHoanTatTraPhong";
            this.btnHoanTatTraPhong.Size = new System.Drawing.Size(155, 33);
            this.btnHoanTatTraPhong.TabIndex = 23;
            this.btnHoanTatTraPhong.Text = "Hoàn tất trả phòng";
            this.btnHoanTatTraPhong.UseVisualStyleBackColor = true;
            this.btnHoanTatTraPhong.Click += new System.EventHandler(this.btnHoanTatTraPhong_Click);
            // 
            // FrmTraPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(890, 530);
            this.Controls.Add(this.btnHoanTatTraPhong);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.txtSoTienThanhToan);
            this.Controls.Add(this.lblSoTienThanhToan);
            this.Controls.Add(this.txtHinhThuc);
            this.Controls.Add(this.lblHinhThuc);
            this.Controls.Add(this.dgvHoaDon);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.txtSoNgayTinhTien);
            this.Controls.Add(this.lblSoNgayTinhTien);
            this.Controls.Add(this.txtSoHoaDon);
            this.Controls.Add(this.lblSoHoaDon);
            this.Controls.Add(this.btnLapPhieuDenBu);
            this.Controls.Add(this.txtSoTienDenBu);
            this.Controls.Add(this.lblSoTienDenBu);
            this.Controls.Add(this.txtMucDo);
            this.Controls.Add(this.lblMucDo);
            this.Controls.Add(this.txtSoPhieuDenBu);
            this.Controls.Add(this.lblSoPhieuDenBu);
            this.Controls.Add(this.dgvDenBu);
            this.Controls.Add(this.dgvTienNghi);
            this.Controls.Add(this.dgvPhong);
            this.Controls.Add(this.txtPhieuDangO);
            this.Controls.Add(this.lblPhieuDangO);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmTraPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trả phòng - Đền bù - Hóa đơn - Thanh toán";
            this.Load += new System.EventHandler(this.FrmTraPhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDenBu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblPhieuDangO;
        private System.Windows.Forms.TextBox txtPhieuDangO;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colP_Phong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colP_DonGia;
        private System.Windows.Forms.DataGridView dgvTienNghi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTN_TienNghi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTN_Loai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTN_TinhTrang;
        private System.Windows.Forms.DataGridView dgvDenBu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDB_TienNghi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDB_MucDo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDB_SoTien;
        private System.Windows.Forms.Label lblSoPhieuDenBu;
        private System.Windows.Forms.TextBox txtSoPhieuDenBu;
        private System.Windows.Forms.Label lblMucDo;
        private System.Windows.Forms.TextBox txtMucDo;
        private System.Windows.Forms.Label lblSoTienDenBu;
        private System.Windows.Forms.TextBox txtSoTienDenBu;
        private System.Windows.Forms.Button btnLapPhieuDenBu;
        private System.Windows.Forms.Label lblSoHoaDon;
        private System.Windows.Forms.TextBox txtSoHoaDon;
        private System.Windows.Forms.Label lblSoNgayTinhTien;
        private System.Windows.Forms.TextBox txtSoNgayTinhTien;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.DataGridView dgvHoaDon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_HoaDon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_PhieuDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_TienPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_TienDichVu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_TongTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHD_TrangThai;
        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.TextBox txtHinhThuc;
        private System.Windows.Forms.Label lblSoTienThanhToan;
        private System.Windows.Forms.TextBox txtSoTienThanhToan;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnHoanTatTraPhong;
    }
}