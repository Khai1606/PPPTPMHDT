﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnNavKhuVuc = new System.Windows.Forms.Button();
            this.btnNavNhanVien = new System.Windows.Forms.Button();
            this.btnNavLoaiTN = new System.Windows.Forms.Button();
            this.btnNavDichVu = new System.Windows.Forms.Button();
            this.btnNavQuyDinh = new System.Windows.Forms.Button();
            this.lblMa = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblDonViVaiTro = new System.Windows.Forms.Label();
            this.txtDonViVaiTro = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.dgvDanhMuc = new System.Windows.Forms.DataGridView();
            this.colMa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLoaiVaiTro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGiaMuc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNavKhuVuc
            // 
            this.btnNavKhuVuc.AutoSize = true;
            this.btnNavKhuVuc.BackColor = System.Drawing.Color.Transparent;
            this.btnNavKhuVuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavKhuVuc.FlatAppearance.BorderSize = 0;
            this.btnNavKhuVuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavKhuVuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavKhuVuc.ForeColor = System.Drawing.Color.Black;
            this.btnNavKhuVuc.Location = new System.Drawing.Point(20, 18);
            this.btnNavKhuVuc.Name = "btnNavKhuVuc";
            this.btnNavKhuVuc.Size = new System.Drawing.Size(95, 31);
            this.btnNavKhuVuc.TabIndex = 0;
            this.btnNavKhuVuc.Text = "[ Khu vực ]";
            this.btnNavKhuVuc.UseVisualStyleBackColor = false;
            this.btnNavKhuVuc.Click += new System.EventHandler(this.btnNavKhuVuc_Click);
            // 
            // btnNavNhanVien
            // 
            this.btnNavNhanVien.AutoSize = true;
            this.btnNavNhanVien.BackColor = System.Drawing.Color.Transparent;
            this.btnNavNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavNhanVien.FlatAppearance.BorderSize = 0;
            this.btnNavNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavNhanVien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavNhanVien.ForeColor = System.Drawing.Color.Black;
            this.btnNavNhanVien.Location = new System.Drawing.Point(120, 18);
            this.btnNavNhanVien.Name = "btnNavNhanVien";
            this.btnNavNhanVien.Size = new System.Drawing.Size(105, 31);
            this.btnNavNhanVien.TabIndex = 1;
            this.btnNavNhanVien.Text = "[ Nhân viên ]";
            this.btnNavNhanVien.UseVisualStyleBackColor = false;
            this.btnNavNhanVien.Click += new System.EventHandler(this.btnNavNhanVien_Click);
            // 
            // btnNavLoaiTN
            // 
            this.btnNavLoaiTN.AutoSize = true;
            this.btnNavLoaiTN.BackColor = System.Drawing.Color.Transparent;
            this.btnNavLoaiTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavLoaiTN.FlatAppearance.BorderSize = 0;
            this.btnNavLoaiTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavLoaiTN.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavLoaiTN.ForeColor = System.Drawing.Color.Black;
            this.btnNavLoaiTN.Location = new System.Drawing.Point(230, 18);
            this.btnNavLoaiTN.Name = "btnNavLoaiTN";
            this.btnNavLoaiTN.Size = new System.Drawing.Size(125, 31);
            this.btnNavLoaiTN.TabIndex = 2;
            this.btnNavLoaiTN.Text = "[ Loại tiện nghi ]";
            this.btnNavLoaiTN.UseVisualStyleBackColor = false;
            this.btnNavLoaiTN.Click += new System.EventHandler(this.btnNavLoaiTN_Click);
            // 
            // btnNavDichVu
            // 
            this.btnNavDichVu.AutoSize = true;
            this.btnNavDichVu.BackColor = System.Drawing.Color.Transparent;
            this.btnNavDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavDichVu.FlatAppearance.BorderSize = 0;
            this.btnNavDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavDichVu.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnNavDichVu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnNavDichVu.Location = new System.Drawing.Point(360, 18);
            this.btnNavDichVu.Name = "btnNavDichVu";
            this.btnNavDichVu.Size = new System.Drawing.Size(95, 31);
            this.btnNavDichVu.TabIndex = 3;
            this.btnNavDichVu.Text = "[ Dịch vụ ]";
            this.btnNavDichVu.UseVisualStyleBackColor = false;
            this.btnNavDichVu.Click += new System.EventHandler(this.btnNavDichVu_Click);
            // 
            // btnNavQuyDinh
            // 
            this.btnNavQuyDinh.AutoSize = true;
            this.btnNavQuyDinh.BackColor = System.Drawing.Color.Transparent;
            this.btnNavQuyDinh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavQuyDinh.FlatAppearance.BorderSize = 0;
            this.btnNavQuyDinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavQuyDinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavQuyDinh.ForeColor = System.Drawing.Color.Black;
            this.btnNavQuyDinh.Location = new System.Drawing.Point(460, 18);
            this.btnNavQuyDinh.Name = "btnNavQuyDinh";
            this.btnNavQuyDinh.Size = new System.Drawing.Size(145, 31);
            this.btnNavQuyDinh.TabIndex = 4;
            this.btnNavQuyDinh.Text = "[ Quy định đền bù ]";
            this.btnNavQuyDinh.UseVisualStyleBackColor = false;
            this.btnNavQuyDinh.Click += new System.EventHandler(this.btnNavQuyDinh_Click);
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMa.Location = new System.Drawing.Point(24, 66);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(35, 21);
            this.lblMa.TabIndex = 5;
            this.lblMa.Text = "Mã:";
            // 
            // txtMa
            // 
            this.txtMa.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMa.Location = new System.Drawing.Point(68, 63);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(155, 29);
            this.txtMa.TabIndex = 6;
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTen.Location = new System.Drawing.Point(240, 66);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(36, 21);
            this.lblTen.TabIndex = 7;
            this.lblTen.Text = "Tên:";
            // 
            // txtTen
            // 
            this.txtTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTen.Location = new System.Drawing.Point(285, 63);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(200, 29);
            this.txtTen.TabIndex = 8;
            // 
            // lblDonViVaiTro
            // 
            this.lblDonViVaiTro.AutoSize = true;
            this.lblDonViVaiTro.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDonViVaiTro.Location = new System.Drawing.Point(500, 66);
            this.lblDonViVaiTro.Name = "lblDonViVaiTro";
            this.lblDonViVaiTro.Size = new System.Drawing.Size(123, 21);
            this.lblDonViVaiTro.TabIndex = 9;
            this.lblDonViVaiTro.Text = "Đơn vị / Vai trò:";
            // 
            // txtDonViVaiTro
            // 
            this.txtDonViVaiTro.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDonViVaiTro.Location = new System.Drawing.Point(630, 63);
            this.txtDonViVaiTro.Name = "txtDonViVaiTro";
            this.txtDonViVaiTro.Size = new System.Drawing.Size(130, 29);
            this.txtDonViVaiTro.TabIndex = 10;
            // 
            // btnThem
            // 
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThem.Location = new System.Drawing.Point(775, 61);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(95, 32);
            this.btnThem.TabIndex = 11;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // dgvDanhMuc
            // 
            this.dgvDanhMuc.AllowUserToAddRows = false;
            this.dgvDanhMuc.AllowUserToDeleteRows = false;
            this.dgvDanhMuc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDanhMuc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMuc.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDanhMuc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDanhMuc.ColumnHeadersHeight = 32;
            this.dgvDanhMuc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMa,
            this.colTen,
            this.colLoaiVaiTro,
            this.colDonVi,
            this.colDonGiaMuc});
            this.dgvDanhMuc.EnableHeadersVisualStyles = false;
            this.dgvDanhMuc.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvDanhMuc.Location = new System.Drawing.Point(24, 110);
            this.dgvDanhMuc.MultiSelect = false;
            this.dgvDanhMuc.Name = "dgvDanhMuc";
            this.dgvDanhMuc.ReadOnly = true;
            this.dgvDanhMuc.RowHeadersVisible = false;
            this.dgvDanhMuc.RowHeadersWidth = 51;
            this.dgvDanhMuc.RowTemplate.Height = 28;
            this.dgvDanhMuc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhMuc.Size = new System.Drawing.Size(846, 360);
            this.dgvDanhMuc.TabIndex = 12;
            this.dgvDanhMuc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhMuc_CellClick);
            // 
            // colMa
            // 
            this.colMa.DataPropertyName = "Ma";
            this.colMa.FillWeight = 85F;
            this.colMa.HeaderText = "Mã";
            this.colMa.MinimumWidth = 6;
            this.colMa.Name = "colMa";
            this.colMa.ReadOnly = true;
            // 
            // colTen
            // 
            this.colTen.DataPropertyName = "Ten";
            this.colTen.FillWeight = 120F;
            this.colTen.HeaderText = "Tên";
            this.colTen.MinimumWidth = 6;
            this.colTen.Name = "colTen";
            this.colTen.ReadOnly = true;
            // 
            // colLoaiVaiTro
            // 
            this.colLoaiVaiTro.DataPropertyName = "LoaiVaiTro";
            this.colLoaiVaiTro.FillWeight = 100F;
            this.colLoaiVaiTro.HeaderText = "Loại / Vai trò";
            this.colLoaiVaiTro.MinimumWidth = 6;
            this.colLoaiVaiTro.Name = "colLoaiVaiTro";
            this.colLoaiVaiTro.ReadOnly = true;
            // 
            // colDonVi
            // 
            this.colDonVi.DataPropertyName = "DonVi";
            this.colDonVi.FillWeight = 85F;
            this.colDonVi.HeaderText = "Đơn vị";
            this.colDonVi.MinimumWidth = 6;
            this.colDonVi.Name = "colDonVi";
            this.colDonVi.ReadOnly = true;
            // 
            // colDonGiaMuc
            // 
            this.colDonGiaMuc.DataPropertyName = "DonGiaMuc";
            this.colDonGiaMuc.FillWeight = 95F;
            this.colDonGiaMuc.HeaderText = "Đơn giá / Mức";
            this.colDonGiaMuc.MinimumWidth = 6;
            this.colDonGiaMuc.Name = "colDonGiaMuc";
            this.colDonGiaMuc.ReadOnly = true;
            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(895, 495);
            this.Controls.Add(this.dgvDanhMuc);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.txtDonViVaiTro);
            this.Controls.Add(this.lblDonViVaiTro);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.txtMa);
            this.Controls.Add(this.lblMa);
            this.Controls.Add(this.btnNavQuyDinh);
            this.Controls.Add(this.btnNavDichVu);
            this.Controls.Add(this.btnNavLoaiTN);
            this.Controls.Add(this.btnNavNhanVien);
            this.Controls.Add(this.btnNavKhuVuc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục khách sạn";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnNavKhuVuc;
        private System.Windows.Forms.Button btnNavNhanVien;
        private System.Windows.Forms.Button btnNavLoaiTN;
        private System.Windows.Forms.Button btnNavDichVu;
        private System.Windows.Forms.Button btnNavQuyDinh;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblDonViVaiTro;
        private System.Windows.Forms.TextBox txtDonViVaiTro;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dgvDanhMuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLoaiVaiTro;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGiaMuc;
    }
}