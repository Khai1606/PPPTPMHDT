﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // Đã bỏ toàn bộ phần gán icon ở đây
        }

        #region Các sự kiện mở Form
        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            new FrmDanhMuc().ShowDialog();
        }

        private void btnPhong_Click(object sender, EventArgs e)
        {
            new FrmPhongTienNghi().ShowDialog();
        }

        private void btnDatPhong_Click(object sender, EventArgs e)
        {
            new FrmDatPhong().ShowDialog();
        }

        private void btnDichVu_Click(object sender, EventArgs e)
        {
            new FrmDichVu().ShowDialog();
        }

        private void btnTraPhong_Click(object sender, EventArgs e)
        {
            new FrmTraPhong().ShowDialog();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            new FrmThongKe().ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát khỏi hệ thống?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        #endregion
    }
}