﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmPhongTienNghi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnNavPhong = new System.Windows.Forms.Button();
            this.btnNavTienNghi = new System.Windows.Forms.Button();
            this.btnNavLapDat = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.dgvDanhSach = new System.Windows.Forms.DataGridView();
            this.colPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKhu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSucChua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblPhieuLD = new System.Windows.Forms.Label();
            this.txtMaPhieuLD = new System.Windows.Forms.TextBox();
            this.lblTienNghiLD = new System.Windows.Forms.Label();
            this.txtMaTNLD = new System.Windows.Forms.TextBox();
            this.lblPhongLD = new System.Windows.Forms.Label();
            this.txtPhongLD = new System.Windows.Forms.TextBox();
            this.lblTinhTrangLD = new System.Windows.Forms.Label();
            this.txtTinhTrangLD = new System.Windows.Forms.TextBox();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNavPhong
            // 
            this.btnNavPhong.AutoSize = true;
            this.btnNavPhong.BackColor = System.Drawing.Color.Transparent;
            this.btnNavPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavPhong.FlatAppearance.BorderSize = 0;
            this.btnNavPhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavPhong.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnNavPhong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnNavPhong.Location = new System.Drawing.Point(20, 15);
            this.btnNavPhong.Name = "btnNavPhong";
            this.btnNavPhong.Size = new System.Drawing.Size(75, 31);
            this.btnNavPhong.TabIndex = 0;
            this.btnNavPhong.Text = "[Phòng]";
            this.btnNavPhong.UseVisualStyleBackColor = false;
            this.btnNavPhong.Click += new System.EventHandler(this.btnNavPhong_Click);
            // 
            // btnNavTienNghi
            // 
            this.btnNavTienNghi.AutoSize = true;
            this.btnNavTienNghi.BackColor = System.Drawing.Color.Transparent;
            this.btnNavTienNghi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavTienNghi.FlatAppearance.BorderSize = 0;
            this.btnNavTienNghi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavTienNghi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavTienNghi.ForeColor = System.Drawing.Color.Black;
            this.btnNavTienNghi.Location = new System.Drawing.Point(100, 15);
            this.btnNavTienNghi.Name = "btnNavTienNghi";
            this.btnNavTienNghi.Size = new System.Drawing.Size(90, 31);
            this.btnNavTienNghi.TabIndex = 1;
            this.btnNavTienNghi.Text = "[Tiện nghi]";
            this.btnNavTienNghi.UseVisualStyleBackColor = false;
            this.btnNavTienNghi.Click += new System.EventHandler(this.btnNavTienNghi_Click);
            // 
            // btnNavLapDat
            // 
            this.btnNavLapDat.AutoSize = true;
            this.btnNavLapDat.BackColor = System.Drawing.Color.Transparent;
            this.btnNavLapDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavLapDat.FlatAppearance.BorderSize = 0;
            this.btnNavLapDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavLapDat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavLapDat.ForeColor = System.Drawing.Color.Black;
            this.btnNavLapDat.Location = new System.Drawing.Point(195, 15);
            this.btnNavLapDat.Name = "btnNavLapDat";
            this.btnNavLapDat.Size = new System.Drawing.Size(155, 31);
            this.btnNavLapDat.TabIndex = 2;
            this.btnNavLapDat.Text = "[Lắp đặt / luân chuyển]";
            this.btnNavLapDat.UseVisualStyleBackColor = false;
            this.btnNavLapDat.Click += new System.EventHandler(this.btnNavLapDat_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lbl1.Location = new System.Drawing.Point(24, 60);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(80, 21);
            this.lbl1.TabIndex = 3;
            this.lbl1.Text = "Số phòng:";
            // 
            // txt1
            // 
            this.txt1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txt1.Location = new System.Drawing.Point(110, 57);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(130, 29);
            this.txt1.TabIndex = 4;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lbl2.Location = new System.Drawing.Point(255, 60);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(70, 21);
            this.lbl2.TabIndex = 5;
            this.lbl2.Text = "Khu vực:";
            // 
            // txt2
            // 
            this.txt2.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txt2.Location = new System.Drawing.Point(330, 57);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(135, 29);
            this.txt2.TabIndex = 6;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lbl3.Location = new System.Drawing.Point(480, 60);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(117, 21);
            this.lbl3.TabIndex = 7;
            this.lbl3.Text = "Số người tối đa:";
            // 
            // txt3
            // 
            this.txt3.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txt3.Location = new System.Drawing.Point(605, 57);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(80, 29);
            this.txt3.TabIndex = 8;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lbl4.Location = new System.Drawing.Point(700, 60);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(112, 21);
            this.lbl4.TabIndex = 9;
            this.lbl4.Text = "Đơn giá/ngày:";
            // 
            // txt4
            // 
            this.txt4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txt4.Location = new System.Drawing.Point(815, 57);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(95, 29);
            this.txt4.TabIndex = 10;
            // 
            // dgvDanhSach
            // 
            this.dgvDanhSach.AllowUserToAddRows = false;
            this.dgvDanhSach.AllowUserToDeleteRows = false;
            this.dgvDanhSach.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDanhSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSach.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDanhSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDanhSach.ColumnHeadersHeight = 32;
            this.dgvDanhSach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPhong,
            this.colKhu,
            this.colSucChua,
            this.colDonGia,
            this.colTrangThai});
            this.dgvDanhSach.EnableHeadersVisualStyles = false;
            this.dgvDanhSach.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvDanhSach.Location = new System.Drawing.Point(24, 105);
            this.dgvDanhSach.MultiSelect = false;
            this.dgvDanhSach.Name = "dgvDanhSach";
            this.dgvDanhSach.ReadOnly = true;
            this.dgvDanhSach.RowHeadersVisible = false;
            this.dgvDanhSach.RowHeadersWidth = 51;
            this.dgvDanhSach.RowTemplate.Height = 28;
            this.dgvDanhSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhSach.Size = new System.Drawing.Size(886, 290);
            this.dgvDanhSach.TabIndex = 11;
            this.dgvDanhSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhSach_CellClick);
            // 
            // colPhong
            // 
            this.colPhong.DataPropertyName = "Phong";
            this.colPhong.FillWeight = 90F;
            this.colPhong.HeaderText = "Phòng";
            this.colPhong.MinimumWidth = 6;
            this.colPhong.Name = "colPhong";
            this.colPhong.ReadOnly = true;
            // 
            // colKhu
            // 
            this.colKhu.DataPropertyName = "Khu";
            this.colKhu.FillWeight = 110F;
            this.colKhu.HeaderText = "Khu";
            this.colKhu.MinimumWidth = 6;
            this.colKhu.Name = "colKhu";
            this.colKhu.ReadOnly = true;
            // 
            // colSucChua
            // 
            this.colSucChua.DataPropertyName = "SucChua";
            this.colSucChua.FillWeight = 90F;
            this.colSucChua.HeaderText = "Sức chứa";
            this.colSucChua.MinimumWidth = 6;
            this.colSucChua.Name = "colSucChua";
            this.colSucChua.ReadOnly = true;
            // 
            // colDonGia
            // 
            this.colDonGia.DataPropertyName = "DonGia";
            this.colDonGia.FillWeight = 100F;
            this.colDonGia.HeaderText = "Đơn giá";
            this.colDonGia.MinimumWidth = 6;
            this.colDonGia.Name = "colDonGia";
            this.colDonGia.ReadOnly = true;
            // 
            // colTrangThai
            // 
            this.colTrangThai.DataPropertyName = "TrangThai";
            this.colTrangThai.FillWeight = 100F;
            this.colTrangThai.HeaderText = "Trạng thái";
            this.colTrangThai.MinimumWidth = 6;
            this.colTrangThai.Name = "colTrangThai";
            this.colTrangThai.ReadOnly = true;
            // 
            // lblPhieuLD
            // 
            this.lblPhieuLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPhieuLD.AutoSize = true;
            this.lblPhieuLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhieuLD.Location = new System.Drawing.Point(24, 417);
            this.lblPhieuLD.Name = "lblPhieuLD";
            this.lblPhieuLD.Size = new System.Drawing.Size(107, 21);
            this.lblPhieuLD.TabIndex = 12;
            this.lblPhieuLD.Text = "Phiếu lắp đặt:";
            // 
            // txtMaPhieuLD
            // 
            this.txtMaPhieuLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaPhieuLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaPhieuLD.Location = new System.Drawing.Point(135, 414);
            this.txtMaPhieuLD.Name = "txtMaPhieuLD";
            this.txtMaPhieuLD.Size = new System.Drawing.Size(120, 29);
            this.txtMaPhieuLD.TabIndex = 13;
            // 
            // lblTienNghiLD
            // 
            this.lblTienNghiLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTienNghiLD.AutoSize = true;
            this.lblTienNghiLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTienNghiLD.Location = new System.Drawing.Point(275, 417);
            this.lblTienNghiLD.Name = "lblTienNghiLD";
            this.lblTienNghiLD.Size = new System.Drawing.Size(77, 21);
            this.lblTienNghiLD.TabIndex = 14;
            this.lblTienNghiLD.Text = "Tiện nghi:";
            // 
            // txtMaTNLD
            // 
            this.txtMaTNLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaTNLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaTNLD.Location = new System.Drawing.Point(355, 414);
            this.txtMaTNLD.Name = "txtMaTNLD";
            this.txtMaTNLD.Size = new System.Drawing.Size(110, 29);
            this.txtMaTNLD.TabIndex = 15;
            // 
            // lblPhongLD
            // 
            this.lblPhongLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPhongLD.AutoSize = true;
            this.lblPhongLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhongLD.Location = new System.Drawing.Point(485, 417);
            this.lblPhongLD.Name = "lblPhongLD";
            this.lblPhongLD.Size = new System.Drawing.Size(58, 21);
            this.lblPhongLD.TabIndex = 16;
            this.lblPhongLD.Text = "Phòng:";
            // 
            // txtPhongLD
            // 
            this.txtPhongLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPhongLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhongLD.Location = new System.Drawing.Point(545, 414);
            this.txtPhongLD.Name = "txtPhongLD";
            this.txtPhongLD.Size = new System.Drawing.Size(100, 29);
            this.txtPhongLD.TabIndex = 17;
            // 
            // lblTinhTrangLD
            // 
            this.lblTinhTrangLD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTinhTrangLD.AutoSize = true;
            this.lblTinhTrangLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTinhTrangLD.Location = new System.Drawing.Point(665, 417);
            this.lblTinhTrangLD.Name = "lblTinhTrangLD";
            this.lblTinhTrangLD.Size = new System.Drawing.Size(83, 21);
            this.lblTinhTrangLD.TabIndex = 18;
            this.lblTinhTrangLD.Text = "Tình trạng:";
            // 
            // txtTinhTrangLD
            // 
            this.txtTinhTrangLD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTinhTrangLD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTinhTrangLD.Location = new System.Drawing.Point(750, 414);
            this.txtTinhTrangLD.Name = "txtTinhTrangLD";
            this.txtTinhTrangLD.Size = new System.Drawing.Size(160, 29);
            this.txtTinhTrangLD.TabIndex = 19;
            this.txtTinhTrangLD.Text = "Tốt";
            // 
            // btnLapPhieu
            // 
            this.btnLapPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLapPhieu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapPhieu.Location = new System.Drawing.Point(750, 452);
            this.btnLapPhieu.Name = "btnLapPhieu";
            this.btnLapPhieu.Size = new System.Drawing.Size(160, 34);
            this.btnLapPhieu.TabIndex = 20;
            this.btnLapPhieu.Text = "Lập phiếu";
            this.btnLapPhieu.UseVisualStyleBackColor = true;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);
            // 
            // FrmPhongTienNghi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(935, 500);
            this.Controls.Add(this.btnLapPhieu);
            this.Controls.Add(this.txtTinhTrangLD);
            this.Controls.Add(this.lblTinhTrangLD);
            this.Controls.Add(this.txtPhongLD);
            this.Controls.Add(this.lblPhongLD);
            this.Controls.Add(this.txtMaTNLD);
            this.Controls.Add(this.lblTienNghiLD);
            this.Controls.Add(this.txtMaPhieuLD);
            this.Controls.Add(this.lblPhieuLD);
            this.Controls.Add(this.dgvDanhSach);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnNavLapDat);
            this.Controls.Add(this.btnNavTienNghi);
            this.Controls.Add(this.btnNavPhong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPhongTienNghi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phòng - Tiện nghi - Phiếu lắp đặt";
            this.Load += new System.EventHandler(this.FrmPhongTienNghi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnNavPhong;
        private System.Windows.Forms.Button btnNavTienNghi;
        private System.Windows.Forms.Button btnNavLapDat;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.DataGridView dgvDanhSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKhu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSucChua;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrangThai;
        private System.Windows.Forms.Label lblPhieuLD;
        private System.Windows.Forms.TextBox txtMaPhieuLD;
        private System.Windows.Forms.Label lblTienNghiLD;
        private System.Windows.Forms.TextBox txtMaTNLD;
        private System.Windows.Forms.Label lblPhongLD;
        private System.Windows.Forms.TextBox txtPhongLD;
        private System.Windows.Forms.Label lblTinhTrangLD;
        private System.Windows.Forms.TextBox txtTinhTrangLD;
        private System.Windows.Forms.Button btnLapPhieu;
    }
}