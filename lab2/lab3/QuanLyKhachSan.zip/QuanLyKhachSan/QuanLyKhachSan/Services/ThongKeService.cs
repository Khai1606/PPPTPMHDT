﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class ThongKeService
    {
        // 1. Tổng hợp các chỉ số số lượng phiếu, phòng và doanh thu
        public (int PhieuDat, int DangO, int HoaDon, decimal DoanhThuHD, decimal TongDenBu)
            LayTongHopSoLieu(DateTime tuNgay, DateTime denNgay)
        {
            DateTime start = tuNgay.Date;
            DateTime end = denNgay.Date.AddDays(1).AddTicks(-1);

            SqlParameter[] TaoPars() => new[]
            {
                new SqlParameter("@TuNgay", start),
                new SqlParameter("@DenNgay", end)
            };

            // Tổng số phiếu đặt trong kỳ
            int phieuDat = Convert.ToInt32(Db.Scalar(
                "SELECT COUNT(*) FROM PhieuDatPhong WHERE NgayDat >= @TuNgay AND NgayDat <= @DenNgay", TaoPars()));

            // Số phòng đang ở hiện tại
            int dangO = Convert.ToInt32(Db.Scalar(
                "SELECT COUNT(*) FROM PhieuDatPhong WHERE TrangThai = N'Đang ở'"));

            // Tổng số hóa đơn đã xuất
            int hoaDon = Convert.ToInt32(Db.Scalar(
                "SELECT COUNT(*) FROM HoaDon WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay", TaoPars()));

            // Doanh thu hóa đơn
            decimal doanhThu = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(SUM(TongTien), 0) FROM HoaDon WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay", TaoPars()));

            // Tổng tiền đền bù
            decimal tongDenBu = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(SUM(GiaDenBu), 0) FROM PhieuDenBu WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay", TaoPars()));

            return (phieuDat, dangO, hoaDon, doanhThu, tongDenBu);
        }

        // 2. Thống kê chi tiết dịch vụ đã sử dụng theo khoảng ngày
        public DataTable LayThongKeDichVu(DateTime tuNgay, DateTime denNgay)
        {
            DateTime start = tuNgay.Date;
            DateTime end = denNgay.Date.AddDays(1).AddTicks(-1);

            string sql = @"SELECT dv.MaDichVu AS MaDV, 
                                  dv.TenDichVu, 
                                  SUM(ct.SoLuong) AS TongSoLuong, 
                                  SUM(ct.ThanhTien) AS TongTien
                           FROM ChiTietSuDungDichVu ct
                           JOIN DichVu dv ON ct.MaDichVu = dv.MaDichVu
                           WHERE ct.NgaySuDung >= @TuNgay AND ct.NgaySuDung <= @DenNgay
                           GROUP BY dv.MaDichVu, dv.TenDichVu
                           ORDER BY TongTien DESC";

            return Db.Query(sql,
                new SqlParameter("@TuNgay", start),
                new SqlParameter("@DenNgay", end));
        }
    }
}