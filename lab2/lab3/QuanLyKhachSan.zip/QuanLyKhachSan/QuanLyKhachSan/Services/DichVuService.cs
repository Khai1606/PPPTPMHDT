﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class DichVuService
    {
        // Lấy danh sách phiếu chi tiết dịch vụ hiển thị lên DataGridView
        public DataTable LayDanhSachSuDungDichVu()
        {
            string sql = @"SELECT ct.MaPhieuDat AS SoPhieu, 
                                  pd.SoPhong AS Phong, 
                                  ct.NgaySuDung AS Ngay, 
                                  dv.TenDichVu AS DichVu, 
                                  ct.SoLuong, 
                                  ct.DonGia, 
                                  ct.ThanhTien 
                           FROM ChiTietSuDungDichVu ct
                           JOIN PhieuDatPhong pd ON ct.MaPhieuDat = pd.MaPhieuDat
                           JOIN DichVu dv ON ct.MaDichVu = dv.MaDichVu
                           ORDER BY ct.NgaySuDung DESC, ct.MaChiTiet DESC";
            return Db.Query(sql);
        }

        // Tự động tìm số phòng từ mã phiếu đặt
        public string LayPhongTheoPhieuDat(string maPhieu)
        {
            object p = Db.Scalar("SELECT SoPhong FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            return p != null ? p.ToString() : "";
        }

        // BR07: Cùng một dịch vụ dùng nhiều lần trong ngày được cộng dồn thành một lần
        public (bool Ok, string Msg) GhiNhanDichVu(string maPhieu, string soPhong, string tenDichVu, int soLuong, DateTime ngayDung)
        {
            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(tenDichVu))
                return (false, "Vui lòng nhập đầy đủ Số phiếu lưu trú và Tên dịch vụ.");

            if (soLuong <= 0)
                return (false, "Số lượng dịch vụ sử dụng phải lớn hơn 0.");

            // Kiểm tra phiếu đặt phòng có tồn tại không
            object checkPhieu = Db.Scalar("SELECT SoPhong FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            if (checkPhieu == null)
            {
                // Nếu chưa có trong CSDL (ví dụ chạy thử mã DP001 mẫu), tự động hỗ trợ khởi tạo phiếu đặt đang ở
                string phongGhiNhan = string.IsNullOrWhiteSpace(soPhong) ? "A101" : soPhong.Trim();
                int daCoPhong = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM Phong WHERE SoPhong = @p", new SqlParameter("@p", phongGhiNhan)));
                if (daCoPhong == 0)
                {
                    object firstKV = Db.Scalar("SELECT TOP 1 MaKhuVuc FROM KhuVuc");
                    string maKV = firstKV != null ? firstKV.ToString() : "KV01";
                    Db.Execute("INSERT INTO Phong (SoPhong, MaKhuVuc, SoNguoiToiDa, DonGiaNgay, TrangThaiPhong) VALUES (@p, @kv, 2, 600000, N'Đang ở')",
                        new SqlParameter("@p", phongGhiNhan), new SqlParameter("@kv", maKV));
                }

                object firstKH = Db.Scalar("SELECT TOP 1 MaKhach FROM KhachHang");
                string maKH = firstKH != null ? firstKH.ToString() : "KH01";

                Db.Execute(@"INSERT INTO PhieuDatPhong (MaPhieuDat, SoPhong, MaKhach, NgayDat, NgayNhan, NgayTraDuKien, TienCoc, TrangThai)
                             VALUES (@ma, @p, @kh, GETDATE(), GETDATE(), DATEADD(day, 1, GETDATE()), 500000, N'Đang ở')",
                    new SqlParameter("@ma", maPhieu.Trim()), new SqlParameter("@p", phongGhiNhan), new SqlParameter("@kh", maKH));
            }

            // Tìm dịch vụ theo tên, nếu chưa có thì thêm mới vào danh mục
            object dvObj = Db.Scalar("SELECT MaDichVu FROM DichVu WHERE TenDichVu = @ten OR MaDichVu = @ten", new SqlParameter("@ten", tenDichVu.Trim()));
            string maDV = dvObj?.ToString();
            decimal donGia = 0;

            if (string.IsNullOrEmpty(maDV))
            {
                maDV = "DV" + DateTime.Now.ToString("mmss");
                donGia = 50000;
                Db.Execute("INSERT INTO DichVu (MaDichVu, TenDichVu, DonGia) VALUES (@ma, @ten, @gia)",
                    new SqlParameter("@ma", maDV), new SqlParameter("@ten", tenDichVu.Trim()), new SqlParameter("@gia", donGia));
            }
            else
            {
                donGia = Convert.ToDecimal(Db.Scalar("SELECT DonGia FROM DichVu WHERE MaDichVu = @ma", new SqlParameter("@ma", maDV)));
                if (donGia <= 0) donGia = 50000;
            }

            // Kiểm tra quy tắc BR07: trùng dịch vụ trong ngày
            string sqlCheck = @"SELECT MaChiTiet, SoLuong FROM ChiTietSuDungDichVu 
                                WHERE MaPhieuDat = @ma AND MaDichVu = @dv AND CAST(NgaySuDung AS DATE) = CAST(@ngay AS DATE)";
            DataTable dtExist = Db.Query(sqlCheck,
                new SqlParameter("@ma", maPhieu.Trim()),
                new SqlParameter("@dv", maDV),
                new SqlParameter("@ngay", ngayDung.Date));

            if (dtExist.Rows.Count > 0)
            {
                // CỘNG DỒN SỐ LƯỢNG VÀ THÀNH TIỀN THEO QUY TẮC BR07
                int maCT = Convert.ToInt32(dtExist.Rows[0]["MaChiTiet"]);
                int slCu = Convert.ToInt32(dtExist.Rows[0]["SoLuong"]);
                int slMoi = slCu + soLuong;
                decimal thanhTienMoi = slMoi * donGia;

                string sqlUpdate = "UPDATE ChiTietSuDungDichVu SET SoLuong = @sl, ThanhTien = @tt WHERE MaChiTiet = @maCT";
                Db.Execute(sqlUpdate,
                    new SqlParameter("@sl", slMoi),
                    new SqlParameter("@tt", thanhTienMoi),
                    new SqlParameter("@maCT", maCT));

                return (true, $"Quy tắc BR07: Dịch vụ '{tenDichVu}' đã được dùng trong ngày -> Hệ thống đã tự động cộng dồn thành tổng số lượng: {slMoi}!");
            }
            else
            {
                // TẠO LẦN DÙNG MỚI
                decimal thanhTien = soLuong * donGia;
                string sqlInsert = @"INSERT INTO ChiTietSuDungDichVu (MaPhieuDat, MaDichVu, NgaySuDung, SoLuong, DonGia, ThanhTien) 
                                     VALUES (@ma, @dv, @ngay, @sl, @gia, @tt)";
                Db.Execute(sqlInsert,
                    new SqlParameter("@ma", maPhieu.Trim()),
                    new SqlParameter("@dv", maDV),
                    new SqlParameter("@ngay", ngayDung.Date),
                    new SqlParameter("@sl", soLuong),
                    new SqlParameter("@gia", donGia),
                    new SqlParameter("@tt", thanhTien));

                return (true, "Ghi nhận sử dụng dịch vụ thành công.");
            }
        }
    }
}