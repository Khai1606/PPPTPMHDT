﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class DatPhongService
    {
        public DatPhongService()
        {
            // Tự động thêm cột KenhDat nếu bảng PhieuDatPhong chưa có để phục vụ giao diện
            try
            {
                Db.Execute(@"IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('PhieuDatPhong') AND name = 'KenhDat')
                             ALTER TABLE PhieuDatPhong ADD KenhDat NVARCHAR(50) DEFAULT N'Trực tiếp';");
            }
            catch { }
        }

        #region 1. Nghiệp vụ Khách hàng (Bảng KhachHang)
        public DataTable LayDanhSachKhachHang()
        {
            string sql = "SELECT MaKhach, HoTen, ISNULL(CCCD, '') AS CCCD, ISNULL(SoDienThoai, '') AS SoDienThoai, ISNULL(Email, '') AS Email FROM KhachHang ORDER BY MaKhach DESC";
            return Db.Query(sql);
        }

        public string SinhMaKhachTuDong()
        {
            int soLuong = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM KhachHang"));
            return string.Format("KH{0:D2}", soLuong + 1);
        }

        public (bool Ok, string Msg) LuuKhachHang(string maKhach, string hoTen, string cccd, string soDienThoai)
        {
            if (string.IsNullOrWhiteSpace(maKhach) || string.IsNullOrWhiteSpace(hoTen))
                return (false, "Vui lòng nhập đầy đủ Mã khách và Họ tên.");

            int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM KhachHang WHERE MaKhach = @ma", new SqlParameter("@ma", maKhach.Trim())));

            if (daCo > 0)
            {
                string sqlUpdate = "UPDATE KhachHang SET HoTen = @ten, CCCD = @cccd, SoDienThoai = @sdt WHERE MaKhach = @ma";
                Db.Execute(sqlUpdate,
                    new SqlParameter("@ten", hoTen.Trim()),
                    new SqlParameter("@cccd", cccd ?? ""),
                    new SqlParameter("@sdt", soDienThoai ?? ""),
                    new SqlParameter("@ma", maKhach.Trim()));
                return (true, "Cập nhật thông tin khách hàng thành công.");
            }
            else
            {
                string sqlInsert = "INSERT INTO KhachHang (MaKhach, HoTen, CCCD, SoDienThoai) VALUES (@ma, @ten, @cccd, @sdt)";
                Db.Execute(sqlInsert,
                    new SqlParameter("@ma", maKhach.Trim()),
                    new SqlParameter("@ten", hoTen.Trim()),
                    new SqlParameter("@cccd", cccd ?? ""),
                    new SqlParameter("@sdt", soDienThoai ?? ""));
                return (true, "Thêm khách hàng mới thành công.");
            }
        }
        #endregion

        #region 2. Nghiệp vụ Đặt phòng (Bảng PhieuDatPhong - BR02, BR05)
        public DataTable LayDanhSachPhongTrong()
        {
            string sql = @"SELECT p.SoPhong AS Phong, kv.TenKhuVuc AS Khu, p.SoNguoiToiDa AS SucChua, p.DonGiaNgay AS DonGia 
                           FROM Phong p 
                           JOIN KhuVuc kv ON p.MaKhuVuc = kv.MaKhuVuc 
                           WHERE p.TrangThaiPhong <> N'Đang ở'
                           ORDER BY p.SoPhong";
            return Db.Query(sql);
        }

        public DataTable LayDanhSachPhieuDat(bool chiLayChoNhanPhong = false)
        {
            string sql = @"SELECT pd.MaPhieuDat AS SoPhieu, 
                                  kh.HoTen AS Khach, 
                                  pd.NgayNhan, 
                                  pd.NgayTraDuKien, 
                                  pd.TienCoc AS Coc, 
                                  ISNULL(pd.KenhDat, N'Trực tiếp') AS Kenh, 
                                  pd.TrangThai 
                           FROM PhieuDatPhong pd 
                           JOIN KhachHang kh ON pd.MaKhach = kh.MaKhach ";

            if (chiLayChoNhanPhong)
                sql += " WHERE pd.TrangThai = N'Đã đặt' ";

            sql += " ORDER BY pd.NgayDat DESC";
            return Db.Query(sql);
        }

        public string SinhMaPhieuDatTuDong()
        {
            int soLuong = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDatPhong"));
            return string.Format("DP{0:D3}", soLuong + 1);
        }

        public (bool Ok, string Msg) DatPhong(
            string maPhieu,
            string tenKhach,
            string kenhDat,
            decimal tienCoc,
            DateTime ngayNhan,
            DateTime ngayTra,
            List<(string SoPhong, int SoNguoi, decimal DonGia)> dsPhongChon)
        {
            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(tenKhach))
                return (false, "Vui lòng nhập đầy đủ Số phiếu đặt và Tên khách.");

            if (dsPhongChon == null || dsPhongChon.Count == 0)
                return (false, "Vui lòng nhấp đúp chọn ít nhất một phòng trống.");

            int daCoPhieu = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim())));
            if (daCoPhieu > 0)
                return (false, $"Mã phiếu đặt '{maPhieu}' đã tồn tại.");

            // Tìm hoặc tạo khách hàng
            object khObj = Db.Scalar("SELECT TOP 1 MaKhach FROM KhachHang WHERE HoTen = @ten", new SqlParameter("@ten", tenKhach.Trim()));
            string maKhach = khObj != null ? khObj.ToString() : null;

            if (string.IsNullOrEmpty(maKhach))
            {
                maKhach = SinhMaKhachTuDong();
                Db.Execute("INSERT INTO KhachHang (MaKhach, HoTen) VALUES (@ma, @ten)",
                    new SqlParameter("@ma", maKhach), new SqlParameter("@ten", tenKhach.Trim()));
            }

            // Lấy 1 nhân viên mặc định để liên kết khóa ngoại MaNV
            object nvObj = Db.Scalar("SELECT TOP 1 MaNV FROM NhanVien");
            string maNV = nvObj != null ? nvObj.ToString() : "NV01";

            foreach (var item in dsPhongChon)
            {
                // BR02: Sức chứa tối đa
                int sucChua = Convert.ToInt32(Db.Scalar("SELECT SoNguoiToiDa FROM Phong WHERE SoPhong = @p", new SqlParameter("@p", item.SoPhong)));
                if (item.SoNguoi > sucChua)
                    return (false, $"Phòng {item.SoPhong} chỉ chứa tối đa {sucChua} người (Bạn đang chọn {item.SoNguoi} người - Vi phạm BR02).");

                // BR05: Trùng lịch đặt
                string sqlCheck = @"SELECT COUNT(*) FROM PhieuDatPhong 
                                   WHERE SoPhong = @p 
                                     AND TrangThai IN (N'Đã đặt', N'Đang ở')
                                     AND NOT (NgayTraDuKien <= @nhan OR NgayNhan >= @tra)";
                int trung = Convert.ToInt32(Db.Scalar(sqlCheck,
                    new SqlParameter("@p", item.SoPhong),
                    new SqlParameter("@nhan", ngayNhan.Date),
                    new SqlParameter("@tra", ngayTra.Date)));

                if (trung > 0)
                    return (false, $"Phòng {item.SoPhong} đã có khách đặt hoặc đang ở trong khoảng thời gian này (Vi phạm BR05).");

                string sqlInsert = @"INSERT INTO PhieuDatPhong (MaPhieuDat, SoPhong, MaKhach, MaNV, NgayDat, NgayNhan, NgayTraDuKien, TienCoc, KenhDat, TrangThai)
                                     VALUES (@ma, @p, @kh, @nv, GETDATE(), @nhan, @tra, @coc, @kenh, N'Đã đặt')";
                Db.Execute(sqlInsert,
                    new SqlParameter("@ma", maPhieu.Trim()),
                    new SqlParameter("@p", item.SoPhong),
                    new SqlParameter("@kh", maKhach),
                    new SqlParameter("@nv", maNV),
                    new SqlParameter("@nhan", ngayNhan.Date),
                    new SqlParameter("@tra", ngayTra.Date),
                    new SqlParameter("@coc", tienCoc),
                    new SqlParameter("@kenh", string.IsNullOrWhiteSpace(kenhDat) ? "Trực tiếp" : kenhDat.Trim()));

                Db.Execute("UPDATE Phong SET TrangThaiPhong = N'Đã đặt' WHERE SoPhong = @p", new SqlParameter("@p", item.SoPhong));
            }

            return (true, "Lập phiếu đặt phòng thành công.");
        }
        #endregion

        #region 3. Nghiệp vụ Nhận phòng & Người lưu trú (Bảng NguoiLuuTru - BR06)
        public DataTable LayDanhSachNguoiLuuTru(string maPhieu)
        {
            string sql = "SELECT MaLuuTru, MaPhieuDat, HoTen, CCCD, QuocTich FROM NguoiLuuTru WHERE MaPhieuDat = @ma OR @ma = '' ORDER BY MaLuuTru DESC";
            return Db.Query(sql, new SqlParameter("@ma", maPhieu ?? ""));
        }

        public (bool Ok, string Msg) NhanPhongVaLuuNguoiLuuTru(string maPhieu, string hoTenNguoiO, string cccd, string quocTich)
        {
            if (string.IsNullOrWhiteSpace(maPhieu))
                return (false, "Vui lòng chọn phiếu đặt cần nhận phòng.");

            object pObj = Db.Scalar("SELECT SoPhong FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            if (pObj == null)
                return (false, "Không tìm thấy phiếu đặt phòng.");

            string soPhong = pObj.ToString();

            // Cập nhật trạng thái phiếu và phòng sang 'Đang ở'
            Db.Execute("UPDATE PhieuDatPhong SET TrangThai = N'Đang ở' WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            Db.Execute("UPDATE Phong SET TrangThaiPhong = N'Đang ở' WHERE SoPhong = @p", new SqlParameter("@p", soPhong));

            // BR06: Ghi nhận người lưu trú thực tế vào bảng NguoiLuuTru
            if (!string.IsNullOrWhiteSpace(hoTenNguoiO) && !string.IsNullOrWhiteSpace(cccd))
            {
                string sqlInsertNLT = @"INSERT INTO NguoiLuuTru (MaPhieuDat, CCCD, HoTen, QuocTich) 
                                       VALUES (@ma, @cccd, @ten, @qt)";
                Db.Execute(sqlInsertNLT,
                    new SqlParameter("@ma", maPhieu.Trim()),
                    new SqlParameter("@cccd", cccd.Trim()),
                    new SqlParameter("@ten", hoTenNguoiO.Trim()),
                    new SqlParameter("@qt", string.IsNullOrWhiteSpace(quocTich) ? "Việt Nam" : quocTich.Trim()));
            }

            return (true, $"Nhận phòng thành công! Khách đã chính thức lưu trú tại phòng {soPhong}.");
        }
        #endregion
    }
}