﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;
using QuanLyThuVien.Models;

namespace QuanLyThuVien.Services
{
    public class MuonTraService
    {
        // 1. Kiểm tra điều kiện mượn sách của độc giả
        public KetQuaXuLy KiemTraDieuKienMuon(string maDocGia)
        {
            // Kiểm tra thẻ hợp lệ
            string sqlThe = @"SELECT TOP 1 MaThe, HanSuDung, DaDongLePhi, TrangThai 
                             FROM TheDocGia 
                             WHERE MaDocGia = @MaDG AND TrangThai = 1";
            DataTable dtThe = Db.Query(sqlThe, new[] { new SqlParameter("@MaDG", maDocGia) });
            if (dtThe.Rows.Count == 0)
                return KetQuaXuLy.Loi("Độc giả chưa có thẻ thư viện đang hoạt động.");

            DataRow the = dtThe.Rows[0];
            if (!Convert.ToBoolean(the["DaDongLePhi"]))
                return KetQuaXuLy.Loi("Thẻ độc giả chưa đóng lệ phí.");

            DateTime hanSD = Convert.ToDateTime(the["HanSuDung"]);
            if (hanSD < DateTime.Today)
                return KetQuaXuLy.Loi($"Thẻ thư viện đã hết hạn từ ngày {hanSD:dd/MM/yyyy}.");

            // Kiểm tra số sách đang mượn chưa trả (Tối đa 3 cuốn)
            string sqlDangMuon = @"SELECT COUNT(*) 
                                  FROM ChiTietPhieuMuon ct
                                  INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                                  WHERE pm.MaDocGia = @MaDG AND ct.NgayTraThucTe IS NULL";
            int dangMuon = (int)Db.Scalar(sqlDangMuon, new[] { new SqlParameter("@MaDG", maDocGia) });
            if (dangMuon >= 3)
                return KetQuaXuLy.Loi($"Độc giả đang mượn {dangMuon} cuốn sách chưa trả (Quy định tối đa 3 cuốn).");

            return KetQuaXuLy.Ok("Độc giả đủ điều kiện mượn sách.");
        }

        // 2. Lập phiếu mượn (Transaction trừ tồn kho sách)
        public KetQuaXuLy LapPhieuMuon(string maPhieu, string maDocGia, string maNhanVien, DateTime ngayMuon, DateTime ngayHenTra, List<string> dsMaSach)
        {
            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(maDocGia) || string.IsNullOrWhiteSpace(maNhanVien))
                return KetQuaXuLy.Loi("Vui lòng điền đầy đủ thông tin phiếu mượn.");

            if (dsMaSach == null || dsMaSach.Count == 0)
                return KetQuaXuLy.Loi("Phiếu mượn phải có ít nhất 1 cuốn sách.");

            if (ngayHenTra < ngayMuon)
                return KetQuaXuLy.Loi("Ngày hẹn trả không thể trước ngày mượn.");

            // Kiểm tra điều kiện thẻ & số lượng đang mượn
            var kt = KiemTraDieuKienMuon(maDocGia);
            if (!kt.ThanhCong) return kt;

            using (SqlConnection conn = Db.OpenConnection())
            using (SqlTransaction tran = conn.BeginTransaction())
            {
                try
                {
                    // Tạo phiếu mượn
                    string sqlPM = @"INSERT INTO PhieuMuon (MaPhieuMuon, MaDocGia, MaNhanVien, NgayMuon, NgayHenTra)
                                    VALUES (@MaPM, @MaDG, @MaNV, @NgayMuon, @NgayHenTra)";
                    using (SqlCommand cmd = new SqlCommand(sqlPM, conn, tran))
                    {
                        cmd.Parameters.AddWithValue("@MaPM", maPhieu);
                        cmd.Parameters.AddWithValue("@MaDG", maDocGia);
                        cmd.Parameters.AddWithValue("@MaNV", maNhanVien);
                        cmd.Parameters.AddWithValue("@NgayMuon", ngayMuon);
                        cmd.Parameters.AddWithValue("@NgayHenTra", ngayHenTra);
                        cmd.ExecuteNonQuery();
                    }

                    int stt = 1;
                    foreach (var maSach in dsMaSach)
                    {
                        // Kiểm tra số lượng sách hiện có
                        string sqlCheckSL = "SELECT SoLuongHienCo FROM DauSach WHERE MaDauSach = @MaDS";
                        using (SqlCommand cmd = new SqlCommand(sqlCheckSL, conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@MaDS", maSach);
                            object objSL = cmd.ExecuteScalar();
                            int sl = (objSL != null && objSL != DBNull.Value) ? Convert.ToInt32(objSL) : 0;
                            if (sl <= 0)
                            {
                                tran.Rollback();
                                return KetQuaXuLy.Loi($"Sách [{maSach}] hiện đã hết, không thể mượn.");
                            }
                        }

                        // Thêm chi tiết phiếu mượn
                        string maCT = $"{maPhieu}_{stt++}";
                        string sqlCT = @"INSERT INTO ChiTietPhieuMuon (MaChiTiet, MaPhieuMuon, MaDauSach, NgayTraThucTe, TinhTrangTra)
                                        VALUES (@MaCT, @MaPM, @MaDS, NULL, NULL)";
                        using (SqlCommand cmd = new SqlCommand(sqlCT, conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@MaCT", maCT);
                            cmd.Parameters.AddWithValue("@MaPM", maPhieu);
                            cmd.Parameters.AddWithValue("@MaDS", maSach);
                            cmd.ExecuteNonQuery();
                        }

                        // Trừ tồn kho SoLuongHienCo
                        string sqlTruSL = "UPDATE DauSach SET SoLuongHienCo = SoLuongHienCo - 1 WHERE MaDauSach = @MaDS";
                        using (SqlCommand cmd = new SqlCommand(sqlTruSL, conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@MaDS", maSach);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    tran.Commit();
                    return KetQuaXuLy.Ok("Lập phiếu mượn thành công!");
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    return KetQuaXuLy.Loi("Lỗi khi lập phiếu mượn: " + ex.Message);
                }
            }
        }

        // 3. Lấy danh sách sách đang mượn chưa trả
        public DataTable LayDanhSachDangMuon(string tuKhoa = "")
        {
            string sql = @"SELECT ct.MaChiTiet, ct.MaPhieuMuon, pm.MaDocGia, (dg.Ho + ' ' + dg.Ten) AS HoTenDocGia,
                                  ds.MaDauSach, ds.TenSach, pm.NgayMuon, pm.NgayHenTra, pm.MaNhanVien
                           FROM ChiTietPhieuMuon ct
                           INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                           INNER JOIN DocGia dg ON pm.MaDocGia = dg.MaDocGia
                           INNER JOIN DauSach ds ON ct.MaDauSach = ds.MaDauSach
                           WHERE ct.NgayTraThucTe IS NULL
                             AND (@TuKhoa = '' OR pm.MaDocGia LIKE @Pat OR dg.Ten LIKE @Pat OR ct.MaPhieuMuon LIKE @Pat)";

            SqlParameter[] pars = {
                new SqlParameter("@TuKhoa", tuKhoa ?? ""),
                new SqlParameter("@Pat", "%" + (tuKhoa ?? "") + "%")
            };
            return Db.Query(sql, pars);
        }

        // 4. Trả sách & lập phạt nếu có
        public KetQuaXuLy TraSach(string maChiTiet, string maDauSach, string maNhanVien, DateTime ngayTra, string tinhTrang, decimal phiPhat, string lyDoPhat)
        {
            using (SqlConnection conn = Db.OpenConnection())
            using (SqlTransaction tran = conn.BeginTransaction())
            {
                try
                {
                    // Cập nhật chi tiết trả
                    string sqlTra = @"UPDATE ChiTietPhieuMuon 
                                     SET NgayTraThucTe = @NgayTra, TinhTrangTra = @TinhTrang 
                                     WHERE MaChiTiet = @MaCT";
                    using (SqlCommand cmd = new SqlCommand(sqlTra, conn, tran))
                    {
                        cmd.Parameters.AddWithValue("@NgayTra", ngayTra);
                        cmd.Parameters.AddWithValue("@TinhTrang", tinhTrang ?? "Nguyên vẹn");
                        cmd.Parameters.AddWithValue("@MaCT", maChiTiet);
                        cmd.ExecuteNonQuery();
                    }

                    // Nếu không phải là "Mất sách", cộng lại số lượng hiện có
                    if (tinhTrang != "Mất sách")
                    {
                        string sqlCong = "UPDATE DauSach SET SoLuongHienCo = SoLuongHienCo + 1 WHERE MaDauSach = @MaDS";
                        using (SqlCommand cmd = new SqlCommand(sqlCong, conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@MaDS", maDauSach);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Nếu có phạt
                    if (phiPhat > 0)
                    {
                        string maPhat = "PP" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        string sqlPhat = @"INSERT INTO PhieuPhat (MaPhieuPhat, MaChiTiet, MaNhanVien, NgayPhat, LyDo, PhiPhat)
                                          VALUES (@MaPP, @MaCT, @MaNV, @NgayPhat, @LyDo, @Phi)";
                        using (SqlCommand cmd = new SqlCommand(sqlPhat, conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@MaPP", maPhat);
                            cmd.Parameters.AddWithValue("@MaCT", maChiTiet);
                            cmd.Parameters.AddWithValue("@MaNV", maNhanVien);
                            cmd.Parameters.AddWithValue("@NgayPhat", ngayTra);
                            cmd.Parameters.AddWithValue("@LyDo", lyDoPhat ?? "Quá hạn / Hư hỏng sách");
                            cmd.Parameters.AddWithValue("@Phi", phiPhat);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    tran.Commit();
                    return KetQuaXuLy.Ok("Xác nhận trả sách thành công!");
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    return KetQuaXuLy.Loi("Lỗi khi trả sách: " + ex.Message);
                }
            }
        }
    }
}