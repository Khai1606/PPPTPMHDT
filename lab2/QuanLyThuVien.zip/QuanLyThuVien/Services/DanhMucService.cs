﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;
using QuanLyThuVien.Models;

namespace QuanLyThuVien.Services
{
    public class DanhMucService
    {
        #region Nghiệp vụ Nhân Viên
        public DataTable LayDanhSachNhanVien()
        {
            return Db.Query("SELECT MaNhanVien, Ho, Ten, Phai, NgaySinh, ChucVu, SoDienThoai FROM NhanVien");
        }

        public KetQuaXuLy ThemNhanVien(NhanVien nv)
        {
            if (string.IsNullOrWhiteSpace(nv.MaNhanVien) || string.IsNullOrWhiteSpace(nv.Ten))
                return KetQuaXuLy.Loi("Mã nhân viên và tên không được để trống.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM NhanVien WHERE MaNhanVien = @Ma",
                                       new[] { new SqlParameter("@Ma", nv.MaNhanVien) });
            if (count > 0)
                return KetQuaXuLy.Loi("Mã nhân viên này đã tồn tại.");

            string sql = @"INSERT INTO NhanVien (MaNhanVien, Ho, Ten, Phai, NgaySinh, ChucVu, SoDienThoai)
                           VALUES (@Ma, @Ho, @Ten, @Phai, @NgaySinh, @ChucVu, @SDT)";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", nv.MaNhanVien),
                new SqlParameter("@Ho", nv.Ho ?? ""),
                new SqlParameter("@Ten", nv.Ten),
                new SqlParameter("@Phai", (object)nv.Phai ?? DBNull.Value),
                new SqlParameter("@NgaySinh", nv.NgaySinh),
                new SqlParameter("@ChucVu", (object)nv.ChucVu ?? DBNull.Value),
                new SqlParameter("@SDT", (object)nv.SoDienThoai ?? DBNull.Value)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Thêm nhân viên thành công.");
        }

        public KetQuaXuLy CapNhatNhanVien(NhanVien nv)
        {
            string sql = @"UPDATE NhanVien 
                           SET Ho = @Ho, Ten = @Ten, Phai = @Phai, NgaySinh = @NgaySinh, 
                               ChucVu = @ChucVu, SoDienThoai = @SDT
                           WHERE MaNhanVien = @Ma";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", nv.MaNhanVien),
                new SqlParameter("@Ho", nv.Ho ?? ""),
                new SqlParameter("@Ten", nv.Ten),
                new SqlParameter("@Phai", (object)nv.Phai ?? DBNull.Value),
                new SqlParameter("@NgaySinh", nv.NgaySinh),
                new SqlParameter("@ChucVu", (object)nv.ChucVu ?? DBNull.Value),
                new SqlParameter("@SDT", (object)nv.SoDienThoai ?? DBNull.Value)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Cập nhật nhân viên thành công.");
        }

        public KetQuaXuLy XoaNhanVien(string maNV)
        {
            int count = (int)Db.Scalar("SELECT COUNT(*) FROM PhieuMuon WHERE MaNhanVien = @Ma",
new[] { new SqlParameter("@Ma", maNV) });
            if (count > 0)
                return KetQuaXuLy.Loi("Nhân viên này đã lập phiếu mượn, không thể xóa.");

            Db.Execute("DELETE FROM NhanVien WHERE MaNhanVien = @Ma", new[] { new SqlParameter("@Ma", maNV) });
            return KetQuaXuLy.Ok("Xóa nhân viên thành công.");
        }
        #endregion

        #region Nghiệp vụ Thể Loại
        public DataTable LayDanhSachTheLoai()
        {
            return Db.Query("SELECT MaTheLoai, TenTheLoai FROM TheLoai");
        }

        public KetQuaXuLy ThemTheLoai(string maTL, string tenTL)
        {
            if (string.IsNullOrWhiteSpace(maTL) || string.IsNullOrWhiteSpace(tenTL))
                return KetQuaXuLy.Loi("Mã thể loại và tên thể loại không được để trống.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM TheLoai WHERE MaTheLoai = @Ma",
                                       new[] { new SqlParameter("@Ma", maTL) });
            if (count > 0)
                return KetQuaXuLy.Loi("Mã thể loại đã tồn tại.");

            Db.Execute("INSERT INTO TheLoai (MaTheLoai, TenTheLoai) VALUES (@Ma, @Ten)",
                       new[] { new SqlParameter("@Ma", maTL), new SqlParameter("@Ten", tenTL) });
            return KetQuaXuLy.Ok("Thêm thể loại thành công.");
        }

        public KetQuaXuLy CapNhatTheLoai(string maTL, string tenTL)
        {
            Db.Execute("UPDATE TheLoai SET TenTheLoai = @Ten WHERE MaTheLoai = @Ma",
                       new[] { new SqlParameter("@Ma", maTL), new SqlParameter("@Ten", tenTL) });
            return KetQuaXuLy.Ok("Cập nhật thể loại thành công.");
        }

        public KetQuaXuLy XoaTheLoai(string maTL)
        {
            int count = (int)Db.Scalar("SELECT COUNT(*) FROM DauSach WHERE MaTheLoai = @Ma",
                                       new[] { new SqlParameter("@Ma", maTL) });
            if (count > 0)
                return KetQuaXuLy.Loi("Thể loại này đang chứa đầu sách, không thể xóa.");

            Db.Execute("DELETE FROM TheLoai WHERE MaTheLoai = @Ma", new[] { new SqlParameter("@Ma", maTL) });
            return KetQuaXuLy.Ok("Xóa thể loại thành công.");
        }
        #endregion

        #region Nghiệp vụ Nhà Xuất Bản
        public DataTable LayDanhSachNhaXuatBan()
        {
            return Db.Query("SELECT MaNhaXuatBan, DiaChi, SoDienThoai FROM NhaXuatBan");
        }

        public KetQuaXuLy ThemNhaXuatBan(string maNXB, string diaChi, string sdt)
        {
            if (string.IsNullOrWhiteSpace(maNXB))
                return KetQuaXuLy.Loi("Mã nhà xuất bản không được để trống.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM NhaXuatBan WHERE MaNhaXuatBan = @Ma",
                                       new[] { new SqlParameter("@Ma", maNXB) });
            if (count > 0)
                return KetQuaXuLy.Loi("Mã nhà xuất bản đã tồn tại.");

            string sql = "INSERT INTO NhaXuatBan (MaNhaXuatBan, DiaChi, SoDienThoai) VALUES (@Ma, @DiaChi, @SDT)";
            Db.Execute(sql, new[] {
                new SqlParameter("@Ma", maNXB),
                new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                new SqlParameter("@SDT", (object)sdt ?? DBNull.Value)
            });
            return KetQuaXuLy.Ok("Thêm nhà xuất bản thành công.");
        }

        public KetQuaXuLy CapNhatNhaXuatBan(string maNXB, string diaChi, string sdt)
        {
            string sql = "UPDATE NhaXuatBan SET DiaChi = @DiaChi, SoDienThoai = @SDT WHERE MaNhaXuatBan = @Ma";
            Db.Execute(sql, new[] {
                new SqlParameter("@Ma", maNXB),
                new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                new SqlParameter("@SDT", (object)sdt ?? DBNull.Value)
            });
            return KetQuaXuLy.Ok("Cập nhật nhà xuất bản thành công.");
        }

        public KetQuaXuLy XoaNhaXuatBan(string maNXB)
        {
            int count = (int)Db.Scalar("SELECT COUNT(*) FROM DauSach WHERE MaNhaXuatBan = @Ma",
                                       new[] { new SqlParameter("@Ma", maNXB) });
            if (count > 0)
                return KetQuaXuLy.Loi("Nhà xuất bản này đang có sách lưu trong kho, không thể xóa.");

            Db.Execute("DELETE FROM NhaXuatBan WHERE MaNhaXuatBan = @Ma", new[] { new SqlParameter("@Ma", maNXB) });
            return KetQuaXuLy.Ok("Xóa nhà xuất bản thành công.");
        }
        #endregion
    }
}