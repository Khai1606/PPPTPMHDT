﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;
using QuanLyThuVien.Models;

namespace QuanLyThuVien.Services
{
    public class SachService
    {
        public DataTable LayDanhSachDauSach(string tuKhoa = "")
        {
            string sql = @"SELECT ds.MaDauSach, ds.TenSach, tl.TenTheLoai, ds.MaTheLoai, 
                                  ds.MaNhaXuatBan, ds.NamXuatBan, ds.SoLuongHienCo
                           FROM DauSach ds
                           LEFT JOIN TheLoai tl ON ds.MaTheLoai = tl.MaTheLoai
                           WHERE (@TuKhoa = '' OR ds.MaDauSach LIKE @Pattern OR ds.TenSach LIKE @Pattern)";

            SqlParameter[] pars = {
                new SqlParameter("@TuKhoa", tuKhoa ?? ""),
                new SqlParameter("@Pattern", "%" + (tuKhoa ?? "") + "%")
            };
            return Db.Query(sql, pars);
        }

        public KetQuaXuLy ThemDauSach(DauSach ds)
        {
            if (string.IsNullOrWhiteSpace(ds.MaDauSach) || string.IsNullOrWhiteSpace(ds.TenSach))
                return KetQuaXuLy.Loi("Mã sách và tên sách không được để trống.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM DauSach WHERE MaDauSach = @Ma",
                                       new[] { new SqlParameter("@Ma", ds.MaDauSach) });
            if (count > 0)
                return KetQuaXuLy.Loi("Mã đầu sách này đã tồn tại.");

            string sql = @"INSERT INTO DauSach (MaDauSach, TenSach, NamXuatBan, SoLuongHienCo, MaTheLoai, MaNhaXuatBan)
                           VALUES (@Ma, @Ten, @Nam, @SL, @MaTL, @MaNXB)";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", ds.MaDauSach),
                new SqlParameter("@Ten", ds.TenSach),
                new SqlParameter("@Nam", (object)ds.NamXuatBan ?? DBNull.Value),
                new SqlParameter("@SL", ds.SoLuongHienCo),
                new SqlParameter("@MaTL", ds.MaTheLoai),
                new SqlParameter("@MaNXB", ds.MaNhaXuatBan)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Thêm đầu sách thành công.");
        }

        public KetQuaXuLy CapNhatDauSach(DauSach ds)
        {
            string sql = @"UPDATE DauSach 
                           SET TenSach = @Ten, NamXuatBan = @Nam, SoLuongHienCo = @SL, 
                               MaTheLoai = @MaTL, MaNhaXuatBan = @MaNXB
                           WHERE MaDauSach = @Ma";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", ds.MaDauSach),
                new SqlParameter("@Ten", ds.TenSach),
                new SqlParameter("@Nam", (object)ds.NamXuatBan ?? DBNull.Value),
                new SqlParameter("@SL", ds.SoLuongHienCo),
                new SqlParameter("@MaTL", ds.MaTheLoai),
                new SqlParameter("@MaNXB", ds.MaNhaXuatBan)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Cập nhật đầu sách thành công.");
        }

        public KetQuaXuLy XoaDauSach(string maDauSach)
        {
            // Kiểm tra xem sách đã từng có trong phiếu mượn chưa
            int countMuon = (int)Db.Scalar("SELECT COUNT(*) FROM ChiTietPhieuMuon WHERE MaDauSach = @Ma",
                                           new[] { new SqlParameter("@Ma", maDauSach) });
            if (countMuon > 0)
                return KetQuaXuLy.Loi("Không thể xóa đầu sách này vì đã có dữ liệu mượn trả trong hệ thống.");

            string sql = "DELETE FROM DauSach WHERE MaDauSach = @Ma";
            Db.Execute(sql, new[] { new SqlParameter("@Ma", maDauSach) });
            return KetQuaXuLy.Ok("Xóa đầu sách thành công.");
        }
    }
}