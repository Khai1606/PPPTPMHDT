﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;
using QuanLyThuVien.Models;

namespace QuanLyThuVien.Services
{
    public class DocGiaService
    {
        public DataTable LayDanhSachDocGiaVaThe()
        {
            string sql = @"SELECT dg.MaDocGia, dg.Ho, dg.Ten, dg.Phai, dg.NgaySinh, dg.SoDienThoai, 
                                  dg.DiaChi, dg.Email, dg.Anh3x4,
                                  the.MaThe, the.NgayCap, the.HanSuDung, the.DaDongLePhi, the.TrangThai
                           FROM DocGia dg
                           LEFT JOIN TheDocGia the ON dg.MaDocGia = the.MaDocGia AND the.TrangThai = 1";
            return Db.Query(sql);
        }

        public DataTable LayDanhSachDocGia()
        {
            return Db.Query("SELECT MaDocGia, Ho, Ten, Phai, NgaySinh, SoDienThoai, DiaChi, Email, Anh3x4 FROM DocGia");
        }

        public KetQuaXuLy ThemDocGia(DocGia dg)
        {
            if (string.IsNullOrWhiteSpace(dg.MaDocGia) || string.IsNullOrWhiteSpace(dg.Ten))
                return KetQuaXuLy.Loi("Mã độc giả và tên không được để trống.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM DocGia WHERE MaDocGia = @Ma",
                                       new[] { new SqlParameter("@Ma", dg.MaDocGia) });
            if (count > 0)
                return KetQuaXuLy.Loi("Mã độc giả này đã tồn tại.");

            string sql = @"INSERT INTO DocGia (MaDocGia, Ho, Ten, NgaySinh, Phai, SoDienThoai, DiaChi, Email, Anh3x4)
                           VALUES (@Ma, @Ho, @Ten, @NgaySinh, @Phai, @SDT, @DiaChi, @Email, @Anh)";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", dg.MaDocGia),
                new SqlParameter("@Ho", dg.Ho ?? ""),
                new SqlParameter("@Ten", dg.Ten),
                new SqlParameter("@NgaySinh", (object)dg.NgaySinh ?? DBNull.Value),
                new SqlParameter("@Phai", (object)dg.Phai ?? DBNull.Value),
                new SqlParameter("@SDT", (object)dg.SoDienThoai ?? DBNull.Value),
                new SqlParameter("@DiaChi", (object)dg.DiaChi ?? DBNull.Value),
                new SqlParameter("@Email", (object)dg.Email ?? DBNull.Value),
                new SqlParameter("@Anh", (object)dg.Anh3x4 ?? DBNull.Value)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Thêm độc giả thành công.");
        }

        public KetQuaXuLy CapNhatDocGia(DocGia dg)
        {
            string sql = @"UPDATE DocGia 
                           SET Ho = @Ho, Ten = @Ten, NgaySinh = @NgaySinh, Phai = @Phai,
                               SoDienThoai = @SDT, DiaChi = @DiaChi, Email = @Email, Anh3x4 = @Anh
                           WHERE MaDocGia = @Ma";

            SqlParameter[] pars = {
                new SqlParameter("@Ma", dg.MaDocGia),
                new SqlParameter("@Ho", dg.Ho ?? ""),
new SqlParameter("@Ten", dg.Ten),
                new SqlParameter("@NgaySinh", (object)dg.NgaySinh ?? DBNull.Value),
                new SqlParameter("@Phai", (object)dg.Phai ?? DBNull.Value),
                new SqlParameter("@SDT", (object)dg.SoDienThoai ?? DBNull.Value),
                new SqlParameter("@DiaChi", (object)dg.DiaChi ?? DBNull.Value),
                new SqlParameter("@Email", (object)dg.Email ?? DBNull.Value),
                new SqlParameter("@Anh", (object)dg.Anh3x4 ?? DBNull.Value)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Cập nhật thông tin độc giả thành công.");
        }

        public KetQuaXuLy CapThe(string maDocGia, DateTime ngayCap, DateTime hanSuDung, bool daDongLePhi)
        {
            if (string.IsNullOrWhiteSpace(maDocGia))
                return KetQuaXuLy.Loi("Vui lòng chọn độc giả để cấp thẻ.");

            // Hủy kích hoạt thẻ cũ nếu có (đảm bảo BR02: độc giả chỉ có 1 thẻ có giá trị)
            Db.Execute("UPDATE TheDocGia SET TrangThai = 0 WHERE MaDocGia = @MaDG",
                       new[] { new SqlParameter("@MaDG", maDocGia) });

            string maThe = "THE" + DateTime.Now.ToString("yyyyMMddHHmmss");
            string sql = @"INSERT INTO TheDocGia (MaThe, MaDocGia, NgayCap, HanSuDung, DaDongLePhi, TrangThai)
                           VALUES (@MaThe, @MaDG, @NgayCap, @HanSD, @LePhi, 1)";

            SqlParameter[] pars = {
                new SqlParameter("@MaThe", maThe),
                new SqlParameter("@MaDG", maDocGia),
                new SqlParameter("@NgayCap", ngayCap),
                new SqlParameter("@HanSD", hanSuDung),
                new SqlParameter("@LePhi", daDongLePhi)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Cấp thẻ thư viện mới thành công.");
        }

        public KetQuaXuLy GiaHanThe(string maDocGia, DateTime hanMoi, bool daDongLePhi)
        {
            if (string.IsNullOrWhiteSpace(maDocGia))
                return KetQuaXuLy.Loi("Vui lòng chọn độc giả để gia hạn thẻ.");

            int count = (int)Db.Scalar("SELECT COUNT(*) FROM TheDocGia WHERE MaDocGia = @MaDG AND TrangThai = 1",
                                       new[] { new SqlParameter("@MaDG", maDocGia) });
            if (count == 0)
                return KetQuaXuLy.Loi("Độc giả chưa có thẻ đang hoạt động để gia hạn. Vui lòng bấm Cấp thẻ.");

            string sql = @"UPDATE TheDocGia 
                           SET HanSuDung = @HanMoi, DaDongLePhi = @LePhi 
                           WHERE MaDocGia = @MaDG AND TrangThai = 1";

            SqlParameter[] pars = {
                new SqlParameter("@HanMoi", hanMoi),
                new SqlParameter("@LePhi", daDongLePhi),
                new SqlParameter("@MaDG", maDocGia)
            };

            Db.Execute(sql, pars);
            return KetQuaXuLy.Ok("Gia hạn thẻ thư viện thành công.");
        }
    }
}