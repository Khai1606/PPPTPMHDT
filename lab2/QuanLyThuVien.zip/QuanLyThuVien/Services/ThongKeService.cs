﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;

namespace QuanLyThuVien.Services
{
    public class ThongKeService
    {
        // Lấy toàn bộ 4 chỉ số thống kê và tổng tiền phạt theo khoảng thời gian
        public (int LuotMuon, int SachQuaHan, int SachMat, int SachHuHong, decimal TongPhat) LaySoLieuBaoCao(DateTime tuNgay, DateTime denNgay)
        {
            DateTime start = tuNgay.Date;
            DateTime end = denNgay.Date.AddDays(1).AddTicks(-1);

            SqlParameter[] pars = {
                new SqlParameter("@TuNgay", start),
                new SqlParameter("@DenNgay", end)
            };

            // 1. Lượt sách mượn
            string sqlMuon = @"SELECT COUNT(*) 
                               FROM ChiTietPhieuMuon ct
                               INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                               WHERE pm.NgayMuon >= @TuNgay AND pm.NgayMuon <= @DenNgay";
            int luotMuon = Convert.ToInt32(Db.Scalar(sqlMuon, pars));

            // 2. Sách quá hạn
            string sqlQuaHan = @"SELECT COUNT(*) 
                                 FROM ChiTietPhieuMuon ct
                                 INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                                 WHERE pm.NgayMuon >= @TuNgay AND pm.NgayMuon <= @DenNgay
                                   AND (ct.NgayTraThucTe > pm.NgayHenTra OR (ct.NgayTraThucTe IS NULL AND pm.NgayHenTra < GETDATE()))";
            int quaHan = Convert.ToInt32(Db.Scalar(sqlQuaHan, pars));

            // 3. Sách mất
            string sqlMat = @"SELECT COUNT(*) 
                              FROM ChiTietPhieuMuon ct
                              INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                              WHERE (pm.NgayMuon >= @TuNgay AND pm.NgayMuon <= @DenNgay)
                                AND ct.TinhTrangTra = N'Mất sách'";
            int mat = Convert.ToInt32(Db.Scalar(sqlMat, pars));

            // 4. Sách hư hỏng
            string sqlHuHong = @"SELECT COUNT(*) 
                                 FROM ChiTietPhieuMuon ct
                                 INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                                 WHERE (pm.NgayMuon >= @TuNgay AND pm.NgayMuon <= @DenNgay)
                                   AND (ct.TinhTrangTra LIKE N'%hỏng%' OR ct.TinhTrangTra LIKE N'%rách%')";
            int huHong = Convert.ToInt32(Db.Scalar(sqlHuHong, pars));

            // 5. Tổng phí phạt
            string sqlPhat = @"SELECT ISNULL(SUM(PhiPhat), 0) 
                               FROM PhieuPhat 
                               WHERE NgayPhat >= @TuNgay AND NgayPhat <= @DenNgay";
            decimal tongPhat = Convert.ToDecimal(Db.Scalar(sqlPhat, pars));

            return (luotMuon, quaHan, mat, huHong, tongPhat);
        }
        // Lấy chi tiết các phiếu phạt theo khoảng thời gian
        public DataTable LayChiTietPhieuPhat(DateTime tuNgay, DateTime denNgay)
        {
            DateTime start = tuNgay.Date;
            DateTime end = denNgay.Date.AddDays(1).AddTicks(-1);

            string sql = @"SELECT pp.MaPhieuPhat, pp.NgayPhat, (dg.Ho + ' ' + dg.Ten) AS HoTenDocGia, 
                                  ct.MaDauSach, pp.LyDo, pp.PhiPhat
                           FROM PhieuPhat pp
                           INNER JOIN ChiTietPhieuMuon ct ON pp.MaChiTiet = ct.MaChiTiet
                           INNER JOIN PhieuMuon pm ON ct.MaPhieuMuon = pm.MaPhieuMuon
                           INNER JOIN DocGia dg ON pm.MaDocGia = dg.MaDocGia
                           WHERE pp.NgayPhat >= @TuNgay AND pp.NgayPhat <= @DenNgay
                           ORDER BY pp.NgayPhat DESC";

            SqlParameter[] pars = {
                new SqlParameter("@TuNgay", start),
                new SqlParameter("@DenNgay", end)
            };
            return Db.Query(sql, pars);
        }
    }
}