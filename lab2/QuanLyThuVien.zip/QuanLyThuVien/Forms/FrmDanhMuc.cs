﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyThuVien.Models;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private readonly DanhMucService _danhMucService = new DanhMucService();

        public FrmDanhMuc()
        {
            InitializeComponent();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            ChonTabNhanVien();
        }

        #region Chuyển đổi tab
        private void lnkNhanVien_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChonTabNhanVien();
        }

        private void lnkTheLoai_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChonTabTheLoai();
        }

        private void lnkNXB_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChonTabNXB();
        }

        private void ChonTabNhanVien()
        {
            pnlNhanVien.Visible = true;
            pnlTheLoai.Visible = false;
            pnlNXB.Visible = false;

            lnkNhanVien.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lnkTheLoai.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lnkNXB.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

            LoadNhanVien();
        }

        private void ChonTabTheLoai()
        {
            pnlNhanVien.Visible = false;
            pnlTheLoai.Visible = true;
            pnlNXB.Visible = false;

            lnkNhanVien.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lnkTheLoai.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lnkNXB.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

            LoadTheLoai();
        }

        private void ChonTabNXB()
        {
            pnlNhanVien.Visible = false;
            pnlTheLoai.Visible = false;
            pnlNXB.Visible = true;

            lnkNhanVien.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lnkTheLoai.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lnkNXB.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

            LoadNhaXuatBan();
        }
        #endregion

        #region Nghiệp vụ Nhân viên
        private void LoadNhanVien()
        {
            DataTable dt = _danhMucService.LayDanhSachNhanVien();
            dgvNhanVien.DataSource = dt;

            if (dgvNhanVien.Columns.Contains("MaNhanVien"))
                dgvNhanVien.Columns["MaNhanVien"].HeaderText = "Mã NV";
            if (dgvNhanVien.Columns.Contains("Ho"))
                dgvNhanVien.Columns["Ho"].HeaderText = "Họ";
            if (dgvNhanVien.Columns.Contains("Ten"))
                dgvNhanVien.Columns["Ten"].HeaderText = "Tên";
            if (dgvNhanVien.Columns.Contains("Phai"))
                dgvNhanVien.Columns["Phai"].HeaderText = "Phái";
            if (dgvNhanVien.Columns.Contains("NgaySinh"))
            {
                dgvNhanVien.Columns["NgaySinh"].HeaderText = "Ngày sinh";
                dgvNhanVien.Columns["NgaySinh"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }
            if (dgvNhanVien.Columns.Contains("ChucVu"))
                dgvNhanVien.Columns["ChucVu"].HeaderText = "Chức vụ";
            if (dgvNhanVien.Columns.Contains("SoDienThoai"))
                dgvNhanVien.Columns["SoDienThoai"].HeaderText = "Điện thoại";
        }

        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvNhanVien.Rows[e.RowIndex];
                txtMaNV.Text = row.Cells["MaNhanVien"].Value?.ToString();
                txtHo.Text = row.Cells["Ho"].Value?.ToString();
                txtTen.Text = row.Cells["Ten"].Value?.ToString();
                txtPhai.Text = row.Cells["Phai"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["NgaySinh"].Value?.ToString(), out DateTime ns))
                    txtNgaySinh.Text = ns.ToString("dd/MM/yyyy");
                else
                    txtNgaySinh.Text = row.Cells["NgaySinh"].Value?.ToString();

                txtChucVu.Text = row.Cells["ChucVu"].Value?.ToString();
                txtMaNV.ReadOnly = true;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            DateTime ns = DateTime.Today;
            if (DateTime.TryParseExact(txtNgaySinh.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedExact))
                ns = parsedExact;
            else if (DateTime.TryParse(txtNgaySinh.Text.Trim(), out DateTime parsedNormal))
                ns = parsedNormal;

            var nv = new NhanVien
            {
                MaNhanVien = txtMaNV.Text.Trim(),
                Ho = txtHo.Text.Trim(),
                Ten = txtTen.Text.Trim(),
                Phai = txtPhai.Text.Trim(),
                NgaySinh = ns,
                ChucVu = txtChucVu.Text.Trim(),
                SoDienThoai = ""
            };

            var kq = _danhMucService.ThemNhanVien(nv);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi",
                            MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                LamMoiNV();
                LoadNhanVien();
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            DateTime ns = DateTime.Today;
            if (DateTime.TryParseExact(txtNgaySinh.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedExact))
                ns = parsedExact;
            else if (DateTime.TryParse(txtNgaySinh.Text.Trim(), out DateTime parsedNormal))
                ns = parsedNormal;

            var nv = new NhanVien
            {
                MaNhanVien = txtMaNV.Text.Trim(),
                Ho = txtHo.Text.Trim(),
                Ten = txtTen.Text.Trim(),
                Phai = txtPhai.Text.Trim(),
                NgaySinh = ns,
                ChucVu = txtChucVu.Text.Trim(),
                SoDienThoai = ""
            };

            var kq = _danhMucService.CapNhatNhanVien(nv);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                LoadNhanVien();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaNV.Text))
            {
                MessageBox.Show("Vui lòng chọn một nhân viên để xóa.");
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa nhân viên này?", "Xác nhận",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                var kq = _danhMucService.XoaNhanVien(txtMaNV.Text.Trim());
                MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
                if (kq.ThanhCong)
                {
                    LamMoiNV();
                    LoadNhanVien();
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LamMoiNV();
        }

        private void LamMoiNV()
        {
            txtMaNV.ReadOnly = false;
            txtMaNV.Clear();
            txtHo.Clear();
            txtTen.Clear();
            txtPhai.Clear();
            txtNgaySinh.Clear();
            txtChucVu.Clear();
            txtMaNV.Focus();
        }
        #endregion

        #region Nghiệp vụ Thể loại
        private void LoadTheLoai()
        {
            DataTable dt = _danhMucService.LayDanhSachTheLoai();
            dgvTheLoai.DataSource = dt;
            if (dgvTheLoai.Columns.Contains("MaTheLoai"))
                dgvTheLoai.Columns["MaTheLoai"].HeaderText = "Mã thể loại";
            if (dgvTheLoai.Columns.Contains("TenTheLoai"))
                dgvTheLoai.Columns["TenTheLoai"].HeaderText = "Tên thể loại";
        }

        private void dgvTheLoai_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtMaTL.Text = dgvTheLoai.Rows[e.RowIndex].Cells["MaTheLoai"].Value?.ToString();
                txtTenTL.Text = dgvTheLoai.Rows[e.RowIndex].Cells["TenTheLoai"].Value?.ToString();
                txtMaTL.ReadOnly = true;
            }
        }

        private void btnThemTL_Click(object sender, EventArgs e)
        {
            var kq = _danhMucService.ThemTheLoai(txtMaTL.Text.Trim(), txtTenTL.Text.Trim());
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
            if (kq.ThanhCong) { LamMoiTL(); LoadTheLoai(); }
        }

        private void btnCapNhatTL_Click(object sender, EventArgs e)
        {
            var kq = _danhMucService.CapNhatTheLoai(txtMaTL.Text.Trim(), txtTenTL.Text.Trim());
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
            if (kq.ThanhCong) LoadTheLoai();
        }

        private void btnXoaTL_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn xóa thể loại này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                var kq = _danhMucService.XoaTheLoai(txtMaTL.Text.Trim());
                MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
                if (kq.ThanhCong) { LamMoiTL(); LoadTheLoai(); }
            }
        }

        private void btnLamMoiTL_Click(object sender, EventArgs e)
        {
            LamMoiTL();
        }

        private void LamMoiTL()
        {
            txtMaTL.ReadOnly = false;
            txtMaTL.Clear();
            txtTenTL.Clear();
            txtMaTL.Focus();
        }
        #endregion

        #region Nghiệp vụ Nhà xuất bản
        private void LoadNhaXuatBan()
        {
            DataTable dt = _danhMucService.LayDanhSachNhaXuatBan();
            dgvNXB.DataSource = dt;
            if (dgvNXB.Columns.Contains("MaNhaXuatBan"))
                dgvNXB.Columns["MaNhaXuatBan"].HeaderText = "Mã NXB";
            if (dgvNXB.Columns.Contains("DiaChi"))
                dgvNXB.Columns["DiaChi"].HeaderText = "Địa chỉ";
            if (dgvNXB.Columns.Contains("SoDienThoai"))
                dgvNXB.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
        }

        private void dgvNXB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtMaNXB.Text = dgvNXB.Rows[e.RowIndex].Cells["MaNhaXuatBan"].Value?.ToString();
                txtDiaChiNXB.Text = dgvNXB.Rows[e.RowIndex].Cells["DiaChi"].Value?.ToString();
                txtSDTNXB.Text = dgvNXB.Rows[e.RowIndex].Cells["SoDienThoai"].Value?.ToString();
                txtMaNXB.ReadOnly = true;
            }
        }

        private void btnThemNXB_Click(object sender, EventArgs e)
        {
            var kq = _danhMucService.ThemNhaXuatBan(txtMaNXB.Text.Trim(), txtDiaChiNXB.Text.Trim(), txtSDTNXB.Text.Trim());
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
            if (kq.ThanhCong) { LamMoiNXB(); LoadNhaXuatBan(); }
        }

        private void btnCapNhatNXB_Click(object sender, EventArgs e)
        {
            var kq = _danhMucService.CapNhatNhaXuatBan(txtMaNXB.Text.Trim(), txtDiaChiNXB.Text.Trim(), txtSDTNXB.Text.Trim());
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
            if (kq.ThanhCong) LoadNhaXuatBan();
        }

        private void btnXoaNXB_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn xóa nhà xuất bản này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                var kq = _danhMucService.XoaNhaXuatBan(txtMaNXB.Text.Trim());
                MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
                if (kq.ThanhCong) { LamMoiNXB(); LoadNhaXuatBan(); }
            }
        }

        private void btnLamMoiNXB_Click(object sender, EventArgs e)
        {
            LamMoiNXB();
        }

        private void LamMoiNXB()
        {
            txtMaNXB.ReadOnly = false;
            txtMaNXB.Clear();
            txtDiaChiNXB.Clear();
            txtSDTNXB.Clear();
            txtMaNXB.Focus();
        }
        #endregion
    }
}