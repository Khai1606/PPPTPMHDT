﻿namespace QuanLyThuVien.Forms
{
    partial class FrmThongKe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlOuter = new System.Windows.Forms.Panel();
            this.dgvChiTietPhat = new System.Windows.Forms.DataGridView();
            this.lblChiTietTitle = new System.Windows.Forms.Label();
            this.lblTongPhiPhat = new System.Windows.Forms.Label();
            this.lblSachHuHong = new System.Windows.Forms.Label();
            this.lblSachQuaHan = new System.Windows.Forms.Label();
            this.lblSachMat = new System.Windows.Forms.Label();
            this.lblLuotMuon = new System.Windows.Forms.Label();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.txtDenNgay = new System.Windows.Forms.TextBox();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.txtTuNgay = new System.Windows.Forms.TextBox();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.pnlOuter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhat)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlOuter
            // 
            this.pnlOuter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlOuter.BackColor = System.Drawing.Color.White;
            this.pnlOuter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOuter.Controls.Add(this.dgvChiTietPhat);
            this.pnlOuter.Controls.Add(this.lblChiTietTitle);
            this.pnlOuter.Controls.Add(this.lblTongPhiPhat);
            this.pnlOuter.Controls.Add(this.lblSachHuHong);
            this.pnlOuter.Controls.Add(this.lblSachQuaHan);
            this.pnlOuter.Controls.Add(this.lblSachMat);
            this.pnlOuter.Controls.Add(this.lblLuotMuon);
            this.pnlOuter.Controls.Add(this.btnThongKe);
            this.pnlOuter.Controls.Add(this.txtDenNgay);
            this.pnlOuter.Controls.Add(this.lblDenNgay);
            this.pnlOuter.Controls.Add(this.txtTuNgay);
            this.pnlOuter.Controls.Add(this.lblTuNgay);
            this.pnlOuter.Location = new System.Drawing.Point(18, 16);
            this.pnlOuter.Name = "pnlOuter";
            this.pnlOuter.Size = new System.Drawing.Size(914, 538);
            this.pnlOuter.TabIndex = 0;
            // 
            // dgvChiTietPhat
            // 
            this.dgvChiTietPhat.AllowUserToAddRows = false;
            this.dgvChiTietPhat.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChiTietPhat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhat.BackgroundColor = System.Drawing.Color.White;
            this.dgvChiTietPhat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhat.Location = new System.Drawing.Point(30, 245);
            this.dgvChiTietPhat.MultiSelect = false;
            this.dgvChiTietPhat.Name = "dgvChiTietPhat";
            this.dgvChiTietPhat.ReadOnly = true;
            this.dgvChiTietPhat.RowHeadersVisible = false;
            this.dgvChiTietPhat.RowHeadersWidth = 51;
            this.dgvChiTietPhat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTietPhat.Size = new System.Drawing.Size(850, 268);
            this.dgvChiTietPhat.TabIndex = 11;
            // 
            // lblChiTietTitle
            // 
            this.lblChiTietTitle.AutoSize = true;
            this.lblChiTietTitle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblChiTietTitle.Location = new System.Drawing.Point(26, 215);
            this.lblChiTietTitle.Name = "lblChiTietTitle";
            this.lblChiTietTitle.Size = new System.Drawing.Size(161, 23);
            this.lblChiTietTitle.TabIndex = 10;
            this.lblChiTietTitle.Text = "Chi tiết phiếu phạt:";
            // 
            // lblTongPhiPhat
            // 
            this.lblTongPhiPhat.AutoSize = true;
            this.lblTongPhiPhat.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTongPhiPhat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.lblTongPhiPhat.Location = new System.Drawing.Point(32, 155);
            this.lblTongPhiPhat.Name = "lblTongPhiPhat";
            this.lblTongPhiPhat.Size = new System.Drawing.Size(262, 32);
            this.lblTongPhiPhat.TabIndex = 9;
            this.lblTongPhiPhat.Text = "Tổng phí phạt: 0 đ";
            // 
            // lblSachHuHong
            // 
            this.lblSachHuHong.AutoSize = true;
            this.lblSachHuHong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSachHuHong.Location = new System.Drawing.Point(400, 115);
            this.lblSachHuHong.Name = "lblSachHuHong";
            this.lblSachHuHong.Size = new System.Drawing.Size(135, 23);
            this.lblSachHuHong.TabIndex = 8;
            this.lblSachHuHong.Text = "Sách hư hỏng: 0";
            // 
            // lblSachQuaHan
            //
            this.lblSachQuaHan.AutoSize = true;
            this.lblSachQuaHan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSachQuaHan.Location = new System.Drawing.Point(400, 78);
            this.lblSachQuaHan.Name = "lblSachQuaHan";
            this.lblSachQuaHan.Size = new System.Drawing.Size(132, 23);
            this.lblSachQuaHan.TabIndex = 7;
            this.lblSachQuaHan.Text = "Sách quá hạn: 0";
            // 
            // lblSachMat
            // 
            this.lblSachMat.AutoSize = true;
            this.lblSachMat.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSachMat.Location = new System.Drawing.Point(34, 115);
            this.lblSachMat.Name = "lblSachMat";
            this.lblSachMat.Size = new System.Drawing.Size(98, 23);
            this.lblSachMat.TabIndex = 6;
            this.lblSachMat.Text = "Sách mất: 0";
            // 
            // lblLuotMuon
            // 
            this.lblLuotMuon.AutoSize = true;
            this.lblLuotMuon.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblLuotMuon.Location = new System.Drawing.Point(34, 78);
            this.lblLuotMuon.Name = "lblLuotMuon";
            this.lblLuotMuon.Size = new System.Drawing.Size(155, 23);
            this.lblLuotMuon.TabIndex = 5;
            this.lblLuotMuon.Text = "Lượt sách mượn: 0";
            // 
            // btnThongKe
            // 
            this.btnThongKe.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThongKe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThongKe.Location = new System.Drawing.Point(520, 20);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(110, 32);
            this.btnThongKe.TabIndex = 4;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = true;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // txtDenNgay
            // 
            this.txtDenNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDenNgay.Location = new System.Drawing.Point(365, 22);
            this.txtDenNgay.Name = "txtDenNgay";
            this.txtDenNgay.Size = new System.Drawing.Size(130, 29);
            this.txtDenNgay.TabIndex = 3;
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDenNgay.Location = new System.Drawing.Point(280, 25);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(79, 21);
            this.lblDenNgay.TabIndex = 2;
            this.lblDenNgay.Text = "Đến ngày:";
            // 
            // txtTuNgay
            // 
            this.txtTuNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTuNgay.Location = new System.Drawing.Point(110, 22);
            this.txtTuNgay.Name = "txtTuNgay";
            this.txtTuNgay.Size = new System.Drawing.Size(130, 29);
            this.txtTuNgay.TabIndex = 1;
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTuNgay.Location = new System.Drawing.Point(30, 25);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(68, 21);
            this.lblTuNgay.TabIndex = 0;
            this.lblTuNgay.Text = "Từ ngày:";
            // 
            // FrmThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(950, 570);
            this.Controls.Add(this.pnlOuter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thống kê thư viện";
            this.Load += new System.EventHandler(this.FrmThongKe_Load);
            this.pnlOuter.ResumeLayout(false);
            this.pnlOuter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhat)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlOuter;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.TextBox txtTuNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.TextBox txtDenNgay;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Label lblLuotMuon;
        private System.Windows.Forms.Label lblSachMat;
        private System.Windows.Forms.Label lblSachQuaHan;
        private System.Windows.Forms.Label lblSachHuHong;
        private System.Windows.Forms.Label lblTongPhiPhat;
        private System.Windows.Forms.Label lblChiTietTitle;
        private System.Windows.Forms.DataGridView dgvChiTietPhat;
    }
}