﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmMuonTra : Form
    {
        private readonly MuonTraService _muonTraService = new MuonTraService();
        private readonly SachService _sachService = new SachService();
        private readonly DocGiaService _docGiaService = new DocGiaService();
        private readonly DanhMucService _danhMucService = new DanhMucService();

        // Bảng dữ liệu sách đã chọn mượn
        private readonly DataTable _dtSachChon = new DataTable();

        // Biến lưu thông tin dòng sách đang chọn để trả
        private string _maChiTietDangChon = "";
        private string _maSachDangChon = "";
        private DateTime _ngayHenTraDangChon = DateTime.Today;

        public FrmMuonTra()
        {
            InitializeComponent();
        }

        private void FrmMuonTra_Load(object sender, EventArgs e)
        {
            // Thiết lập cấu trúc bảng sách đã chọn
            if (_dtSachChon.Columns.Count == 0)
            {
                _dtSachChon.Columns.Add("MaDauSach", typeof(string));
                _dtSachChon.Columns.Add("TenSach", typeof(string));
            }
            dgvSachChon.DataSource = _dtSachChon;
            if (dgvSachChon.Columns.Contains("MaDauSach"))
                dgvSachChon.Columns["MaDauSach"].HeaderText = "Mã";
            if (dgvSachChon.Columns.Contains("TenSach"))
                dgvSachChon.Columns["TenSach"].HeaderText = "Tên sách";

            // Khởi tạo ngày mặc định
            txtNgayMuon.Text = DateTime.Today.ToString("dd/MM/yyyy");
            txtHenTra.Text = DateTime.Today.AddDays(7).ToString("dd/MM/yyyy");
            txtNgayTra.Text = DateTime.Today.ToString("dd/MM/yyyy");
            cboTinhTrang.SelectedIndex = 0;

            ChonTabMuonSach();
            LoadComboBoxes();
            LoadKhoSach();
            LoadDanhSachDangMuon();
        }

        #region Chuyển đổi giữa [Mượn sách] và [Trả sách]
        private void lnkMuonSach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChonTabMuonSach();
        }

        private void lnkTraSach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChonTabTraSach();
        }

        private void ChonTabMuonSach()
        {
            pnlMuonSach.Visible = true;
            pnlTraSach.Visible = false;

            lnkMuonSach.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lnkTraSach.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

            LoadKhoSach();
        }

        private void ChonTabTraSach()
        {
            pnlMuonSach.Visible = false;
            pnlTraSach.Visible = true;

            lnkMuonSach.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lnkTraSach.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

            LoadDanhSachDangMuon();
        }
        #endregion

        #region Nghiệp vụ Mượn Sách
        private void LoadComboBoxes()
        {
            // Nạp Độc Giả
            DataTable dtDG = _docGiaService.LayDanhSachDocGia();
            if (!dtDG.Columns.Contains("HienThi"))
                dtDG.Columns.Add("HienThi", typeof(string), "MaDocGia + ' - ' + Ho + ' ' + Ten");
            cboDocGia.DataSource = dtDG;
            cboDocGia.DisplayMember = "HienThi";
            cboDocGia.ValueMember = "MaDocGia";

            // Nạp Thủ Thư
            DataTable dtNV = _danhMucService.LayDanhSachNhanVien();
            cboNhanVien.DataSource = dtNV;
            cboNhanVien.DisplayMember = "MaNhanVien";
            cboNhanVien.ValueMember = "MaNhanVien";
        }

        private void LoadKhoSach()
        {
            DataTable dt = _sachService.LayDanhSachDauSach();
            dgvKhoSach.DataSource = dt;

            if (dgvKhoSach.Columns.Contains("MaDauSach"))
                dgvKhoSach.Columns["MaDauSach"].HeaderText = "Mã";
            if (dgvKhoSach.Columns.Contains("TenSach"))
                dgvKhoSach.Columns["TenSach"].HeaderText = "Tên sách";
            if (dgvKhoSach.Columns.Contains("NamXuatBan"))
                dgvKhoSach.Columns["NamXuatBan"].HeaderText = "Năm XB";
            if (dgvKhoSach.Columns.Contains("SoLuongHienCo"))
                dgvKhoSach.Columns["SoLuongHienCo"].HeaderText = "Còn";

            // Ẩn cột không cần thiết
            string[] hideCols = { "MaTheLoai", "TenTheLoai", "MaNhaXuatBan" };
            foreach (var col in hideCols)
            {
                if (dgvKhoSach.Columns.Contains(col))
                    dgvKhoSach.Columns[col].Visible = false;
            }
        }

        private void btnKiemTraDieuKien_Click(object sender, EventArgs e)
        {
            if (cboDocGia.SelectedValue == null) return;
            string maDG = cboDocGia.SelectedValue.ToString();

            var kq = _muonTraService.KiemTraDieuKienMuon(maDG);
            lblDieuKienStatus.Text = kq.ThongBao;
            lblDieuKienStatus.ForeColor = kq.ThanhCong ? Color.DarkGreen : Color.Red;
        }

        private void btnThemSach_Click(object sender, EventArgs e)
        {
            if (dgvKhoSach.CurrentRow == null) return;

            string maSach = dgvKhoSach.CurrentRow.Cells["MaDauSach"].Value?.ToString();
            string tenSach = dgvKhoSach.CurrentRow.Cells["TenSach"].Value?.ToString();
            int tonKho = 0;
            int.TryParse(dgvKhoSach.CurrentRow.Cells["SoLuongHienCo"].Value?.ToString(), out tonKho);

            if (tonKho <= 0)
            {
                MessageBox.Show("Sách này hiện đã hết trong kho.", "Thông báo");
                return;
            }

            // Kiểm tra tối đa 3 cuốn
            if (_dtSachChon.Rows.Count >= 3)
            {
                MessageBox.Show("Chỉ được mượn tối đa 3 cuốn sách.", "Quy định thư viện");
                return;
            }

            // Kiểm tra trùng đầu sách
            foreach (DataRow row in _dtSachChon.Rows)
            {
                if (row["MaDauSach"].ToString() == maSach)
                {
                    MessageBox.Show("Sách này đã có trong danh sách chọn.", "Thông báo");
                    return;
                }
            }

            _dtSachChon.Rows.Add(maSach, tenSach);
        }

        private void btnBoSach_Click(object sender, EventArgs e)
        {
            if (dgvSachChon.CurrentRow != null)
            {
                int index = dgvSachChon.CurrentRow.Index;
                if (index >= 0 && index < _dtSachChon.Rows.Count)
                {
                    _dtSachChon.Rows.RemoveAt(index);
                }
            }
        }

        private void btnLapPhieu_Click(object sender, EventArgs e)
        {
            string maDG = cboDocGia.SelectedValue?.ToString();
            string maNV = cboNhanVien.SelectedValue?.ToString();
            string maPM = "PM" + DateTime.Now.ToString("yyyyMMddHHmmss");

            DateTime nm = DateTime.Today;
            DateTime ht = DateTime.Today.AddDays(7);
            if (DateTime.TryParseExact(txtNgayMuon.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime pNM))
                nm = pNM;
            if (DateTime.TryParseExact(txtHenTra.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime pHT))
                ht = pHT;

            List<string> dsSach = new List<string>();
            foreach (DataRow r in _dtSachChon.Rows)
            {
                dsSach.Add(r["MaDauSach"].ToString());
            }

            var kq = _muonTraService.LapPhieuMuon(maPM, maDG, maNV, nm, ht, dsSach);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi",
                            MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                _dtSachChon.Clear();
                LoadKhoSach();
            }
        }
        #endregion

        #region Nghiệp vụ Trả Sách & Phạt
        private void LoadDanhSachDangMuon()
        {
            DataTable dt = _muonTraService.LayDanhSachDangMuon(txtTimKiemTra.Text.Trim());
            dgvDangMuon.DataSource = dt;

            if (dgvDangMuon.Columns.Contains("MaChiTiet"))
                dgvDangMuon.Columns["MaChiTiet"].HeaderText = "Mã CT";
            if (dgvDangMuon.Columns.Contains("MaPhieuMuon"))
                dgvDangMuon.Columns["MaPhieuMuon"].HeaderText = "Mã PM";
            if (dgvDangMuon.Columns.Contains("HoTenDocGia"))
                dgvDangMuon.Columns["HoTenDocGia"].HeaderText = "Độc giả";
            if (dgvDangMuon.Columns.Contains("MaDauSach"))
                dgvDangMuon.Columns["MaDauSach"].HeaderText = "Mã sách";
            if (dgvDangMuon.Columns.Contains("TenSach"))
                dgvDangMuon.Columns["TenSach"].HeaderText = "Tên sách";
            if (dgvDangMuon.Columns.Contains("NgayHenTra"))
            {
                dgvDangMuon.Columns["NgayHenTra"].HeaderText = "Hạn trả";
                dgvDangMuon.Columns["NgayHenTra"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }

            // Ẩn các cột nội bộ
            if (dgvDangMuon.Columns.Contains("MaDocGia"))
                dgvDangMuon.Columns["MaDocGia"].Visible = false;
            if (dgvDangMuon.Columns.Contains("NgayMuon"))
                dgvDangMuon.Columns["NgayMuon"].Visible = false;
            if (dgvDangMuon.Columns.Contains("MaNhanVien"))
                dgvDangMuon.Columns["MaNhanVien"].Visible = false;
        }

        private void txtTimKiemTra_TextChanged(object sender, EventArgs e)
        {
            LoadDanhSachDangMuon();
        }

        private void dgvDangMuon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDangMuon.Rows[e.RowIndex];
                _maChiTietDangChon = row.Cells["MaChiTiet"].Value?.ToString();
                _maSachDangChon = row.Cells["MaDauSach"].Value?.ToString();

                string maPM = row.Cells["MaPhieuMuon"].Value?.ToString();
                string tenSach = row.Cells["TenSach"].Value?.ToString();
                string hoTenDG = row.Cells["HoTenDocGia"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["NgayHenTra"].Value?.ToString(), out DateTime ht))
                    _ngayHenTraDangChon = ht;

                txtInfoSachTra.Text = $"{maPM} - {hoTenDG} - {tenSach} (Hạn trả: {_ngayHenTraDangChon:dd/MM/yyyy})";
                TinhPhiPhat();
            }
        }

        private void cboTinhTrang_SelectedIndexChanged(object sender, EventArgs e)
        {
            TinhPhiPhat();
        }

        private void TinhPhiPhat()
        {
            decimal tongPhat = 0;
            string lyDo = "";

            DateTime nt = DateTime.Today;
            if (DateTime.TryParseExact(txtNgayTra.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime pNT))
                nt = pNT;

            if (nt.Date > _ngayHenTraDangChon.Date)
            {
                int soNgayTre = (nt.Date - _ngayHenTraDangChon.Date).Days;
                decimal phatTre = soNgayTre * 5000;
                tongPhat += phatTre;
                lyDo += $"Trễ hạn {soNgayTre} ngày ({phatTre:N0} đ); ";
            }

            string tt = cboTinhTrang.SelectedItem?.ToString() ?? "";
            if (tt == "Rách / Hư hỏng nhẹ")
            {
                tongPhat += 20000;
                lyDo += "Sách hư hỏng nhẹ (20.000 đ); ";
            }
            else if (tt == "Hư hỏng nặng")
            {
                tongPhat += 50000;
                lyDo += "Sách hư hỏng nặng (50.000 đ); ";
            }
            else if (tt == "Mất sách")
            {
                tongPhat += 100000;
                lyDo += "Làm mất sách (100.000 đ); ";
            }

            nudPhiPhat.Value = tongPhat;
            txtLyDoPhat.Text = lyDo.TrimEnd(' ', ';');
        }

        private void btnXacNhanTra_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_maChiTietDangChon))
            {
                MessageBox.Show("Vui lòng chọn 1 cuốn sách cần trả từ danh sách trên.");
                return;
            }

            DateTime nt = DateTime.Today;
            if (DateTime.TryParseExact(txtNgayTra.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime pNT))
                nt = pNT;

            string maNV = cboNhanVien.SelectedValue?.ToString() ?? "NV001";

            var kq = _muonTraService.TraSach(
                _maChiTietDangChon,
                _maSachDangChon,
                maNV,
                nt,
                cboTinhTrang.SelectedItem?.ToString(),
                nudPhiPhat.Value,
                txtLyDoPhat.Text.Trim()
            );

            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                _maChiTietDangChon = "";
                _maSachDangChon = "";
                txtInfoSachTra.Clear();
                nudPhiPhat.Value = 0;
                txtLyDoPhat.Clear();

                LoadDanhSachDangMuon();
                LoadKhoSach();
            }
        }
        #endregion
    }
}