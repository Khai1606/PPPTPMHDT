﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmThongKe : Form
    {
        private readonly ThongKeService _thongKeService = new ThongKeService();

        public FrmThongKe()
        {
            InitializeComponent();
        }

        private void FrmThongKe_Load(object sender, EventArgs e)
        {
            // Thiết lập khoảng ngày mặc định: từ đầu tháng đến cuối tháng hiện tại
            DateTime today = DateTime.Today;
            DateTime startOfMonth = new DateTime(today.Year, today.Month, 1);
            DateTime endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

            txtTuNgay.Text = startOfMonth.ToString("dd/MM/yyyy");
            txtDenNgay.Text = endOfMonth.ToString("dd/MM/yyyy");

            ThucHienThongKe();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            ThucHienThongKe();
        }

        private void ThucHienThongKe()
        {
            DateTime tuNgay = DateTime.Today;
            DateTime denNgay = DateTime.Today;

            if (!DateTime.TryParseExact(txtTuNgay.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out tuNgay))
            {
                MessageBox.Show("Vui lòng nhập định dạng 'Từ ngày' là dd/MM/yyyy (ví dụ: 01/09/2026).", "Lỗi định dạng");
                return;
            }

            if (!DateTime.TryParseExact(txtDenNgay.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out denNgay))
            {
                MessageBox.Show("Vui lòng nhập định dạng 'Đến ngày' là dd/MM/yyyy (ví dụ: 30/09/2026).", "Lỗi định dạng");
                return;
            }

            // 1. Cập nhật các chỉ số tổng hợp
            var bc = _thongKeService.LaySoLieuBaoCao(tuNgay, denNgay);
            lblLuotMuon.Text = $"Lượt sách mượn: {bc.LuotMuon}";
            lblSachQuaHan.Text = $"Sách quá hạn: {bc.SachQuaHan}";
            lblSachMat.Text = $"Sách mất: {bc.SachMat}";
            lblSachHuHong.Text = $"Sách hư hỏng: {bc.SachHuHong}";
            lblTongPhiPhat.Text = $"Tổng phí phạt: {bc.TongPhat:N0} đ";

            // 2. Nạp bảng chi tiết phiếu phạt
            DataTable dtPhat = _thongKeService.LayChiTietPhieuPhat(tuNgay, denNgay);
            dgvChiTietPhat.DataSource = dtPhat;

            if (dgvChiTietPhat.Columns.Contains("MaPhieuPhat"))
                dgvChiTietPhat.Columns["MaPhieuPhat"].HeaderText = "Mã phiếu";
            if (dgvChiTietPhat.Columns.Contains("NgayPhat"))
            {
                dgvChiTietPhat.Columns["NgayPhat"].HeaderText = "Ngày";
                dgvChiTietPhat.Columns["NgayPhat"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }
            if (dgvChiTietPhat.Columns.Contains("HoTenDocGia"))
                dgvChiTietPhat.Columns["HoTenDocGia"].HeaderText = "Độc giả";
            if (dgvChiTietPhat.Columns.Contains("MaDauSach"))
                dgvChiTietPhat.Columns["MaDauSach"].HeaderText = "Mã sách";
            if (dgvChiTietPhat.Columns.Contains("LyDo"))
                dgvChiTietPhat.Columns["LyDo"].HeaderText = "Lý do";
            if (dgvChiTietPhat.Columns.Contains("PhiPhat"))
            {
                dgvChiTietPhat.Columns["PhiPhat"].HeaderText = "Phí phạt";
                dgvChiTietPhat.Columns["PhiPhat"].DefaultCellStyle.Format = "N0";
            }
        }
    }
}