﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyThuVien.Models;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmSach : Form
    {
        private readonly SachService _sachService = new SachService();
        private readonly DanhMucService _danhMucService = new DanhMucService();

        public FrmSach()
        {
            InitializeComponent();
        }

        private void FrmSach_Load(object sender, EventArgs e)
        {
            LoadComboBoxes();
            LoadDanhSachSach();
        }

        private void LoadComboBoxes()
        {
            // Nạp Thể loại
            DataTable dtTheLoai = _danhMucService.LayDanhSachTheLoai();
            cboTheLoai.DataSource = dtTheLoai;
            cboTheLoai.DisplayMember = "TenTheLoai";
            cboTheLoai.ValueMember = "MaTheLoai";

            // Nạp Nhà xuất bản
            DataTable dtNXB = _danhMucService.LayDanhSachNhaXuatBan();
            cboNXB.DataSource = dtNXB;
            cboNXB.DisplayMember = "MaNhaXuatBan";
            cboNXB.ValueMember = "MaNhaXuatBan";
        }

        private void LoadDanhSachSach()
        {
            DataTable dt = _sachService.LayDanhSachDauSach();
            dgvSach.DataSource = dt;

            // Đặt tên tiêu đề cột hiển thị đúng như thiết kế
            if (dgvSach.Columns.Contains("MaDauSach"))
                dgvSach.Columns["MaDauSach"].HeaderText = "Mã sách";
            if (dgvSach.Columns.Contains("TenSach"))
                dgvSach.Columns["TenSach"].HeaderText = "Tên sách";
            if (dgvSach.Columns.Contains("NamXuatBan"))
                dgvSach.Columns["NamXuatBan"].HeaderText = "Năm XB";
            if (dgvSach.Columns.Contains("SoLuongHienCo"))
                dgvSach.Columns["SoLuongHienCo"].HeaderText = "Số lượng";
            if (dgvSach.Columns.Contains("TenTheLoai"))
                dgvSach.Columns["TenTheLoai"].HeaderText = "Thể loại";
            if (dgvSach.Columns.Contains("MaNhaXuatBan"))
                dgvSach.Columns["MaNhaXuatBan"].HeaderText = "Mã NXB";

            // Ẩn cột mã thể loại nội bộ
            if (dgvSach.Columns.Contains("MaTheLoai"))
                dgvSach.Columns["MaTheLoai"].Visible = false;
        }

        private void dgvSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvSach.Rows[e.RowIndex];
                txtMaSach.Text = row.Cells["MaDauSach"].Value?.ToString();
                txtTenSach.Text = row.Cells["TenSach"].Value?.ToString();
                txtNamXB.Text = row.Cells["NamXuatBan"].Value?.ToString();
                txtSoLuong.Text = row.Cells["SoLuongHienCo"].Value?.ToString();

                if (row.Cells["MaTheLoai"].Value != null)
                    cboTheLoai.SelectedValue = row.Cells["MaTheLoai"].Value.ToString();
                if (row.Cells["MaNhaXuatBan"].Value != null)
                    cboNXB.SelectedValue = row.Cells["MaNhaXuatBan"].Value.ToString();

                txtMaSach.ReadOnly = true;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            int namXB = 0;
            int.TryParse(txtNamXB.Text.Trim(), out namXB);

            int soLuong = 0;
            int.TryParse(txtSoLuong.Text.Trim(), out soLuong);

            var ds = new DauSach
            {
                MaDauSach = txtMaSach.Text.Trim(),
                TenSach = txtTenSach.Text.Trim(),
                MaTheLoai = cboTheLoai.SelectedValue?.ToString(),
                MaNhaXuatBan = cboNXB.SelectedValue?.ToString(),
                NamXuatBan = namXB,
                SoLuongHienCo = soLuong
            };

            var kq = _sachService.ThemDauSach(ds);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi",
                            MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                LamMoi();
                LoadDanhSachSach();
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            int namXB = 0;
            int.TryParse(txtNamXB.Text.Trim(), out namXB);

            int soLuong = 0;
            int.TryParse(txtSoLuong.Text.Trim(), out soLuong);

            var ds = new DauSach
            {
                MaDauSach = txtMaSach.Text.Trim(),
                TenSach = txtTenSach.Text.Trim(),
                MaTheLoai = cboTheLoai.SelectedValue?.ToString(),
                MaNhaXuatBan = cboNXB.SelectedValue?.ToString(),
                NamXuatBan = namXB,
                SoLuongHienCo = soLuong
            };

            var kq = _sachService.CapNhatDauSach(ds);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                LoadDanhSachSach();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaSach.Text))
            {
                MessageBox.Show("Vui lòng chọn một đầu sách để xóa.");
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa đầu sách này?", "Xác nhận",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                var kq = _sachService.XoaDauSach(txtMaSach.Text.Trim());
                MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");
                if (kq.ThanhCong)
                {
                    LamMoi();
                    LoadDanhSachSach();
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LamMoi();
        }
        private void LamMoi()
        {
            txtMaSach.ReadOnly = false;
            txtMaSach.Clear();
            txtTenSach.Clear();
            txtNamXB.Clear();
            txtSoLuong.Clear();
            if (cboTheLoai.Items.Count > 0) cboTheLoai.SelectedIndex = 0;
            if (cboNXB.Items.Count > 0) cboNXB.SelectedIndex = 0;
            txtMaSach.Focus();
        }
    }
}