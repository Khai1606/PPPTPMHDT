﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyThuVien.Models;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmDocGia : Form
    {
        private readonly DocGiaService _docGiaService = new DocGiaService();

        public FrmDocGia()
        {
            InitializeComponent();
        }

        private void FrmDocGia_Load(object sender, EventArgs e)
        {
            // Thiết lập giá trị ngày mặc định
            txtNgayCap.Text = DateTime.Today.ToString("dd/MM/yyyy");
            txtHanSuDung.Text = DateTime.Today.AddYears(1).ToString("dd/MM/yyyy");
            chkDaDongLePhi.Checked = true;

            LoadDanhSachDocGia();
        }

        private void LoadDanhSachDocGia()
        {
            DataTable dt = _docGiaService.LayDanhSachDocGiaVaThe();
            dgvDocGia.DataSource = dt;

            // Đặt tên cột hiển thị đúng như thiết kế
            if (dgvDocGia.Columns.Contains("MaDocGia"))
                dgvDocGia.Columns["MaDocGia"].HeaderText = "Mã";
            if (dgvDocGia.Columns.Contains("Ho"))
                dgvDocGia.Columns["Ho"].HeaderText = "Họ";
            if (dgvDocGia.Columns.Contains("Ten"))
                dgvDocGia.Columns["Ten"].HeaderText = "Tên";
            if (dgvDocGia.Columns.Contains("Phai"))
                dgvDocGia.Columns["Phai"].HeaderText = "Phái";
            if (dgvDocGia.Columns.Contains("SoDienThoai"))
                dgvDocGia.Columns["SoDienThoai"].HeaderText = "Điện thoại";
            if (dgvDocGia.Columns.Contains("Email"))
                dgvDocGia.Columns["Email"].HeaderText = "Email";
            if (dgvDocGia.Columns.Contains("HanSuDung"))
            {
                dgvDocGia.Columns["HanSuDung"].HeaderText = "Hạn thẻ";
                dgvDocGia.Columns["HanSuDung"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }

            // Ẩn các cột nội bộ không hiển thị trên bảng
            string[] hideCols = { "NgaySinh", "DiaChi", "Anh3x4", "MaThe", "NgayCap", "DaDongLePhi", "TrangThai" };
            foreach (var col in hideCols)
            {
                if (dgvDocGia.Columns.Contains(col))
                    dgvDocGia.Columns[col].Visible = false;
            }
        }

        private void dgvDocGia_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDocGia.Rows[e.RowIndex];
                txtMaDG.Text = row.Cells["MaDocGia"].Value?.ToString();
                txtHo.Text = row.Cells["Ho"].Value?.ToString();
                txtTen.Text = row.Cells["Ten"].Value?.ToString();
                txtPhai.Text = row.Cells["Phai"].Value?.ToString();
                txtDienThoai.Text = row.Cells["SoDienThoai"].Value?.ToString();
                txtDiaChi.Text = row.Cells["DiaChi"].Value?.ToString();
                txtEmail.Text = row.Cells["Email"].Value?.ToString();
                txtAnh3x4.Text = row.Cells["Anh3x4"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["NgaySinh"].Value?.ToString(), out DateTime ns))
                    txtNgaySinh.Text = ns.ToString("dd/MM/yyyy");
                else
                    txtNgaySinh.Text = row.Cells["NgaySinh"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["NgayCap"].Value?.ToString(), out DateTime nc))
                    txtNgayCap.Text = nc.ToString("dd/MM/yyyy");

                if (DateTime.TryParse(row.Cells["HanSuDung"].Value?.ToString(), out DateTime hsd))
                    txtHanSuDung.Text = hsd.ToString("dd/MM/yyyy");

                chkDaDongLePhi.Checked = row.Cells["DaDongLePhi"].Value != DBNull.Value && Convert.ToBoolean(row.Cells["DaDongLePhi"].Value);

                txtMaDG.ReadOnly = true;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            DateTime? ns = null;
            if (DateTime.TryParseExact(txtNgaySinh.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                ns = parsedDate;
            else if (DateTime.TryParse(txtNgaySinh.Text.Trim(), out DateTime parsedNormal))
                ns = parsedNormal;

            var dg = new DocGia
            {
                MaDocGia = txtMaDG.Text.Trim(),
                Ho = txtHo.Text.Trim(),
                Ten = txtTen.Text.Trim(),
                NgaySinh = ns,
                Phai = txtPhai.Text.Trim(),
                SoDienThoai = txtDienThoai.Text.Trim(),
                DiaChi = txtDiaChi.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Anh3x4 = txtAnh3x4.Text.Trim()
            };

            var kq = _docGiaService.ThemDocGia(dg);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi",
                            MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                LoadDanhSachDocGia();
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            DateTime? ns = null;
            if (DateTime.TryParseExact(txtNgaySinh.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                ns = parsedDate;
            else if (DateTime.TryParse(txtNgaySinh.Text.Trim(), out DateTime parsedNormal))
                ns = parsedNormal;

            var dg = new DocGia
            {
                MaDocGia = txtMaDG.Text.Trim(),
                Ho = txtHo.Text.Trim(),
                Ten = txtTen.Text.Trim(),
                NgaySinh = ns,
                Phai = txtPhai.Text.Trim(),
                SoDienThoai = txtDienThoai.Text.Trim(),
                DiaChi = txtDiaChi.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Anh3x4 = txtAnh3x4.Text.Trim()
            };
            var kq = _docGiaService.CapNhatDocGia(dg);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                LoadDanhSachDocGia();
            }
        }

        private void btnCapThe_Click(object sender, EventArgs e)
        {
            DateTime nc = DateTime.Today;
            DateTime hsd = DateTime.Today.AddYears(1);

            if (DateTime.TryParseExact(txtNgayCap.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedNC))
                nc = parsedNC;
            if (DateTime.TryParseExact(txtHanSuDung.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedHSD))
                hsd = parsedHSD;

            var kq = _docGiaService.CapThe(txtMaDG.Text.Trim(), nc, hsd, chkDaDongLePhi.Checked);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                LoadDanhSachDocGia();
            }
        }

        private void btnGiaHan_Click(object sender, EventArgs e)
        {
            DateTime hsd = DateTime.Today.AddYears(1);
            if (DateTime.TryParseExact(txtHanSuDung.Text.Trim(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime parsedHSD))
                hsd = parsedHSD;

            var kq = _docGiaService.GiaHanThe(txtMaDG.Text.Trim(), hsd, chkDaDongLePhi.Checked);
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi");

            if (kq.ThanhCong)
            {
                LoadDanhSachDocGia();
            }
        }
    }
}