﻿namespace QuanLyThuVien.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlOuter = new System.Windows.Forms.Panel();
            this.lnkNXB = new System.Windows.Forms.LinkLabel();
            this.lnkTheLoai = new System.Windows.Forms.LinkLabel();
            this.lnkNhanVien = new System.Windows.Forms.LinkLabel();
            this.pnlNhanVien = new System.Windows.Forms.Panel();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtPhai = new System.Windows.Forms.TextBox();
            this.lblPhai = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtHo = new System.Windows.Forms.TextBox();
            this.lblHo = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.pnlTheLoai = new System.Windows.Forms.Panel();
            this.dgvTheLoai = new System.Windows.Forms.DataGridView();
            this.btnLamMoiTL = new System.Windows.Forms.Button();
            this.btnXoaTL = new System.Windows.Forms.Button();
            this.btnCapNhatTL = new System.Windows.Forms.Button();
            this.btnThemTL = new System.Windows.Forms.Button();
            this.txtTenTL = new System.Windows.Forms.TextBox();
            this.lblTenTL = new System.Windows.Forms.Label();
            this.txtMaTL = new System.Windows.Forms.TextBox();
            this.lblMaTL = new System.Windows.Forms.Label();
            this.pnlNXB = new System.Windows.Forms.Panel();
            this.dgvNXB = new System.Windows.Forms.DataGridView();
            this.btnLamMoiNXB = new System.Windows.Forms.Button();
            this.btnXoaNXB = new System.Windows.Forms.Button();
            this.btnCapNhatNXB = new System.Windows.Forms.Button();
            this.btnThemNXB = new System.Windows.Forms.Button();
            this.txtSDTNXB = new System.Windows.Forms.TextBox();
            this.lblSDTNXB = new System.Windows.Forms.Label();
            this.txtDiaChiNXB = new System.Windows.Forms.TextBox();
            this.lblDiaChiNXB = new System.Windows.Forms.Label();
            this.txtMaNXB = new System.Windows.Forms.TextBox();
            this.lblMaNXB = new System.Windows.Forms.Label();
            this.pnlOuter.SuspendLayout();
            this.pnlNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.pnlTheLoai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheLoai)).BeginInit();
            this.pnlNXB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNXB)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlOuter
            // 
            this.pnlOuter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlOuter.BackColor = System.Drawing.Color.White;
            this.pnlOuter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOuter.Controls.Add(this.pnlNhanVien);
            this.pnlOuter.Controls.Add(this.pnlTheLoai);
            this.pnlOuter.Controls.Add(this.pnlNXB);
            this.pnlOuter.Controls.Add(this.lnkNXB);
            this.pnlOuter.Controls.Add(this.lnkTheLoai);
            this.pnlOuter.Controls.Add(this.lnkNhanVien);
            this.pnlOuter.Location = new System.Drawing.Point(22, 18);
            this.pnlOuter.Name = "pnlOuter";
            this.pnlOuter.Size = new System.Drawing.Size(864, 520);
            this.pnlOuter.TabIndex = 0;
            // 
            // lnkNXB
            // 
            this.lnkNXB.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lnkNXB.AutoSize = true;
            this.lnkNXB.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lnkNXB.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkNXB.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lnkNXB.Location = new System.Drawing.Point(215, 18);
            this.lnkNXB.Name = "lnkNXB";
            this.lnkNXB.Size = new System.Drawing.Size(125, 23);
            this.lnkNXB.TabIndex = 2;
            this.lnkNXB.TabStop = true;
            this.lnkNXB.Text = "[Nhà xuất bản]";
            this.lnkNXB.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkNXB_LinkClicked);
            // 
            // lnkTheLoai
            // 
            this.lnkTheLoai.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lnkTheLoai.AutoSize = true;
            this.lnkTheLoai.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lnkTheLoai.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkTheLoai.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lnkTheLoai.Location = new System.Drawing.Point(125, 18);
            this.lnkTheLoai.Name = "lnkTheLoai";
            this.lnkTheLoai.Size = new System.Drawing.Size(81, 23);
            this.lnkTheLoai.TabIndex = 1;
            this.lnkTheLoai.TabStop = true;
            this.lnkTheLoai.Text = "[Thể loại]";
            this.lnkTheLoai.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTheLoai_LinkClicked);
            // 
            // lnkNhanVien
            // 
            this.lnkNhanVien.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lnkNhanVien.AutoSize = true;
            this.lnkNhanVien.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lnkNhanVien.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkNhanVien.LinkColor = System.Drawing.Color.Black;
            this.lnkNhanVien.Location = new System.Drawing.Point(20, 18);
            this.lnkNhanVien.Name = "lnkNhanVien";
            this.lnkNhanVien.Size = new System.Drawing.Size(102, 23);
            this.lnkNhanVien.TabIndex = 0;
            this.lnkNhanVien.TabStop = true;
            this.lnkNhanVien.Text = "[Nhân viên]";
            this.lnkNhanVien.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkNhanVien_LinkClicked);
            // 
            // pnlNhanVien
            // 
            this.pnlNhanVien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlNhanVien.Controls.Add(this.dgvNhanVien);
            this.pnlNhanVien.Controls.Add(this.btnLamMoi);
            this.pnlNhanVien.Controls.Add(this.btnXoa);
            this.pnlNhanVien.Controls.Add(this.btnCapNhat);
            this.pnlNhanVien.Controls.Add(this.btnThem);
            this.pnlNhanVien.Controls.Add(this.txtChucVu);
            this.pnlNhanVien.Controls.Add(this.lblChucVu);
            this.pnlNhanVien.Controls.Add(this.txtNgaySinh);
            this.pnlNhanVien.Controls.Add(this.lblNgaySinh);
            this.pnlNhanVien.Controls.Add(this.txtPhai);
            this.pnlNhanVien.Controls.Add(this.lblPhai);
            this.pnlNhanVien.Controls.Add(this.txtTen);
            this.pnlNhanVien.Controls.Add(this.lblTen);
            this.pnlNhanVien.Controls.Add(this.txtHo);
            this.pnlNhanVien.Controls.Add(this.lblHo);
            this.pnlNhanVien.Controls.Add(this.txtMaNV);
            this.pnlNhanVien.Controls.Add(this.lblMaNV);
            this.pnlNhanVien.Location = new System.Drawing.Point(10, 48);
            this.pnlNhanVien.Name = "pnlNhanVien";
            this.pnlNhanVien.Size = new System.Drawing.Size(842, 460);
            this.pnlNhanVien.TabIndex = 3;
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AllowUserToAddRows = false;
            this.dgvNhanVien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.BackgroundColor = System.Drawing.Color.White;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Location = new System.Drawing.Point(15, 135);
            this.dgvNhanVien.MultiSelect = false;
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.ReadOnly = true;
            this.dgvNhanVien.RowHeadersVisible = false;
            this.dgvNhanVien.RowHeadersWidth = 51;
            this.dgvNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNhanVien.Size = new System.Drawing.Size(812, 310);
            this.dgvNhanVien.TabIndex = 16;
            this.dgvNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellClick);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoi.Location = new System.Drawing.Point(705, 47);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(105, 30);
            this.btnLamMoi.TabIndex = 15;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoa.Location = new System.Drawing.Point(585, 47);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(105, 30);
            this.btnXoa.TabIndex = 14;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCapNhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapNhat.Location = new System.Drawing.Point(705, 9);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(105, 30);
            this.btnCapNhat.TabIndex = 13;
            this.btnCapNhat.Text = "Cập nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // btnThem
            // 
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThem.Location = new System.Drawing.Point(585, 9);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(105, 30);
            this.btnThem.TabIndex = 12;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtChucVu
            // 
            this.txtChucVu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtChucVu.Location = new System.Drawing.Point(400, 86);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(155, 29);
            this.txtChucVu.TabIndex = 11;
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblChucVu.Location = new System.Drawing.Point(315, 89);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(69, 21);
            this.lblChucVu.TabIndex = 10;
            this.lblChucVu.Text = "Chức vụ:";
            // 
            // txtNgaySinh
            // 
            this.txtNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNgaySinh.Location = new System.Drawing.Point(400, 48);
            this.txtNgaySinh.Name = "txtNgaySinh";
            this.txtNgaySinh.Size = new System.Drawing.Size(155, 29);
            this.txtNgaySinh.TabIndex = 9;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgaySinh.Location = new System.Drawing.Point(315, 51);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(83, 21);
            this.lblNgaySinh.TabIndex = 8;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // txtPhai
            // 
            this.txtPhai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhai.Location = new System.Drawing.Point(400, 10);
            this.txtPhai.Name = "txtPhai";
            this.txtPhai.Size = new System.Drawing.Size(155, 29);
            this.txtPhai.TabIndex = 7;
            //
            // lblPhai
            // 
            this.lblPhai.AutoSize = true;
            this.lblPhai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhai.Location = new System.Drawing.Point(315, 13);
            this.lblPhai.Name = "lblPhai";
            this.lblPhai.Size = new System.Drawing.Size(43, 21);
            this.lblPhai.TabIndex = 6;
            this.lblPhai.Text = "Phái:";
            // 
            // txtTen
            // 
            this.txtTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTen.Location = new System.Drawing.Point(125, 86);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(160, 29);
            this.txtTen.TabIndex = 5;
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTen.Location = new System.Drawing.Point(15, 89);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(36, 21);
            this.lblTen.TabIndex = 4;
            this.lblTen.Text = "Tên:";
            // 
            // txtHo
            // 
            this.txtHo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHo.Location = new System.Drawing.Point(125, 48);
            this.txtHo.Name = "txtHo";
            this.txtHo.Size = new System.Drawing.Size(160, 29);
            this.txtHo.TabIndex = 3;
            // 
            // lblHo
            // 
            this.lblHo.AutoSize = true;
            this.lblHo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHo.Location = new System.Drawing.Point(15, 51);
            this.lblHo.Name = "lblHo";
            this.lblHo.Size = new System.Drawing.Size(33, 21);
            this.lblHo.TabIndex = 2;
            this.lblHo.Text = "Họ:";
            // 
            // txtMaNV
            // 
            this.txtMaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaNV.Location = new System.Drawing.Point(125, 10);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(160, 29);
            this.txtMaNV.TabIndex = 1;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaNV.Location = new System.Drawing.Point(15, 13);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(107, 21);
            this.lblMaNV.TabIndex = 0;
            this.lblMaNV.Text = "Mã nhân viên:";
            // 
            // pnlTheLoai
            // 
            this.pnlTheLoai.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
| System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTheLoai.Controls.Add(this.dgvTheLoai);
            this.pnlTheLoai.Controls.Add(this.btnLamMoiTL);
            this.pnlTheLoai.Controls.Add(this.btnXoaTL);
            this.pnlTheLoai.Controls.Add(this.btnCapNhatTL);
            this.pnlTheLoai.Controls.Add(this.btnThemTL);
            this.pnlTheLoai.Controls.Add(this.txtTenTL);
            this.pnlTheLoai.Controls.Add(this.lblTenTL);
            this.pnlTheLoai.Controls.Add(this.txtMaTL);
            this.pnlTheLoai.Controls.Add(this.lblMaTL);
            this.pnlTheLoai.Location = new System.Drawing.Point(10, 48);
            this.pnlTheLoai.Name = "pnlTheLoai";
            this.pnlTheLoai.Size = new System.Drawing.Size(842, 460);
            this.pnlTheLoai.TabIndex = 4;
            this.pnlTheLoai.Visible = false;
            // 
            // dgvTheLoai
            // 
            this.dgvTheLoai.AllowUserToAddRows = false;
            this.dgvTheLoai.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTheLoai.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheLoai.BackgroundColor = System.Drawing.Color.White;
            this.dgvTheLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheLoai.Location = new System.Drawing.Point(15, 135);
            this.dgvTheLoai.MultiSelect = false;
            this.dgvTheLoai.Name = "dgvTheLoai";
            this.dgvTheLoai.ReadOnly = true;
            this.dgvTheLoai.RowHeadersVisible = false;
            this.dgvTheLoai.RowHeadersWidth = 51;
            this.dgvTheLoai.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTheLoai.Size = new System.Drawing.Size(812, 310);
            this.dgvTheLoai.TabIndex = 8;
            this.dgvTheLoai.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTheLoai_CellClick);
            // 
            // btnLamMoiTL
            // 
            this.btnLamMoiTL.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLamMoiTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiTL.Location = new System.Drawing.Point(705, 47);
            this.btnLamMoiTL.Name = "btnLamMoiTL";
            this.btnLamMoiTL.Size = new System.Drawing.Size(105, 30);
            this.btnLamMoiTL.TabIndex = 7;
            this.btnLamMoiTL.Text = "Làm mới";
            this.btnLamMoiTL.UseVisualStyleBackColor = true;
            this.btnLamMoiTL.Click += new System.EventHandler(this.btnLamMoiTL_Click);
            // 
            // btnXoaTL
            // 
            this.btnXoaTL.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnXoaTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaTL.Location = new System.Drawing.Point(585, 47);
            this.btnXoaTL.Name = "btnXoaTL";
            this.btnXoaTL.Size = new System.Drawing.Size(105, 30);
            this.btnXoaTL.TabIndex = 6;
            this.btnXoaTL.Text = "Xóa";
            this.btnXoaTL.UseVisualStyleBackColor = true;
            this.btnXoaTL.Click += new System.EventHandler(this.btnXoaTL_Click);
            // 
            // btnCapNhatTL
            // 
            this.btnCapNhatTL.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCapNhatTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapNhatTL.Location = new System.Drawing.Point(705, 9);
            this.btnCapNhatTL.Name = "btnCapNhatTL";
            this.btnCapNhatTL.Size = new System.Drawing.Size(105, 30);
            this.btnCapNhatTL.TabIndex = 5;
            this.btnCapNhatTL.Text = "Cập nhật";
            this.btnCapNhatTL.UseVisualStyleBackColor = true;
            this.btnCapNhatTL.Click += new System.EventHandler(this.btnCapNhatTL_Click);
            // 
            // btnThemTL
            // 
            this.btnThemTL.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThemTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThemTL.Location = new System.Drawing.Point(585, 9);
            this.btnThemTL.Name = "btnThemTL";
            this.btnThemTL.Size = new System.Drawing.Size(105, 30);
            this.btnThemTL.TabIndex = 4;
            this.btnThemTL.Text = "Thêm";
            this.btnThemTL.UseVisualStyleBackColor = true;
            this.btnThemTL.Click += new System.EventHandler(this.btnThemTL_Click);
            // 
            // txtTenTL
            // 
            this.txtTenTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTenTL.Location = new System.Drawing.Point(125, 48);
            this.txtTenTL.Name = "txtTenTL";
            this.txtTenTL.Size = new System.Drawing.Size(250, 29);
            this.txtTenTL.TabIndex = 3;
            // 
            // lblTenTL
            // 
            this.lblTenTL.AutoSize = true;
            this.lblTenTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTenTL.Location = new System.Drawing.Point(15, 51);
            this.lblTenTL.Name = "lblTenTL";
            this.lblTenTL.Size = new System.Drawing.Size(92, 21);
            this.lblTenTL.TabIndex = 2;
            this.lblTenTL.Text = "Tên thể loại:";
            // 
            // txtMaTL
            // 
            this.txtMaTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaTL.Location = new System.Drawing.Point(125, 10);
            this.txtMaTL.Name = "txtMaTL";
            this.txtMaTL.Size = new System.Drawing.Size(250, 29);
            this.txtMaTL.TabIndex = 1;
            // 
            // lblMaTL
            //
            this.lblMaTL.AutoSize = true;
            this.lblMaTL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaTL.Location = new System.Drawing.Point(15, 13);
            this.lblMaTL.Name = "lblMaTL";
            this.lblMaTL.Size = new System.Drawing.Size(90, 21);
            this.lblMaTL.TabIndex = 0;
            this.lblMaTL.Text = "Mã thể loại:";
            // 
            // pnlNXB
            // 
            this.pnlNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlNXB.Controls.Add(this.dgvNXB);
            this.pnlNXB.Controls.Add(this.btnLamMoiNXB);
            this.pnlNXB.Controls.Add(this.btnXoaNXB);
            this.pnlNXB.Controls.Add(this.btnCapNhatNXB);
            this.pnlNXB.Controls.Add(this.btnThemNXB);
            this.pnlNXB.Controls.Add(this.txtSDTNXB);
            this.pnlNXB.Controls.Add(this.lblSDTNXB);
            this.pnlNXB.Controls.Add(this.txtDiaChiNXB);
            this.pnlNXB.Controls.Add(this.lblDiaChiNXB);
            this.pnlNXB.Controls.Add(this.txtMaNXB);
            this.pnlNXB.Controls.Add(this.lblMaNXB);
            this.pnlNXB.Location = new System.Drawing.Point(10, 48);
            this.pnlNXB.Name = "pnlNXB";
            this.pnlNXB.Size = new System.Drawing.Size(842, 460);
            this.pnlNXB.TabIndex = 5;
            this.pnlNXB.Visible = false;
            // 
            // dgvNXB
            // 
            this.dgvNXB.AllowUserToAddRows = false;
            this.dgvNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvNXB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNXB.BackgroundColor = System.Drawing.Color.White;
            this.dgvNXB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNXB.Location = new System.Drawing.Point(15, 135);
            this.dgvNXB.MultiSelect = false;
            this.dgvNXB.Name = "dgvNXB";
            this.dgvNXB.ReadOnly = true;
            this.dgvNXB.RowHeadersVisible = false;
            this.dgvNXB.RowHeadersWidth = 51;
            this.dgvNXB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNXB.Size = new System.Drawing.Size(812, 310);
            this.dgvNXB.TabIndex = 10;
            this.dgvNXB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNXB_CellClick);
            // 
            // btnLamMoiNXB
            // 
            this.btnLamMoiNXB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLamMoiNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiNXB.Location = new System.Drawing.Point(705, 47);
            this.btnLamMoiNXB.Name = "btnLamMoiNXB";
            this.btnLamMoiNXB.Size = new System.Drawing.Size(105, 30);
            this.btnLamMoiNXB.TabIndex = 9;
            this.btnLamMoiNXB.Text = "Làm mới";
            this.btnLamMoiNXB.UseVisualStyleBackColor = true;
            this.btnLamMoiNXB.Click += new System.EventHandler(this.btnLamMoiNXB_Click);
            // 
            // btnXoaNXB
            // 
            this.btnXoaNXB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnXoaNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaNXB.Location = new System.Drawing.Point(585, 47);
            this.btnXoaNXB.Name = "btnXoaNXB";
            this.btnXoaNXB.Size = new System.Drawing.Size(105, 30);
            this.btnXoaNXB.TabIndex = 8;
            this.btnXoaNXB.Text = "Xóa";
            this.btnXoaNXB.UseVisualStyleBackColor = true;
            this.btnXoaNXB.Click += new System.EventHandler(this.btnXoaNXB_Click);
            // 
            // btnCapNhatNXB
            // 
            this.btnCapNhatNXB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCapNhatNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapNhatNXB.Location = new System.Drawing.Point(705, 9);
            this.btnCapNhatNXB.Name = "btnCapNhatNXB";
            this.btnCapNhatNXB.Size = new System.Drawing.Size(105, 30);
            this.btnCapNhatNXB.TabIndex = 7;
            this.btnCapNhatNXB.Text = "Cập nhật";
            this.btnCapNhatNXB.UseVisualStyleBackColor = true;
            this.btnCapNhatNXB.Click += new System.EventHandler(this.btnCapNhatNXB_Click);
            // 
            // btnThemNXB
            // 
            this.btnThemNXB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThemNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThemNXB.Location = new System.Drawing.Point(585, 9);
            this.btnThemNXB.Name = "btnThemNXB";
            this.btnThemNXB.Size = new System.Drawing.Size(105, 30);
            this.btnThemNXB.TabIndex = 6;
            this.btnThemNXB.Text = "Thêm";
            this.btnThemNXB.UseVisualStyleBackColor = true;
            this.btnThemNXB.Click += new System.EventHandler(this.btnThemNXB_Click);
            // 
            // txtSDTNXB
            // 
            this.txtSDTNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSDTNXB.Location = new System.Drawing.Point(125, 86);
            this.txtSDTNXB.Name = "txtSDTNXB";
            this.txtSDTNXB.Size = new System.Drawing.Size(250, 29);
            this.txtSDTNXB.TabIndex = 5;
            // 
            // lblSDTNXB
            // 
            this.lblSDTNXB.AutoSize = true;
            this.lblSDTNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSDTNXB.Location = new System.Drawing.Point(15, 89);
            this.lblSDTNXB.Name = "lblSDTNXB";
            this.lblSDTNXB.Size = new System.Drawing.Size(104, 21);
            this.lblSDTNXB.TabIndex = 4;
            this.lblSDTNXB.Text = "Số điện thoại:";
            // 
            // txtDiaChiNXB
            // 
            this.txtDiaChiNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDiaChiNXB.Location = new System.Drawing.Point(125, 48);
            this.txtDiaChiNXB.Name = "txtDiaChiNXB";
            this.txtDiaChiNXB.Size = new System.Drawing.Size(250, 29);
            this.txtDiaChiNXB.TabIndex = 3;
            // 
            // lblDiaChiNXB
            // 
            this.lblDiaChiNXB.AutoSize = true;
            this.lblDiaChiNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiaChiNXB.Location = new System.Drawing.Point(15, 51);
            this.lblDiaChiNXB.Name = "lblDiaChiNXB";
            this.lblDiaChiNXB.Size = new System.Drawing.Size(60, 21);
            this.lblDiaChiNXB.TabIndex = 2;
            this.lblDiaChiNXB.Text = "Địa chỉ:";
            // 
            // txtMaNXB
            // 
            this.txtMaNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaNXB.Location = new System.Drawing.Point(125, 10);
            this.txtMaNXB.Name = "txtMaNXB";
            this.txtMaNXB.Size = new System.Drawing.Size(250, 29);
            this.txtMaNXB.TabIndex = 1;
            // 
            // lblMaNXB
            // 
            this.lblMaNXB.AutoSize = true;
            this.lblMaNXB.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaNXB.Location = new System.Drawing.Point(15, 13);
            this.lblMaNXB.Name = "lblMaNXB";
            this.lblMaNXB.Size = new System.Drawing.Size(70, 21);
            this.lblMaNXB.TabIndex = 0;
            this.lblMaNXB.Text = "Mã NXB:";
            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(910, 560);
            this.Controls.Add(this.pnlOuter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục và nhân viên";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            this.pnlOuter.ResumeLayout(false);
            this.pnlOuter.PerformLayout();
            this.pnlNhanVien.ResumeLayout(false);
            this.pnlNhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.pnlTheLoai.ResumeLayout(false);
            this.pnlTheLoai.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheLoai)).EndInit();
            this.pnlNXB.ResumeLayout(false);
            this.pnlNXB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNXB)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlOuter;
        private System.Windows.Forms.LinkLabel lnkNhanVien;
        private System.Windows.Forms.LinkLabel lnkTheLoai;
        private System.Windows.Forms.LinkLabel lnkNXB;
        private System.Windows.Forms.Panel pnlNhanVien;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblHo;
        private System.Windows.Forms.TextBox txtHo;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblPhai;
        private System.Windows.Forms.TextBox txtPhai;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.DataGridView dgvNhanVien;

        private System.Windows.Forms.Panel pnlTheLoai;
        private System.Windows.Forms.Label lblMaTL;
        private System.Windows.Forms.TextBox txtMaTL;
        private System.Windows.Forms.Label lblTenTL;
        private System.Windows.Forms.TextBox txtTenTL;
        private System.Windows.Forms.Button btnThemTL;
        private System.Windows.Forms.Button btnCapNhatTL;
        private System.Windows.Forms.Button btnXoaTL;
        private System.Windows.Forms.Button btnLamMoiTL;
        private System.Windows.Forms.DataGridView dgvTheLoai;

        private System.Windows.Forms.Panel pnlNXB;
        private System.Windows.Forms.Label lblMaNXB;
        private System.Windows.Forms.TextBox txtMaNXB;
        private System.Windows.Forms.Label lblDiaChiNXB;
        private System.Windows.Forms.TextBox txtDiaChiNXB;
        private System.Windows.Forms.Label lblSDTNXB;
        private System.Windows.Forms.TextBox txtSDTNXB;
        private System.Windows.Forms.Button btnThemNXB;
        private System.Windows.Forms.Button btnCapNhatNXB;
        private System.Windows.Forms.Button btnXoaNXB;
        private System.Windows.Forms.Button btnLamMoiNXB;
        private System.Windows.Forms.DataGridView dgvNXB;
    }
}