﻿namespace QuanLyThuVien.Forms
{
    partial class FrmMuonTra
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlOuter = new System.Windows.Forms.Panel();
            this.pnlMuonSach = new System.Windows.Forms.Panel();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            this.dgvSachChon = new System.Windows.Forms.DataGridView();
            this.lblSachChon = new System.Windows.Forms.Label();
            this.btnBoSach = new System.Windows.Forms.Button();
            this.btnThemSach = new System.Windows.Forms.Button();
            this.dgvKhoSach = new System.Windows.Forms.DataGridView();
            this.lblKhoSach = new System.Windows.Forms.Label();
            this.txtHenTra = new System.Windows.Forms.TextBox();
            this.lblHenTra = new System.Windows.Forms.Label();
            this.txtNgayMuon = new System.Windows.Forms.TextBox();
            this.lblNgayMuon = new System.Windows.Forms.Label();
            this.cboNhanVien = new System.Windows.Forms.ComboBox();
            this.lblNV = new System.Windows.Forms.Label();
            this.lblDieuKienStatus = new System.Windows.Forms.Label();
            this.btnKiemTraDieuKien = new System.Windows.Forms.Button();
            this.cboDocGia = new System.Windows.Forms.ComboBox();
            this.lblDocGia = new System.Windows.Forms.Label();
            this.pnlTraSach = new System.Windows.Forms.Panel();
            this.btnXacNhanTra = new System.Windows.Forms.Button();
            this.txtLyDoPhat = new System.Windows.Forms.TextBox();
            this.lblLyDoPhat = new System.Windows.Forms.Label();
            this.nudPhiPhat = new System.Windows.Forms.NumericUpDown();
            this.lblPhiPhat = new System.Windows.Forms.Label();
            this.cboTinhTrang = new System.Windows.Forms.ComboBox();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.txtNgayTra = new System.Windows.Forms.TextBox();
            this.lblNgayTra = new System.Windows.Forms.Label();
            this.txtInfoSachTra = new System.Windows.Forms.TextBox();
            this.lblInfoSachTra = new System.Windows.Forms.Label();
            this.dgvDangMuon = new System.Windows.Forms.DataGridView();
            this.txtTimKiemTra = new System.Windows.Forms.TextBox();
            this.lblTimKiemTra = new System.Windows.Forms.Label();
            this.lnkTraSach = new System.Windows.Forms.LinkLabel();
            this.lnkMuonSach = new System.Windows.Forms.LinkLabel();
            this.pnlOuter.SuspendLayout();
            this.pnlMuonSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachChon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoSach)).BeginInit();
            this.pnlTraSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPhiPhat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangMuon)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlOuter
            // 
            this.pnlOuter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlOuter.BackColor = System.Drawing.Color.White;
            this.pnlOuter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOuter.Controls.Add(this.pnlMuonSach);
            this.pnlOuter.Controls.Add(this.pnlTraSach);
            this.pnlOuter.Controls.Add(this.lnkTraSach);
            this.pnlOuter.Controls.Add(this.lnkMuonSach);
            this.pnlOuter.Location = new System.Drawing.Point(14, 13);
            this.pnlOuter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOuter.Name = "pnlOuter";
            this.pnlOuter.Size = new System.Drawing.Size(729, 438);
            this.pnlOuter.TabIndex = 0;
            // 
            // pnlMuonSach
            // 
            this.pnlMuonSach.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMuonSach.Controls.Add(this.btnLapPhieu);
            this.pnlMuonSach.Controls.Add(this.dgvSachChon);
            this.pnlMuonSach.Controls.Add(this.lblSachChon);
            this.pnlMuonSach.Controls.Add(this.btnBoSach);
            this.pnlMuonSach.Controls.Add(this.btnThemSach);
            this.pnlMuonSach.Controls.Add(this.dgvKhoSach);
            this.pnlMuonSach.Controls.Add(this.lblKhoSach);
            this.pnlMuonSach.Controls.Add(this.txtHenTra);
            this.pnlMuonSach.Controls.Add(this.lblHenTra);
            this.pnlMuonSach.Controls.Add(this.txtNgayMuon);
            this.pnlMuonSach.Controls.Add(this.lblNgayMuon);
            this.pnlMuonSach.Controls.Add(this.cboNhanVien);
            this.pnlMuonSach.Controls.Add(this.lblNV);
            this.pnlMuonSach.Controls.Add(this.lblDieuKienStatus);
            this.pnlMuonSach.Controls.Add(this.btnKiemTraDieuKien);
            this.pnlMuonSach.Controls.Add(this.cboDocGia);
            this.pnlMuonSach.Controls.Add(this.lblDocGia);
            this.pnlMuonSach.Location = new System.Drawing.Point(8, 37);
            this.pnlMuonSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlMuonSach.Name = "pnlMuonSach";
            this.pnlMuonSach.Size = new System.Drawing.Size(712, 390);
            this.pnlMuonSach.TabIndex = 2;
            // 
            // btnLapPhieu
            // 
            this.btnLapPhieu.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLapPhieu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapPhieu.Location = new System.Drawing.Point(488, 348);
            this.btnLapPhieu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLapPhieu.Name = "btnLapPhieu";
            this.btnLapPhieu.Size = new System.Drawing.Size(105, 28);
            this.btnLapPhieu.TabIndex = 16;
            this.btnLapPhieu.Text = "Lập phiếu mượn";
            this.btnLapPhieu.UseVisualStyleBackColor = true;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);
            // 
            // dgvSachChon
            // 
            this.dgvSachChon.AllowUserToAddRows = false;
            this.dgvSachChon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSachChon.BackgroundColor = System.Drawing.Color.White;
            this.dgvSachChon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSachChon.Location = new System.Drawing.Point(371, 114);
            this.dgvSachChon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvSachChon.MultiSelect = false;
            this.dgvSachChon.Name = "dgvSachChon";
            this.dgvSachChon.ReadOnly = true;
            this.dgvSachChon.RowHeadersVisible = false;
            this.dgvSachChon.RowHeadersWidth = 51;
            this.dgvSachChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSachChon.Size = new System.Drawing.Size(285, 223);
            this.dgvSachChon.TabIndex = 15;
            // 
            // lblSachChon
            // 
            this.lblSachChon.AutoSize = true;
            this.lblSachChon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSachChon.Location = new System.Drawing.Point(371, 91);
            this.lblSachChon.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSachChon.Name = "lblSachChon";
            this.lblSachChon.Size = new System.Drawing.Size(146, 17);
            this.lblSachChon.TabIndex = 14;
            this.lblSachChon.Text = "Sách đã chọn (tối đa 3):";
            // 
            // btnBoSach
            // 
            this.btnBoSach.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBoSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnBoSach.Location = new System.Drawing.Point(308, 207);
            this.btnBoSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBoSach.Name = "btnBoSach";
            this.btnBoSach.Size = new System.Drawing.Size(54, 26);
            this.btnBoSach.TabIndex = 13;
            this.btnBoSach.Text = "<< Bỏ";
            this.btnBoSach.UseVisualStyleBackColor = true;
            this.btnBoSach.Click += new System.EventHandler(this.btnBoSach_Click);
            // 
            // btnThemSach
            // 
            this.btnThemSach.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThemSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThemSach.Location = new System.Drawing.Point(308, 171);
            this.btnThemSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnThemSach.Name = "btnThemSach";
            this.btnThemSach.Size = new System.Drawing.Size(54, 26);
            this.btnThemSach.TabIndex = 12;
            this.btnThemSach.Text = "Thêm >>";
            this.btnThemSach.UseVisualStyleBackColor = true;
            this.btnThemSach.Click += new System.EventHandler(this.btnThemSach_Click);
            // 
            // dgvKhoSach
            // 
            this.dgvKhoSach.AllowUserToAddRows = false;
            this.dgvKhoSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhoSach.BackgroundColor = System.Drawing.Color.White;
            this.dgvKhoSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhoSach.Location = new System.Drawing.Point(11, 114);
            this.dgvKhoSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvKhoSach.MultiSelect = false;
            this.dgvKhoSach.Name = "dgvKhoSach";
            this.dgvKhoSach.ReadOnly = true;
            this.dgvKhoSach.RowHeadersVisible = false;
            this.dgvKhoSach.RowHeadersWidth = 51;
            this.dgvKhoSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKhoSach.Size = new System.Drawing.Size(285, 262);
            this.dgvKhoSach.TabIndex = 11;
            // 
            // lblKhoSach
            // 
            this.lblKhoSach.AutoSize = true;
            this.lblKhoSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblKhoSach.Location = new System.Drawing.Point(11, 91);
            this.lblKhoSach.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKhoSach.Name = "lblKhoSach";
            this.lblKhoSach.Size = new System.Drawing.Size(124, 17);
            this.lblKhoSach.TabIndex = 10;
            this.lblKhoSach.Text = "Sách còn trong kho:";
            // 
            // txtHenTra
            // 
            this.txtHenTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHenTra.Location = new System.Drawing.Point(465, 46);
            this.txtHenTra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtHenTra.Name = "txtHenTra";
            this.txtHenTra.Size = new System.Drawing.Size(87, 24);
            this.txtHenTra.TabIndex = 9;
            // 
            // lblHenTra
            // 
            this.lblHenTra.AutoSize = true;
            this.lblHenTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHenTra.Location = new System.Drawing.Point(412, 49);
            this.lblHenTra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHenTra.Name = "lblHenTra";
            this.lblHenTra.Size = new System.Drawing.Size(54, 17);
            this.lblHenTra.TabIndex = 8;
            this.lblHenTra.Text = "Hẹn trả:";
            // 
            // txtNgayMuon
            // 
            this.txtNgayMuon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNgayMuon.Location = new System.Drawing.Point(304, 46);
            this.txtNgayMuon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNgayMuon.Name = "txtNgayMuon";
            this.txtNgayMuon.Size = new System.Drawing.Size(87, 24);
            this.txtNgayMuon.TabIndex = 7;
            // 
            // lblNgayMuon
            // 
            this.lblNgayMuon.AutoSize = true;
            this.lblNgayMuon.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayMuon.Location = new System.Drawing.Point(229, 49);
            this.lblNgayMuon.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNgayMuon.Name = "lblNgayMuon";
            this.lblNgayMuon.Size = new System.Drawing.Size(80, 17);
            this.lblNgayMuon.TabIndex = 6;
            this.lblNgayMuon.Text = "Ngày mượn:";
            // 
            // cboNhanVien
            // 
            this.cboNhanVien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhanVien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNhanVien.FormattingEnabled = true;
            this.cboNhanVien.Location = new System.Drawing.Point(128, 46);
            this.cboNhanVien.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboNhanVien.Name = "cboNhanVien";
            this.cboNhanVien.Size = new System.Drawing.Size(87, 25);
            this.cboNhanVien.TabIndex = 5;
            // 
            // lblNV
            // 
            this.lblNV.AutoSize = true;
            this.lblNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV.Location = new System.Drawing.Point(11, 49);
            this.lblNV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNV.Name = "lblNV";
            this.lblNV.Size = new System.Drawing.Size(127, 17);
            this.lblNV.TabIndex = 4;
            this.lblNV.Text = "Nhân viên lập phiếu:";
            // 
            // lblDieuKienStatus
            // 
            this.lblDieuKienStatus.AutoSize = true;
            this.lblDieuKienStatus.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDieuKienStatus.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblDieuKienStatus.Location = new System.Drawing.Point(380, 13);
            this.lblDieuKienStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDieuKienStatus.Name = "lblDieuKienStatus";
            this.lblDieuKienStatus.Size = new System.Drawing.Size(148, 17);
            this.lblDieuKienStatus.TabIndex = 3;
            this.lblDieuKienStatus.Text = "Đủ điều kiện mượn sách";
            // 
            // btnKiemTraDieuKien
            // 
            this.btnKiemTraDieuKien.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnKiemTraDieuKien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnKiemTraDieuKien.Location = new System.Drawing.Point(255, 9);
            this.btnKiemTraDieuKien.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnKiemTraDieuKien.Name = "btnKiemTraDieuKien";
            this.btnKiemTraDieuKien.Size = new System.Drawing.Size(121, 24);
            this.btnKiemTraDieuKien.TabIndex = 2;
            this.btnKiemTraDieuKien.Text = "Kiểm tra điều kiện";
            this.btnKiemTraDieuKien.UseVisualStyleBackColor = true;
            this.btnKiemTraDieuKien.Click += new System.EventHandler(this.btnKiemTraDieuKien_Click);
            // 
            // cboDocGia
            // 
            this.cboDocGia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDocGia.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboDocGia.FormattingEnabled = true;
            this.cboDocGia.Location = new System.Drawing.Point(68, 10);
            this.cboDocGia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboDocGia.Name = "cboDocGia";
            this.cboDocGia.Size = new System.Drawing.Size(177, 25);
            this.cboDocGia.TabIndex = 1;
            // 
            // lblDocGia
            // 
            this.lblDocGia.AutoSize = true;
            this.lblDocGia.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDocGia.Location = new System.Drawing.Point(11, 13);
            this.lblDocGia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDocGia.Name = "lblDocGia";
            this.lblDocGia.Size = new System.Drawing.Size(56, 17);
            this.lblDocGia.TabIndex = 0;
            this.lblDocGia.Text = "Độc giả:";
            // 
            // pnlTraSach
            // 
            this.pnlTraSach.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTraSach.Controls.Add(this.btnXacNhanTra);
            this.pnlTraSach.Controls.Add(this.txtLyDoPhat);
            this.pnlTraSach.Controls.Add(this.lblLyDoPhat);
            this.pnlTraSach.Controls.Add(this.nudPhiPhat);
            this.pnlTraSach.Controls.Add(this.lblPhiPhat);
            this.pnlTraSach.Controls.Add(this.cboTinhTrang);
            this.pnlTraSach.Controls.Add(this.lblTinhTrang);
            this.pnlTraSach.Controls.Add(this.txtNgayTra);
            this.pnlTraSach.Controls.Add(this.lblNgayTra);
            this.pnlTraSach.Controls.Add(this.txtInfoSachTra);
            this.pnlTraSach.Controls.Add(this.lblInfoSachTra);
            this.pnlTraSach.Controls.Add(this.dgvDangMuon);
            this.pnlTraSach.Controls.Add(this.txtTimKiemTra);
            this.pnlTraSach.Controls.Add(this.lblTimKiemTra);
            this.pnlTraSach.Location = new System.Drawing.Point(8, 37);
            this.pnlTraSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlTraSach.Name = "pnlTraSach";
            this.pnlTraSach.Size = new System.Drawing.Size(712, 390);
            this.pnlTraSach.TabIndex = 3;
            this.pnlTraSach.Visible = false;
            // 
            // btnXacNhanTra
            // 
            this.btnXacNhanTra.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnXacNhanTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXacNhanTra.Location = new System.Drawing.Point(536, 351);
            this.btnXacNhanTra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnXacNhanTra.Name = "btnXacNhanTra";
            this.btnXacNhanTra.Size = new System.Drawing.Size(120, 28);
            this.btnXacNhanTra.TabIndex = 13;
            this.btnXacNhanTra.Text = "Xác nhận trả sách";
            this.btnXacNhanTra.UseVisualStyleBackColor = true;
            this.btnXacNhanTra.Click += new System.EventHandler(this.btnXacNhanTra_Click);
            // 
            // txtLyDoPhat
            // 
            this.txtLyDoPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtLyDoPhat.Location = new System.Drawing.Point(285, 353);
            this.txtLyDoPhat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLyDoPhat.Name = "txtLyDoPhat";
            this.txtLyDoPhat.Size = new System.Drawing.Size(237, 24);
            this.txtLyDoPhat.TabIndex = 12;
            // 
            // lblLyDoPhat
            // 
            this.lblLyDoPhat.AutoSize = true;
            this.lblLyDoPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLyDoPhat.Location = new System.Drawing.Point(221, 356);
            this.lblLyDoPhat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLyDoPhat.Name = "lblLyDoPhat";
            this.lblLyDoPhat.Size = new System.Drawing.Size(72, 17);
            this.lblLyDoPhat.TabIndex = 11;
            this.lblLyDoPhat.Text = "Lý do phạt:";
            // 
            // nudPhiPhat
            // 
            this.nudPhiPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.nudPhiPhat.Increment = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPhiPhat.Location = new System.Drawing.Point(94, 353);
            this.nudPhiPhat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nudPhiPhat.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudPhiPhat.Name = "nudPhiPhat";
            this.nudPhiPhat.Size = new System.Drawing.Size(112, 24);
            this.nudPhiPhat.TabIndex = 10;
            // 
            // lblPhiPhat
            // 
            this.lblPhiPhat.AutoSize = true;
            this.lblPhiPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhiPhat.Location = new System.Drawing.Point(11, 356);
            this.lblPhiPhat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPhiPhat.Name = "lblPhiPhat";
            this.lblPhiPhat.Size = new System.Drawing.Size(97, 17);
            this.lblPhiPhat.TabIndex = 9;
            this.lblPhiPhat.Text = "Phí phạt (VNĐ):";
            // 
            // cboTinhTrang
            // 
            this.cboTinhTrang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTinhTrang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboTinhTrang.FormattingEnabled = true;
            this.cboTinhTrang.Items.AddRange(new object[] {
            "Nguyên vẹn",
            "Rách / Hư hỏng nhẹ",
            "Hư hỏng nặng",
            "Mất sách"});
            this.cboTinhTrang.Location = new System.Drawing.Point(300, 321);
            this.cboTinhTrang.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboTinhTrang.Name = "cboTinhTrang";
            this.cboTinhTrang.Size = new System.Drawing.Size(144, 25);
            this.cboTinhTrang.TabIndex = 8;
            this.cboTinhTrang.SelectedIndexChanged += new System.EventHandler(this.cboTinhTrang_SelectedIndexChanged);
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTinhTrang.Location = new System.Drawing.Point(236, 323);
            this.lblTinhTrang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(70, 17);
            this.lblTinhTrang.TabIndex = 7;
            this.lblTinhTrang.Text = "Tình trạng:";
            // 
            // txtNgayTra
            // 
            this.txtNgayTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNgayTra.Location = new System.Drawing.Point(94, 321);
            this.txtNgayTra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNgayTra.Name = "txtNgayTra";
            this.txtNgayTra.Size = new System.Drawing.Size(114, 24);
            this.txtNgayTra.TabIndex = 6;
            // 
            // lblNgayTra
            // 
            this.lblNgayTra.AutoSize = true;
            this.lblNgayTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayTra.Location = new System.Drawing.Point(11, 323);
            this.lblNgayTra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNgayTra.Name = "lblNgayTra";
            this.lblNgayTra.Size = new System.Drawing.Size(80, 17);
            this.lblNgayTra.TabIndex = 5;
            this.lblNgayTra.Text = "Ngày trả TT:";
            // 
            // txtInfoSachTra
            // 
            this.txtInfoSachTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtInfoSachTra.Location = new System.Drawing.Point(94, 288);
            this.txtInfoSachTra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtInfoSachTra.Name = "txtInfoSachTra";
            this.txtInfoSachTra.ReadOnly = true;
            this.txtInfoSachTra.Size = new System.Drawing.Size(564, 24);
            this.txtInfoSachTra.TabIndex = 4;
            // 
            // lblInfoSachTra
            // 
            this.lblInfoSachTra.AutoSize = true;
            this.lblInfoSachTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblInfoSachTra.Location = new System.Drawing.Point(11, 291);
            this.lblInfoSachTra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInfoSachTra.Name = "lblInfoSachTra";
            this.lblInfoSachTra.Size = new System.Drawing.Size(58, 17);
            this.lblInfoSachTra.TabIndex = 3;
            this.lblInfoSachTra.Text = "Sách trả:";
            // 
            // dgvDangMuon
            // 
            this.dgvDangMuon.AllowUserToAddRows = false;
            this.dgvDangMuon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDangMuon.BackgroundColor = System.Drawing.Color.White;
            this.dgvDangMuon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDangMuon.Location = new System.Drawing.Point(11, 42);
            this.dgvDangMuon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvDangMuon.MultiSelect = false;
            this.dgvDangMuon.Name = "dgvDangMuon";
            this.dgvDangMuon.ReadOnly = true;
            this.dgvDangMuon.RowHeadersVisible = false;
            this.dgvDangMuon.RowHeadersWidth = 51;
            this.dgvDangMuon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDangMuon.Size = new System.Drawing.Size(645, 236);
            this.dgvDangMuon.TabIndex = 2;
            this.dgvDangMuon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDangMuon_CellClick);
            // 
            // txtTimKiemTra
            // 
            this.txtTimKiemTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTimKiemTra.Location = new System.Drawing.Point(135, 10);
            this.txtTimKiemTra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTimKiemTra.Name = "txtTimKiemTra";
            this.txtTimKiemTra.Size = new System.Drawing.Size(241, 24);
            this.txtTimKiemTra.TabIndex = 1;
            this.txtTimKiemTra.TextChanged += new System.EventHandler(this.txtTimKiemTra_TextChanged);
            // 
            // lblTimKiemTra
            // 
            this.lblTimKiemTra.AutoSize = true;
            this.lblTimKiemTra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTimKiemTra.Location = new System.Drawing.Point(11, 13);
            this.lblTimKiemTra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimKiemTra.Name = "lblTimKiemTra";
            this.lblTimKiemTra.Size = new System.Drawing.Size(143, 17);
            this.lblTimKiemTra.TabIndex = 0;
            this.lblTimKiemTra.Text = "Tìm theo Độc giả / PM:";
            // 
            // lnkTraSach
            // 
            this.lnkTraSach.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lnkTraSach.AutoSize = true;
            this.lnkTraSach.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lnkTraSach.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkTraSach.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lnkTraSach.Location = new System.Drawing.Point(94, 12);
            this.lnkTraSach.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnkTraSach.Name = "lnkTraSach";
            this.lnkTraSach.Size = new System.Drawing.Size(66, 19);
            this.lnkTraSach.TabIndex = 1;
            this.lnkTraSach.TabStop = true;
            this.lnkTraSach.Text = "[Trả sách]";
            this.lnkTraSach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTraSach_LinkClicked);
            // 
            // lnkMuonSach
            // 
            this.lnkMuonSach.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lnkMuonSach.AutoSize = true;
            this.lnkMuonSach.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lnkMuonSach.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkMuonSach.LinkColor = System.Drawing.Color.Black;
            this.lnkMuonSach.Location = new System.Drawing.Point(14, 12);
            this.lnkMuonSach.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnkMuonSach.Name = "lnkMuonSach";
            this.lnkMuonSach.Size = new System.Drawing.Size(91, 19);
            this.lnkMuonSach.TabIndex = 0;
            this.lnkMuonSach.TabStop = true;
            this.lnkMuonSach.Text = "[Mượn sách]";
            this.lnkMuonSach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkMuonSach_LinkClicked);
            // 
            // FrmMuonTra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(755, 463);
            this.Controls.Add(this.pnlOuter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "FrmMuonTra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mượn - Trả sách";
            this.Load += new System.EventHandler(this.FrmMuonTra_Load);
            this.pnlOuter.ResumeLayout(false);
            this.pnlOuter.PerformLayout();
            this.pnlMuonSach.ResumeLayout(false);
            this.pnlMuonSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachChon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoSach)).EndInit();
            this.pnlTraSach.ResumeLayout(false);
            this.pnlTraSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPhiPhat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangMuon)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel pnlOuter;
        private System.Windows.Forms.LinkLabel lnkMuonSach;
        private System.Windows.Forms.LinkLabel lnkTraSach;
        private System.Windows.Forms.Panel pnlMuonSach;
        private System.Windows.Forms.Label lblDocGia;
        private System.Windows.Forms.ComboBox cboDocGia;
        private System.Windows.Forms.Button btnKiemTraDieuKien;
        private System.Windows.Forms.Label lblDieuKienStatus;
        private System.Windows.Forms.Label lblNV;
        private System.Windows.Forms.ComboBox cboNhanVien;
        private System.Windows.Forms.Label lblNgayMuon;
        private System.Windows.Forms.TextBox txtNgayMuon;
        private System.Windows.Forms.Label lblHenTra;
        private System.Windows.Forms.TextBox txtHenTra;
        private System.Windows.Forms.Label lblKhoSach;
        private System.Windows.Forms.DataGridView dgvKhoSach;
        private System.Windows.Forms.Button btnThemSach;
        private System.Windows.Forms.Button btnBoSach;
        private System.Windows.Forms.Label lblSachChon;
        private System.Windows.Forms.DataGridView dgvSachChon;
        private System.Windows.Forms.Button btnLapPhieu;

        private System.Windows.Forms.Panel pnlTraSach;
        private System.Windows.Forms.Label lblTimKiemTra;
        private System.Windows.Forms.TextBox txtTimKiemTra;
        private System.Windows.Forms.DataGridView dgvDangMuon;
        private System.Windows.Forms.Label lblInfoSachTra;
        private System.Windows.Forms.TextBox txtInfoSachTra;
        private System.Windows.Forms.Label lblNgayTra;
        private System.Windows.Forms.TextBox txtNgayTra;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.ComboBox cboTinhTrang;
        private System.Windows.Forms.Label lblPhiPhat;
        private System.Windows.Forms.NumericUpDown nudPhiPhat;
        private System.Windows.Forms.Label lblLyDoPhat;
        private System.Windows.Forms.TextBox txtLyDoPhat;
        private System.Windows.Forms.Button btnXacNhanTra;
    }
}