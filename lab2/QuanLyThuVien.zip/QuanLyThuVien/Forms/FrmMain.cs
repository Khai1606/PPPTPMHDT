﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyThuVien.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            using (FrmDanhMuc frm = new FrmDanhMuc())
            {
                frm.ShowDialog();
            }
        }

        private void btnSach_Click(object sender, EventArgs e)
        {
            using (FrmSach frm = new FrmSach())
            {
                frm.ShowDialog();
            }
        }

        private void btnDocGia_Click(object sender, EventArgs e)
        {
            using (FrmDocGia frm = new FrmDocGia())
            {
                frm.ShowDialog();
            }
        }

        private void btnMuonTra_Click(object sender, EventArgs e)
        {
            using (FrmMuonTra frm = new FrmMuonTra())
            {
                frm.ShowDialog();
            }
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            using (FrmThongKe frm = new FrmThongKe())
            {
                frm.ShowDialog();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}