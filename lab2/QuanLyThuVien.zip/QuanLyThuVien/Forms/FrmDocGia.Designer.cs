﻿namespace QuanLyThuVien.Forms
{
    partial class FrmDocGia
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlOuter = new System.Windows.Forms.Panel();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.btnGiaHan = new System.Windows.Forms.Button();
            this.btnCapThe = new System.Windows.Forms.Button();
            this.chkDaDongLePhi = new System.Windows.Forms.CheckBox();
            this.txtHanSuDung = new System.Windows.Forms.TextBox();
            this.lblHanSuDung = new System.Windows.Forms.Label();
            this.txtNgayCap = new System.Windows.Forms.TextBox();
            this.lblNgayCap = new System.Windows.Forms.Label();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtAnh3x4 = new System.Windows.Forms.TextBox();
            this.lblAnh3x4 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.txtPhai = new System.Windows.Forms.TextBox();
            this.lblPhai = new System.Windows.Forms.Label();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtHo = new System.Windows.Forms.TextBox();
            this.lblHo = new System.Windows.Forms.Label();
            this.txtMaDG = new System.Windows.Forms.TextBox();
            this.lblMaDG = new System.Windows.Forms.Label();
            this.pnlOuter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlOuter
            // 
            this.pnlOuter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlOuter.BackColor = System.Drawing.Color.White;
            this.pnlOuter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOuter.Controls.Add(this.dgvDocGia);
            this.pnlOuter.Controls.Add(this.btnGiaHan);
            this.pnlOuter.Controls.Add(this.btnCapThe);
            this.pnlOuter.Controls.Add(this.chkDaDongLePhi);
            this.pnlOuter.Controls.Add(this.txtHanSuDung);
            this.pnlOuter.Controls.Add(this.lblHanSuDung);
            this.pnlOuter.Controls.Add(this.txtNgayCap);
            this.pnlOuter.Controls.Add(this.lblNgayCap);
            this.pnlOuter.Controls.Add(this.btnCapNhat);
            this.pnlOuter.Controls.Add(this.btnThem);
            this.pnlOuter.Controls.Add(this.txtAnh3x4);
            this.pnlOuter.Controls.Add(this.lblAnh3x4);
            this.pnlOuter.Controls.Add(this.txtEmail);
            this.pnlOuter.Controls.Add(this.lblEmail);
            this.pnlOuter.Controls.Add(this.txtDiaChi);
            this.pnlOuter.Controls.Add(this.lblDiaChi);
            this.pnlOuter.Controls.Add(this.txtDienThoai);
            this.pnlOuter.Controls.Add(this.lblDienThoai);
            this.pnlOuter.Controls.Add(this.txtPhai);
            this.pnlOuter.Controls.Add(this.lblPhai);
            this.pnlOuter.Controls.Add(this.txtNgaySinh);
            this.pnlOuter.Controls.Add(this.lblNgaySinh);
            this.pnlOuter.Controls.Add(this.txtTen);
            this.pnlOuter.Controls.Add(this.lblTen);
            this.pnlOuter.Controls.Add(this.txtHo);
            this.pnlOuter.Controls.Add(this.lblHo);
            this.pnlOuter.Controls.Add(this.txtMaDG);
            this.pnlOuter.Controls.Add(this.lblMaDG);
            this.pnlOuter.Location = new System.Drawing.Point(18, 16);
            this.pnlOuter.Name = "pnlOuter";
            this.pnlOuter.Size = new System.Drawing.Size(914, 538);
            this.pnlOuter.TabIndex = 0;
            // 
            // dgvDocGia
            // 
            this.dgvDocGia.AllowUserToAddRows = false;
            this.dgvDocGia.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDocGia.BackgroundColor = System.Drawing.Color.White;
            this.dgvDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDocGia.Location = new System.Drawing.Point(20, 240);
            this.dgvDocGia.MultiSelect = false;
            this.dgvDocGia.Name = "dgvDocGia";
            this.dgvDocGia.ReadOnly = true;
            this.dgvDocGia.RowHeadersVisible = false;
            this.dgvDocGia.RowHeadersWidth = 51;
            this.dgvDocGia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDocGia.Size = new System.Drawing.Size(870, 280);
            this.dgvDocGia.TabIndex = 27;
            this.dgvDocGia.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDocGia_CellClick);
            // 
            // btnGiaHan
            // 
            this.btnGiaHan.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGiaHan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnGiaHan.Location = new System.Drawing.Point(785, 192);
            this.btnGiaHan.Name = "btnGiaHan";
            this.btnGiaHan.Size = new System.Drawing.Size(105, 30);
            this.btnGiaHan.TabIndex = 26;
            this.btnGiaHan.Text = "Gia hạn";
            this.btnGiaHan.UseVisualStyleBackColor = true;
            this.btnGiaHan.Click += new System.EventHandler(this.btnGiaHan_Click);
            // 
            // btnCapThe
            // 
            this.btnCapThe.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCapThe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapThe.Location = new System.Drawing.Point(665, 192);
            this.btnCapThe.Name = "btnCapThe";
            this.btnCapThe.Size = new System.Drawing.Size(105, 30);
            this.btnCapThe.TabIndex = 25;
            this.btnCapThe.Text = "Cấp thẻ";
            this.btnCapThe.UseVisualStyleBackColor = true;
            this.btnCapThe.Click += new System.EventHandler(this.btnCapThe_Click);
            // 
            // chkDaDongLePhi
            // 
            this.chkDaDongLePhi.AutoSize = true;
            this.chkDaDongLePhi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkDaDongLePhi.Location = new System.Drawing.Point(665, 158);
            this.chkDaDongLePhi.Name = "chkDaDongLePhi";
            this.chkDaDongLePhi.Size = new System.Drawing.Size(134, 25);
            this.chkDaDongLePhi.TabIndex = 24;
            this.chkDaDongLePhi.Text = "Đã đóng lệ phí";
            this.chkDaDongLePhi.UseVisualStyleBackColor = true;
            // 
            // txtHanSuDung
            // 
            this.txtHanSuDung.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHanSuDung.Location = new System.Drawing.Point(505, 193);
            this.txtHanSuDung.Name = "txtHanSuDung";
            this.txtHanSuDung.Size = new System.Drawing.Size(130, 29);
            this.txtHanSuDung.TabIndex = 23;
            // 
            // lblHanSuDung
            // 
            this.lblHanSuDung.AutoSize = true;
            this.lblHanSuDung.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHanSuDung.Location = new System.Drawing.Point(385, 196);
            this.lblHanSuDung.Name = "lblHanSuDung";
            this.lblHanSuDung.Size = new System.Drawing.Size(101, 21);
            this.lblHanSuDung.TabIndex = 22;
            this.lblHanSuDung.Text = "Hạn sử dụng:";
            // 
            // txtNgayCap
            // 
            this.txtNgayCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNgayCap.Location = new System.Drawing.Point(505, 156);
            this.txtNgayCap.Name = "txtNgayCap";
            this.txtNgayCap.Size = new System.Drawing.Size(130, 29);
            this.txtNgayCap.TabIndex = 21;
            // 
            // lblNgayCap
            // 
            this.lblNgayCap.AutoSize = true;
            this.lblNgayCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayCap.Location = new System.Drawing.Point(385, 159);
            this.lblNgayCap.Name = "lblNgayCap";
            this.lblNgayCap.Size = new System.Drawing.Size(78, 21);
            this.lblNgayCap.TabIndex = 20;
            this.lblNgayCap.Text = "Ngày cấp:";
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCapNhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapNhat.Location = new System.Drawing.Point(785, 50);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(105, 32);
            this.btnCapNhat.TabIndex = 19;
            this.btnCapNhat.Text = "Cập nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // btnThem
            // 
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThem.Location = new System.Drawing.Point(785, 13);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(105, 32);
            this.btnThem.TabIndex = 18;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtAnh3x4
            // 
            this.txtAnh3x4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtAnh3x4.Location = new System.Drawing.Point(505, 120);
            this.txtAnh3x4.Name = "txtAnh3x4";
            this.txtAnh3x4.Size = new System.Drawing.Size(255, 29);
            this.txtAnh3x4.TabIndex = 17;
            // 
            // lblAnh3x4
            // 
            this.lblAnh3x4.AutoSize = true;
            this.lblAnh3x4.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblAnh3x4.Location = new System.Drawing.Point(385, 123);
            this.lblAnh3x4.Name = "lblAnh3x4";
            this.lblAnh3x4.Size = new System.Drawing.Size(69, 21);
            this.lblAnh3x4.TabIndex = 16;
            this.lblAnh3x4.Text = "Ảnh 3x4:";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtEmail.Location = new System.Drawing.Point(505, 84);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(255, 29);
            this.txtEmail.TabIndex = 15;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblEmail.Location = new System.Drawing.Point(385, 87);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(51, 21);
            this.lblEmail.TabIndex = 14;
            this.lblEmail.Text = "Email:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDiaChi.Location = new System.Drawing.Point(505, 48);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(255, 29);
            this.txtDiaChi.TabIndex = 13;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiaChi.Location = new System.Drawing.Point(385, 51);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(60, 21);
            this.lblDiaChi.TabIndex = 12;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDienThoai.Location = new System.Drawing.Point(505, 14);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(255, 29);
            this.txtDienThoai.TabIndex = 11;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDienThoai.Location = new System.Drawing.Point(385, 17);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(84, 21);
            this.lblDienThoai.TabIndex = 10;
            this.lblDienThoai.Text = "Điện thoại:";
            // 
            // txtPhai
            // 
            this.txtPhai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhai.Location = new System.Drawing.Point(125, 156);
            this.txtPhai.Name = "txtPhai";
            this.txtPhai.Size = new System.Drawing.Size(225, 29);
            this.txtPhai.TabIndex = 9;
            // 
            // lblPhai
            // 
            this.lblPhai.AutoSize = true;
            this.lblPhai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhai.Location = new System.Drawing.Point(20, 159);
            this.lblPhai.Name = "lblPhai";
            this.lblPhai.Size = new System.Drawing.Size(43, 21);
            this.lblPhai.TabIndex = 8;
            this.lblPhai.Text = "Phái:";
            // 
            // txtNgaySinh
            // 
            this.txtNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNgaySinh.Location = new System.Drawing.Point(125, 120);
            this.txtNgaySinh.Name = "txtNgaySinh";
            this.txtNgaySinh.Size = new System.Drawing.Size(225, 29);
            this.txtNgaySinh.TabIndex = 7;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgaySinh.Location = new System.Drawing.Point(20, 123);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(83, 21);
            this.lblNgaySinh.TabIndex = 6;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // txtTen
            // 
            this.txtTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTen.Location = new System.Drawing.Point(125, 84);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(225, 29);
            this.txtTen.TabIndex = 5;
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTen.Location = new System.Drawing.Point(20, 87);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(36, 21);
            this.lblTen.TabIndex = 4;
            this.lblTen.Text = "Tên:";
            // 
            // txtHo
            // 
            this.txtHo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHo.Location = new System.Drawing.Point(125, 48);
            this.txtHo.Name = "txtHo";
            this.txtHo.Size = new System.Drawing.Size(225, 29);
            this.txtHo.TabIndex = 3;
            // 
            // lblHo
            // 
            this.lblHo.AutoSize = true;
            this.lblHo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHo.Location = new System.Drawing.Point(20, 51);
            this.lblHo.Name = "lblHo";
            this.lblHo.Size = new System.Drawing.Size(33, 21);
            this.lblHo.TabIndex = 2;
            this.lblHo.Text = "Họ:";
            // 
            // txtMaDG
            // 
            this.txtMaDG.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaDG.Location = new System.Drawing.Point(125, 14);
            this.txtMaDG.Name = "txtMaDG";
            this.txtMaDG.Size = new System.Drawing.Size(225, 29);
            this.txtMaDG.TabIndex = 1;
            // 
            // lblMaDG
            // 
            this.lblMaDG.AutoSize = true;
            this.lblMaDG.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaDG.Location = new System.Drawing.Point(20, 17);
            this.lblMaDG.Name = "lblMaDG";
            this.lblMaDG.Size = new System.Drawing.Size(90, 21);
            this.lblMaDG.TabIndex = 0;
            this.lblMaDG.Text = "Mã độc giả:";
            // 
            // FrmDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(950, 570);
            this.Controls.Add(this.pnlOuter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDocGia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Độc giả và thẻ thư viện";
            this.Load += new System.EventHandler(this.FrmDocGia_Load);
            this.pnlOuter.ResumeLayout(false);
            this.pnlOuter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlOuter;
        private System.Windows.Forms.Label lblMaDG;
        private System.Windows.Forms.TextBox txtMaDG;
        private System.Windows.Forms.Label lblHo;
        private System.Windows.Forms.TextBox txtHo;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.Label lblPhai;
        private System.Windows.Forms.TextBox txtPhai;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblAnh3x4;
        private System.Windows.Forms.TextBox txtAnh3x4;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.Label lblNgayCap;
        private System.Windows.Forms.TextBox txtNgayCap;
        private System.Windows.Forms.Label lblHanSuDung;
        private System.Windows.Forms.TextBox txtHanSuDung;
        private System.Windows.Forms.CheckBox chkDaDongLePhi;
        private System.Windows.Forms.Button btnCapThe;
        private System.Windows.Forms.Button btnGiaHan;
        private System.Windows.Forms.DataGridView dgvDocGia;
    }
}