﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyThuVien.Data
{
    public static class Db
    {
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["QuanLyThuVienConnection"].ConnectionString;
        }

        public static SqlConnection OpenConnection()
        {
            SqlConnection conn = new SqlConnection(GetConnectionString());
            conn.Open();
            return conn;
        }

        public static DataTable Query(string sql, SqlParameter[] pars = null)
        {
            using (SqlConnection conn = OpenConnection())
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (pars != null) cmd.Parameters.AddRange(pars);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public static int Execute(string sql, SqlParameter[] pars = null)
        {
            using (SqlConnection conn = OpenConnection())
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (pars != null) cmd.Parameters.AddRange(pars);
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static object Scalar(string sql, SqlParameter[] pars = null)
        {
            using (SqlConnection conn = OpenConnection())
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (pars != null) cmd.Parameters.AddRange(pars);
                    return cmd.ExecuteScalar();
                }
            }
        }
    }
}