﻿using System;
using System.Data;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Services
{
    public class TuyendungService
    {
        public DataTable LayDanhSachPhongBan() => Db.Query("SELECT MaPhongBan, TenPhongBan FROM PhongBan ORDER BY TenPhongBan");

        public DataTable LayQuyetDinhTuyendung() => Db.Query(@"SELECT q.SoQDTD, q.MaNhanVien, n.HoTen, p.TenPhongBan, q.NgayKy, q.ThoiGianThuViec, q.LuongThuViec 
                                                            FROM QDTuyendung q 
                                                            JOIN NhanVien n ON q.MaNhanVien = n.MaNhanVien 
                                                            JOIN PhongBan p ON q.MaPhongBan = p.MaPhongBan");

        public DataTable LayHopDongLaoDong() => Db.Query(@"SELECT h.SoHopDong, h.MaNhanVien, n.HoTen, h.LoaiHopDong, h.NgayBatDau, h.NgayKetThuc 
                                                          FROM HopDongLaoDong h 
                                                          JOIN NhanVien n ON h.MaNhanVien = n.MaNhanVien");

        public KetQuaXuLy LapQDTuyendung(string soQD, string maNV, string maPB, DateTime ngayKy, int thoiGianThuViec, decimal luong, string dieuKhoan)
        {
            if (string.IsNullOrWhiteSpace(soQD) || string.IsNullOrWhiteSpace(maNV) || string.IsNullOrWhiteSpace(maPB))
                return KetQuaXuLy.Fail("Thông tin quyết định tuyển dụng chưa đầy đủ.");

            try
            {
                Db.Execute("INSERT INTO QDTuyendung(SoQDTD, MaNhanVien, MaPhongBan, NgayKy, ThoiGianThuViec, LuongThuViec, NoiDungDieuKhoan) VALUES(@so, @nv, @pb, @nk, @tg, @l, @dk)",
                    Db.P("@so", soQD), Db.P("@nv", maNV), Db.P("@pb", maPB), Db.P("@nk", ngayKy), Db.P("@tg", thoiGianThuViec), Db.P("@l", luong), Db.P("@dk", dieuKhoan));
                return KetQuaXuLy.Ok("Đã lập Quyết định tuyển dụng thử việc thành công.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy KyHopDongLaoDong(string soHD, string maNV, string loaiHD, DateTime ngayBD, DateTime? ngayKT, bool isDaiHan, string bhyt, string bhxh, decimal mucDongBH)
        {
            if (string.IsNullOrWhiteSpace(soHD) || string.IsNullOrWhiteSpace(maNV))
                return KetQuaXuLy.Fail("Thông tin hợp đồng chưa đầy đủ.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // 1. Thêm hợp đồng
                    using (var cmd1 = new System.Data.SqlClient.SqlCommand(@"INSERT INTO HopDongLaoDong(SoHopDong, MaNhanVien, LoaiHopDong, NgayBatDau, NgayKetThuc) 
                                                                           VALUES(@hd, @nv, @loai, @bd, @kt)", cn, tr))
                    {
                        cmd1.Parameters.Add(Db.P("@hd", soHD));
                        cmd1.Parameters.Add(Db.P("@nv", maNV));
                        cmd1.Parameters.Add(Db.P("@loai", loaiHD));
                        cmd1.Parameters.Add(Db.P("@bd", ngayBD));
                        cmd1.Parameters.Add(Db.P("@kt", ngayKT));
                        cmd1.ExecuteNonQuery();
                    }

                    // 2. Nếu là hợp đồng dài hạn -> Lập Hồ sơ Bảo hiểm
                    if (isDaiHan)
                    {
                        using (var cmd2 = new System.Data.SqlClient.SqlCommand(@"INSERT INTO HoSoBaoHiem(MaHoSoBH, MaNhanVien, SoBHYT, SoBHXH, MucDong, NgayThamGia) 
                                                                               VALUES(@bh, @nv, @yt, @xh, @muc, @nk)", cn, tr))
                        {
                            cmd2.Parameters.Add(Db.P("@bh", "BH_" + maNV));
                            cmd2.Parameters.Add(Db.P("@nv", maNV));
                            cmd2.Parameters.Add(Db.P("@yt", bhyt));
                            cmd2.Parameters.Add(Db.P("@xh", bhxh));
                            cmd2.Parameters.Add(Db.P("@muc", mucDongBH));
                            cmd2.Parameters.Add(Db.P("@nk", ngayBD));
                            cmd2.ExecuteNonQuery();
                        }
                    }

                    // 3. Cập nhật trạng thái nhân viên chính thức
                    using (var cmd3 = new System.Data.SqlClient.SqlCommand("UPDATE NhanVien SET TrangThai = N'Chính thức' WHERE MaNhanVien = @nv", cn, tr))
                    {
                        cmd3.Parameters.Add(Db.P("@nv", maNV));
                        cmd3.ExecuteNonQuery();
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã ký Hợp đồng lao động và chuyển nhân viên sang chính thức.");
                }
                catch (Exception ex)
                {
                    tr.Rollback();
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }
    }
}