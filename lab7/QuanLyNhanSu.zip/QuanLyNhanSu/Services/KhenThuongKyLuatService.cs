﻿using System;
using System.Data;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Services
{
    public class KhenThuongKyLuatService
    {
        public DataTable LayQDKhenThuong() => Db.Query("SELECT SoQDKhenThuong, NgayKy, LoaiDoiTuong, MaDoiTuong, LyDo, SoTienThuong FROM QDKhenThuong ORDER BY NgayKy DESC");
        public DataTable LayQDKyLuat() => Db.Query("SELECT SoQDKyLuat, NgayKy, LoaiDoiTuong, MaDoiTuong, LyDo, SoTienPhat FROM QDKyLuat ORDER BY NgayKy DESC");

        public KetQuaXuLy LapQDKhenThuong(string soQD, DateTime ngayKy, string loaiDT, string maDT, string lyDo, decimal soTien, bool chiTienMat)
        {
            if (string.IsNullOrWhiteSpace(soQD) || string.IsNullOrWhiteSpace(maDT) || soTien <= 0)
                return KetQuaXuLy.Fail("Thông tin quyết định khen thưởng không hợp lệ.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // 1. Lưu Quyết định Khen thưởng
                    using (var cmd = new System.Data.SqlClient.SqlCommand(@"INSERT INTO QDKhenThuong(SoQDKhenThuong, NgayKy, LoaiDoiTuong, MaDoiTuong, LyDo, SoTienThuong)
                                                                           VALUES(@so, @nk, @loai, @ma, @ld, @tien)", cn, tr))
                    {
                        cmd.Parameters.Add(Db.P("@so", soQD));
                        cmd.Parameters.Add(Db.P("@nk", ngayKy));
                        cmd.Parameters.Add(Db.P("@loai", loaiDT));
                        cmd.Parameters.Add(Db.P("@ma", maDT));
                        cmd.Parameters.Add(Db.P("@ld", lyDo));
                        cmd.Parameters.Add(Db.P("@tien", soTien));
                        cmd.ExecuteNonQuery();
                    }

                    // 2. Nếu khen thưởng bằng tiền mặt -> Tự động lập Phiếu chi tiền
                    if (chiTienMat)
                    {
                        using (var cmdChi = new System.Data.SqlClient.SqlCommand(@"INSERT INTO PhieuChiKhenThuong(SoPhieuChi, SoQDKhenThuong, NgayChi, SoTienChi, LyDoChi)
                                                                                  VALUES(@pc, @so, @nc, @tien, @ld)", cn, tr))
                        {
                            cmdChi.Parameters.Add(Db.P("@pc", "PC_" + soQD));
                            cmdChi.Parameters.Add(Db.P("@so", soQD));
                            cmdChi.Parameters.Add(Db.P("@nc", ngayKy));
                            cmdChi.Parameters.Add(Db.P("@tien", soTien));
                            cmdChi.Parameters.Add(Db.P("@ld", "Chi thưởng tiền mặt theo QĐ " + soQD));
                            cmdChi.ExecuteNonQuery();
                        }
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã lập Quyết định khen thưởng thành công.");
                }
                catch (Exception ex)
                {
                    tr.Rollback();
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        public KetQuaXuLy LapQDKyLuat(string soQD, DateTime ngayKy, string loaiDT, string maDT, string lyDo, decimal soTien, bool nopTienMat)
        {
            if (string.IsNullOrWhiteSpace(soQD) || string.IsNullOrWhiteSpace(maDT) || soTien < 0)
                return KetQuaXuLy.Fail("Thông tin quyết định kỷ luật không hợp lệ.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    // 1. Lưu Quyết định Kỷ luật
                    using (var cmd = new System.Data.SqlClient.SqlCommand(@"INSERT INTO QDKyLuat(SoQDKyLuat, NgayKy, LoaiDoiTuong, MaDoiTuong, LyDo, SoTienPhat)
                                                                           VALUES(@so, @nk, @loai, @ma, @ld, @tien)", cn, tr))
                    {
                        cmd.Parameters.Add(Db.P("@so", soQD));
                        cmd.Parameters.Add(Db.P("@nk", ngayKy));
                        cmd.Parameters.Add(Db.P("@loai", loaiDT));
                        cmd.Parameters.Add(Db.P("@ma", maDT));
                        cmd.Parameters.Add(Db.P("@ld", lyDo));
                        cmd.Parameters.Add(Db.P("@tien", soTien));
                        cmd.ExecuteNonQuery();
                    }

                    // 2. Nếu nộp phạt tiền mặt trực tiếp -> Lập Phiếu thu
                    if (nopTienMat && soTien > 0)
                    {
                        using (var cmdThu = new System.Data.SqlClient.SqlCommand(@"INSERT INTO PhieuThuNopPhat(SoPhieuThu, SoQDKyLuat, NgayThu, SoTienThu, LyDoThu)
                                                                                  VALUES(@pt, @so, @nt, @tien, @ld)", cn, tr))
                        {
                            cmdThu.Parameters.Add(Db.P("@pt", "PT_" + soQD));
                            cmdThu.Parameters.Add(Db.P("@so", soQD));
                            cmdThu.Parameters.Add(Db.P("@nt", ngayKy));
                            cmdThu.Parameters.Add(Db.P("@tien", soTien));
                            cmdThu.Parameters.Add(Db.P("@ld", "Thu tiền nộp phạt theo QĐ " + soQD));
                            cmdThu.ExecuteNonQuery();
                        }
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã lập Quyết định kỷ luật thành công.");
                }
                catch (Exception ex)
                {
                    tr.Rollback();
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }
    }
}