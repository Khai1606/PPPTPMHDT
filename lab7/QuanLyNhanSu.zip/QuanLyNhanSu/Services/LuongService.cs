﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Services
{
    public class LuongService
    {
        public DataTable LayBangLuongThang(int thang, int nam)
        {
            return Db.Query(@"SELECT b.MaBangLuong, b.MaNhanVien, n.HoTen, b.Thang, b.Nam, 
                                     b.LuongCoBan, b.PhuCap, b.LuongPhuTroi, b.TienTrichBH, 
                                     b.TienKhenThuong, b.TienKyLuat, b.LuongThucLinh
                              FROM BangLuong b
                              JOIN NhanVien n ON b.MaNhanVien = n.MaNhanVien
                              WHERE b.Thang = @th AND b.Nam = @na
                              ORDER BY b.MaNhanVien", Db.P("@th", thang), Db.P("@na", nam));
        }

        public KetQuaXuLy TinhBangLuongThang(int thang, int nam)
        {
            if (thang < 1 || thang > 12 || nam < 2000)
                return KetQuaXuLy.Fail("Tháng/Năm tính lương không hợp lệ.");

            try
            {
                // Lấy danh sách nhân viên chính thức
                DataTable dsNV = Db.Query("SELECT MaNhanVien FROM NhanVien WHERE TrangThai = N'Chính thức'");

                foreach (DataRow row in dsNV.Rows)
                {
                    string maNV = row["MaNhanVien"].ToString();
                    string maBL = $"BL_{maNV}_{thang:D2}{nam}";

                    // 1. Lấy Lương cơ bản & Phụ cấp lương từ QDLuong mới nhất
                    DataTable dtLuong = Db.Query(@"SELECT TOP 1 LuongCoBan, (PhuCapLuong + PhuCapDocHai) AS PhuCap 
                                                  FROM QDLuong WHERE MaNhanVien = @nv AND NgayApdung <= SYSDATETIME() 
                                                  ORDER BY NgayApdung DESC", Db.P("@nv", maNV));
                    decimal luongCoBan = dtLuong.Rows.Count > 0 ? Convert.ToDecimal(dtLuong.Rows[0]["LuongCoBan"]) : 0;
                    decimal phuCapLuong = dtLuong.Rows.Count > 0 ? Convert.ToDecimal(dtLuong.Rows[0]["PhuCap"]) : 0;

                    // 2. Lấy Phụ cấp chức vụ từ QĐChức vụ
                    decimal phuCapCV = Convert.ToDecimal(Db.Scalar(@"SELECT ISNULL(c.PhuCapChucVu, 0) 
                                                                    FROM NhanVien n JOIN ChucVu c ON n.MaChucVu = c.MaChucVu 
                                                                    WHERE n.MaNhanVien = @nv", Db.P("@nv", maNV)) ?? 0);
                    decimal tongPhuCap = phuCapLuong + phuCapCV;

                    // 3. Lấy tổng số giờ phụ trội từ Bảng chấm công (Hệ số 1.5)
                    double gioPhuTroi = Convert.ToDouble(Db.Scalar(@"SELECT ISNULL(SoGioPhuTroiTong, 0) FROM BangChamCong 
                                                                    WHERE MaNhanVien = @nv AND Thang = @th AND Nam = @na",
                                                                    Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);
                    decimal luongPhuTroi = (luongCoBan / 26 / 8) * (decimal)gioPhuTroi * 1.5m;

                    // 4. Lấy tiền trích trừ Bảo hiểm (BHYT, BHXH)
                    decimal tienBH = Convert.ToDecimal(Db.Scalar("SELECT ISNULL(MucDong, 0) FROM HoSoBaoHiem WHERE MaNhanVien = @nv", Db.P("@nv", maNV)) ?? 0);

                    // 5. Lấy tiền Khen thưởng & Kỷ luật trong tháng
                    decimal tienThuong = Convert.ToDecimal(Db.Scalar(@"SELECT ISNULL(SUM(SoTienThuong), 0) FROM QDKhenThuong 
                                                                       WHERE MaDoiTuong = @nv AND MONTH(NgayKy) = @th AND YEAR(NgayKy) = @na",
                                                                       Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);

                    decimal tienPhat = Convert.ToDecimal(Db.Scalar(@"SELECT ISNULL(SUM(SoTienPhat), 0) FROM QDKyLuat 
                                                                    WHERE MaDoiTuong = @nv AND MONTH(NgayKy) = @th AND YEAR(NgayKy) = @na",
                                                                    Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);

                    // 6. Tính Lương Thực Lĩnh
                    decimal luongThucLinh = luongCoBan + tongPhuCap + luongPhuTroi + tienThuong - tienPhat - tienBH;

                    // 7. Lưu hoặc cập nhật vào bảng BangLuong
                    string sqlUpsert = @"
                        IF EXISTS (SELECT 1 FROM BangLuong WHERE MaBangLuong = @mbl)
                            UPDATE BangLuong SET LuongCoBan=@lcb, PhuCap=@pc, LuongPhuTroi=@lpt, TienTrichBH=@tbh, 
                                                 TienKhenThuong=@kt, TienKyLuat=@kl, LuongThucLinh=@tl
                            WHERE MaBangLuong = @mbl
                        ELSE
                            INSERT INTO BangLuong(MaBangLuong, MaNhanVien, Thang, Nam, LuongCoBan, PhuCap, LuongPhuTroi, TienTrichBH, TienKhenThuong, TienKyLuat, LuongThucLinh)
                            VALUES(@mbl, @nv, @th, @na, @lcb, @pc, @lpt, @tbh, @kt, @kl, @tl)";

                    Db.Execute(sqlUpsert,
                        Db.P("@mbl", maBL), Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam),
                        Db.P("@lcb", luongCoBan), Db.P("@pc", tongPhuCap), Db.P("@lpt", luongPhuTroi),
                        Db.P("@tbh", tienBH), Db.P("@kt", tienThuong), Db.P("@kl", tienPhat), Db.P("@tl", luongThucLinh));
                }

                return KetQuaXuLy.Ok($"Đã tự động tính xong Bảng lương tháng {thang}/{nam}.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}