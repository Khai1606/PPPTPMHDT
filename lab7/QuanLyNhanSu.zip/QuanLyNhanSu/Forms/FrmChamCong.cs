﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmChamCong : Form
    {
        public FrmChamCong() { InitializeComponent(); }

        private void FrmChamCong_Load(object sender, EventArgs e)
        {
            numThang.Value = DateTime.Today.Month;
            numNam.Value = DateTime.Today.Year;
            Tai();
        }

        private void Tai()
        {
            dgvChamCong.DataSource = Db.Query("SELECT c.MaChamCong, c.MaNhanVien, n.HoTen, c.Thang, c.Nam, c.SoNgayCong, c.SoGioPhuTroiTong FROM BangChamCong c JOIN NhanVien n ON c.MaNhanVien = n.MaNhanVien WHERE c.Thang = @th AND c.Nam = @na", Db.P("@th", numThang.Value), Db.P("@na", numNam.Value));
        }

        private void btnLuuChamCong_Click(object sender, EventArgs e)
        {
            try
            {
                string maCC = $"CC_{txtMaNV.Text}_{numThang.Value:D2}{numNam.Value}";
                string sql = @"IF EXISTS (SELECT 1 FROM BangChamCong WHERE MaChamCong = @m)
                                UPDATE BangChamCong SET SoNgayCong = @ng, SoGioPhuTroiTong = @pt WHERE MaChamCong = @m
                               ELSE
                                INSERT INTO BangChamCong VALUES(@m, @nv, @th, @na, @ng, @pt)";
                Db.Execute(sql, Db.P("@m", maCC), Db.P("@nv", txtMaNV.Text), Db.P("@th", numThang.Value), Db.P("@na", numNam.Value), Db.P("@ng", numNgayCong.Value), Db.P("@pt", numGioPT.Value));
                MessageBox.Show("Lưu chấm công thành công!");
                Tai();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnDong_Click(object sender, EventArgs e) => Close();
    }
}