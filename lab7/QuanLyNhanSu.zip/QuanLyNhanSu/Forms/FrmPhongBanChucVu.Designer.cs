﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmPhongBanChucVu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPB = new System.Windows.Forms.TabPage();
            this.dgvPhongBan = new System.Windows.Forms.DataGridView();
            this.btnThemPB = new System.Windows.Forms.Button();
            this.txtSDTPB = new System.Windows.Forms.TextBox();
            this.txtTenPB = new System.Windows.Forms.TextBox();
            this.txtMaPB = new System.Windows.Forms.TextBox();
            this.tabCV = new System.Windows.Forms.TabPage();
            this.dgvChucVu = new System.Windows.Forms.DataGridView();
            this.btnThemCV = new System.Windows.Forms.Button();
            this.numPhuCapCV = new System.Windows.Forms.NumericUpDown();
            this.txtTenCV = new System.Windows.Forms.TextBox();
            this.txtMaCV = new System.Windows.Forms.TextBox();
            this.btnDong = new System.Windows.Forms.Button();

            this.tabControl.SuspendLayout();
            this.tabPB.SuspendLayout();
            this.tabCV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCapCV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChucVu)).BeginInit();
            this.SuspendLayout();

            this.tabControl.Controls.Add(this.tabPB);
            this.tabControl.Controls.Add(this.tabCV);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Size = new System.Drawing.Size(760, 430);

            // Tab Phòng Ban
            this.tabPB.Controls.Add(this.btnThemPB);
            this.tabPB.Controls.Add(this.txtSDTPB);
            this.tabPB.Controls.Add(this.txtTenPB);
            this.tabPB.Controls.Add(this.txtMaPB);
            this.tabPB.Controls.Add(this.dgvPhongBan);
            this.tabPB.Text = "Quản lý Phòng Ban";

            this.txtMaPB.Location = new System.Drawing.Point(20, 20); this.txtMaPB.Size = new System.Drawing.Size(120, 20);
            this.txtTenPB.Location = new System.Drawing.Point(160, 20); this.txtTenPB.Size = new System.Drawing.Size(200, 20);
            this.txtSDTPB.Location = new System.Drawing.Point(380, 20); this.txtSDTPB.Size = new System.Drawing.Size(150, 20);
            this.btnThemPB.Location = new System.Drawing.Point(550, 18); this.btnThemPB.Text = "Thêm Phòng Ban"; this.btnThemPB.Click += new System.EventHandler(this.btnThemPB_Click);
            this.dgvPhongBan.Location = new System.Drawing.Point(20, 60); this.dgvPhongBan.Size = new System.Drawing.Size(710, 330);

            // Tab Chức Vụ
            this.tabCV.Controls.Add(this.btnThemCV);
            this.tabCV.Controls.Add(this.numPhuCapCV);
            this.tabCV.Controls.Add(this.txtTenCV);
            this.tabCV.Controls.Add(this.txtMaCV);
            this.tabCV.Controls.Add(this.dgvChucVu);
            this.tabCV.Text = "Quản lý Chức Vụ";

            this.txtMaCV.Location = new System.Drawing.Point(20, 20); this.txtMaCV.Size = new System.Drawing.Size(120, 20);
            this.txtTenCV.Location = new System.Drawing.Point(160, 20); this.txtTenCV.Size = new System.Drawing.Size(200, 20);
            this.numPhuCapCV.Location = new System.Drawing.Point(380, 20); this.numPhuCapCV.Maximum = 50000000;
            this.btnThemCV.Location = new System.Drawing.Point(550, 18); this.btnThemCV.Text = "Thêm Chức Vụ"; this.btnThemCV.Click += new System.EventHandler(this.btnThemCV_Click);
            this.dgvChucVu.Location = new System.Drawing.Point(20, 60); this.dgvChucVu.Size = new System.Drawing.Size(710, 330);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(672, 450);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cơ cấu Tổ chức - Phòng ban & Chức vụ";
            this.Load += new System.EventHandler(this.FrmPhongBanChucVu_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPB.ResumeLayout(false); this.tabPB.PerformLayout();
            this.tabCV.ResumeLayout(false); this.tabCV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCapCV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChucVu)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPB;
        private System.Windows.Forms.TabPage tabCV;
        private System.Windows.Forms.DataGridView dgvPhongBan;
        private System.Windows.Forms.TextBox txtMaPB;
        private System.Windows.Forms.TextBox txtTenPB;
        private System.Windows.Forms.TextBox txtSDTPB;
        private System.Windows.Forms.Button btnThemPB;
        private System.Windows.Forms.DataGridView dgvChucVu;
        private System.Windows.Forms.TextBox txtMaCV;
        private System.Windows.Forms.TextBox txtTenCV;
        private System.Windows.Forms.NumericUpDown numPhuCapCV;
        private System.Windows.Forms.Button btnThemCV;
        private System.Windows.Forms.Button btnDong;
    }
}