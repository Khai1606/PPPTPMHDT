﻿using System;
using System.Windows.Forms;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent(); // Dòng này bắt buộc phải có để vẽ các nút bấm!
        }

        private void Mo(Form f) { using (f) f.ShowDialog(this); }

        private void btnPhongBanCV_Click(object sender, EventArgs e) => Mo(new FrmPhongBanChucVu());
        private void btnHoSoNV_Click(object sender, EventArgs e) => Mo(new FrmHoSoNhanVien());
        private void btnTuyendung_Click(object sender, EventArgs e) => Mo(new FrmTuyendungHopDong());
        private void btnBienDong_Click(object sender, EventArgs e) => Mo(new FrmBienDongNhanSu());
        private void btnPhanCong_Click(object sender, EventArgs e) => Mo(new FrmPhanCongPhuTroi());
        private void btnChamCong_Click(object sender, EventArgs e) => Mo(new FrmChamCong());
        private void btnKhenThuong_Click(object sender, EventArgs e) => Mo(new FrmKhenThuongKyLuat());
        private void btnBangLuong_Click(object sender, EventArgs e) => Mo(new FrmBangLuong());

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Xác nhận thoát hệ thống Quản lý Nhân sự?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}