﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Data;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmBienDongNhanSu : Form
    {
        public FrmBienDongNhanSu() { InitializeComponent(); }

        private void FrmBienDongNhanSu_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboChucVu, Db.Query("SELECT MaChucVu, TenChucVu FROM ChucVu"), "TenChucVu", "MaChucVu");
            Tai();
        }

        private void Tai()
        {
            dgvQDLuong.DataSource = Db.Query("SELECT * FROM QDLuong ORDER BY NgayKy DESC");
            dgvQDChucVu.DataSource = Db.Query("SELECT * FROM QDChucVu ORDER BY NgayKy DESC");
        }

        private void btnLapQDLuong_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO QDLuong VALUES(@so, @nv, @nk, @lcb, @pc, @dh, @ad)",
                    Db.P("@so", txtSoQDL.Text), Db.P("@nv", txtMaNV_L.Text), Db.P("@nk", dtNgayKy_L.Value),
                    Db.P("@lcb", numLuongCB.Value), Db.P("@pc", numPhuCap.Value), Db.P("@dh", numPhuCapDH.Value), Db.P("@ad", dtNgayAD_L.Value));
                MessageBox.Show("Đã lập Quyết định lương!");
                Tai();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnLapQDCV_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO QDChucVu VALUES(@so, @nv, @cv, @nk, @ad, @nd)",
                    Db.P("@so", txtSoQDCV.Text), Db.P("@nv", txtMaNV_CV.Text), Db.P("@cv", FormHelper.Gia(cboChucVu)),
                    Db.P("@nk", dtNgayKy_CV.Value), Db.P("@ad", dtNgayAD_CV.Value), Db.P("@nd", txtNoiDungCV.Text));

                Db.Execute("UPDATE NhanVien SET MaChucVu = @cv WHERE MaNhanVien = @nv", Db.P("@cv", FormHelper.Gia(cboChucVu)), Db.P("@nv", txtMaNV_CV.Text));
                MessageBox.Show("Đã bổ nhiệm chức vụ!");
                Tai();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnDong_Click(object sender, EventArgs e) => Close();
    }
}