﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Data;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmPhanCongPhuTroi : Form
    {
        public FrmPhanCongPhuTroi() { InitializeComponent(); }

        private void FrmPhanCongPhuTroi_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboPhongBan, Db.Query("SELECT MaPhongBan, TenPhongBan FROM PhongBan"), "TenPhongBan", "MaPhongBan");
            cboHinhThuc.Items.AddRange(new object[] { "Tăng ca", "Ngày lễ", "Ngày nghỉ" });
            cboHinhThuc.SelectedIndex = 0;
            Tai();
        }

        private void Tai()
        {
            dgvPhanCong.DataSource = Db.Query("SELECT * FROM KeHoachPhanCong ORDER BY NgayLap DESC");
            dgvPhuTroi.DataSource = Db.Query("SELECT * FROM PhieuPhuTroi ORDER BY NgayPhuTroi DESC");
        }

        private void btnLapKH_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO KeHoachPhanCong VALUES(@m, @pb, @t, @n, @nl, @ca)",
                    Db.P("@m", txtMaKH.Text), Db.P("@pb", FormHelper.Gia(cboPhongBan)), Db.P("@t", numTuan.Value),
                    Db.P("@n", numNam.Value), Db.P("@nl", dtNgayLapKH.Value), Db.P("@ca", txtCa.Text));
                MessageBox.Show("Đã lập kế hoạch phân công!");
                Tai();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnLapPhieuPT_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO PhieuPhuTroi VALUES(@so, @ng, @gio, @ht, 1.5)",
                    Db.P("@so", txtSoPhieuPT.Text), Db.P("@ng", dtNgayPT.Value), Db.P("@gio", numSoGioPT.Value), Db.P("@ht", cboHinhThuc.Text));

                if (!string.IsNullOrWhiteSpace(txtMaNV_PT.Text))
                {
                    Db.Execute("INSERT INTO ChiTietPhuTroi VALUES(@so, @nv, @gio, NULL)",
                        Db.P("@so", txtSoPhieuPT.Text), Db.P("@nv", txtMaNV_PT.Text), Db.P("@gio", numSoGioPT.Value));
                }

                MessageBox.Show("Đã ghi nhận phiếu phụ trội x1.5!");
                Tai();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnDong_Click(object sender, EventArgs e) => Close();
    }
}