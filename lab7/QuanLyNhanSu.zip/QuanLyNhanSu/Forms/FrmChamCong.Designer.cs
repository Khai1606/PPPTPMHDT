﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmChamCong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblThang = new System.Windows.Forms.Label();
            this.numThang = new System.Windows.Forms.NumericUpDown();
            this.lblNam = new System.Windows.Forms.Label();
            this.numNam = new System.Windows.Forms.NumericUpDown();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblNgayCong = new System.Windows.Forms.Label();
            this.numNgayCong = new System.Windows.Forms.NumericUpDown();
            this.lblGioPT = new System.Windows.Forms.Label();
            this.numGioPT = new System.Windows.Forms.NumericUpDown();
            this.btnLuuChamCong = new System.Windows.Forms.Button();
            this.dgvChamCong = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.numThang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgayCong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGioPT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).BeginInit();
            this.SuspendLayout();

            this.lblThang.Text = "Tháng:"; this.lblThang.Location = new System.Drawing.Point(20, 20);
            this.numThang.Location = new System.Drawing.Point(70, 18); this.numThang.Maximum = 12; this.numThang.Minimum = 1;
            this.lblNam.Text = "Năm:"; this.lblNam.Location = new System.Drawing.Point(140, 20);
            this.numNam.Location = new System.Drawing.Point(180, 18); this.numNam.Maximum = 2100; this.numNam.Minimum = 2000; this.numNam.Value = 2026;

            this.lblMaNV.Text = "Mã NV:"; this.lblMaNV.Location = new System.Drawing.Point(280, 20);
            this.txtMaNV.Location = new System.Drawing.Point(330, 18); this.txtMaNV.Size = new System.Drawing.Size(100, 20);

            this.lblNgayCong.Text = "Ngày công:"; this.lblNgayCong.Location = new System.Drawing.Point(440, 20);
            this.numNgayCong.Location = new System.Drawing.Point(510, 18); this.numNgayCong.Value = 26;

            this.lblGioPT.Text = "Giờ PT:"; this.lblGioPT.Location = new System.Drawing.Point(580, 20);
            this.numGioPT.Location = new System.Drawing.Point(630, 18);

            this.btnLuuChamCong.Location = new System.Drawing.Point(660, 50); this.btnLuuChamCong.Size = new System.Drawing.Size(104, 30);
            this.btnLuuChamCong.Text = "Lưu Chấm Công"; this.btnLuuChamCong.Click += new System.EventHandler(this.btnLuuChamCong_Click);

            this.dgvChamCong.Location = new System.Drawing.Point(20, 90); this.dgvChamCong.Size = new System.Drawing.Size(744, 350);

            this.btnDong.Location = new System.Drawing.Point(664, 450); this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgvChamCong);
            this.Controls.Add(this.btnLuuChamCong);
            this.Controls.Add(this.numGioPT); this.Controls.Add(this.lblGioPT);
            this.Controls.Add(this.numNgayCong); this.Controls.Add(this.lblNgayCong);
            this.Controls.Add(this.txtMaNV); this.Controls.Add(this.lblMaNV);
            this.Controls.Add(this.numNam); this.Controls.Add(this.lblNam);
            this.Controls.Add(this.numThang); this.Controls.Add(this.lblThang);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bảng Chấm Công Hàng Tháng";
            this.Load += new System.EventHandler(this.FrmChamCong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numThang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgayCong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGioPT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).EndInit();
            this.ResumeLayout(false); this.PerformLayout();
        }

        private System.Windows.Forms.Label lblThang;
        private System.Windows.Forms.NumericUpDown numThang;
        private System.Windows.Forms.Label lblNam;
        private System.Windows.Forms.NumericUpDown numNam;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblNgayCong;
        private System.Windows.Forms.NumericUpDown numNgayCong;
        private System.Windows.Forms.Label lblGioPT;
        private System.Windows.Forms.NumericUpDown numGioPT;
        private System.Windows.Forms.Button btnLuuChamCong;
        private System.Windows.Forms.DataGridView dgvChamCong;
        private System.Windows.Forms.Button btnDong;
    }
}