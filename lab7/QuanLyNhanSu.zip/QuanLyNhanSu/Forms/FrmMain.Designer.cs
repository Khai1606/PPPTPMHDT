﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnPhongBanCV = new System.Windows.Forms.Button();
            this.btnHoSoNV = new System.Windows.Forms.Button();
            this.btnTuyendung = new System.Windows.Forms.Button();
            this.btnBienDong = new System.Windows.Forms.Button();
            this.btnPhanCong = new System.Windows.Forms.Button();
            this.btnChamCong = new System.Windows.Forms.Button();
            this.btnKhenThuong = new System.Windows.Forms.Button();
            this.btnBangLuong = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Location = new System.Drawing.Point(100, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(450, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ NHÂN SỰ ĐÔNG Á";

            // btnPhongBanCV
            this.btnPhongBanCV.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnPhongBanCV.Location = new System.Drawing.Point(50, 80);
            this.btnPhongBanCV.Name = "btnPhongBanCV";
            this.btnPhongBanCV.Size = new System.Drawing.Size(260, 45);
            this.btnPhongBanCV.TabIndex = 1;
            this.btnPhongBanCV.Text = "1. Phòng Ban & Chức Vụ";
            this.btnPhongBanCV.UseVisualStyleBackColor = true;
            this.btnPhongBanCV.Click += new System.EventHandler(this.btnPhongBanCV_Click);

            // btnHoSoNV
            this.btnHoSoNV.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnHoSoNV.Location = new System.Drawing.Point(340, 80);
            this.btnHoSoNV.Name = "btnHoSoNV";
            this.btnHoSoNV.Size = new System.Drawing.Size(260, 45);
            this.btnHoSoNV.TabIndex = 2;
            this.btnHoSoNV.Text = "2. Hồ Sơ Lý Lịch Nhân Viên";
            this.btnHoSoNV.UseVisualStyleBackColor = true;
            this.btnHoSoNV.Click += new System.EventHandler(this.btnHoSoNV_Click);

            // btnTuyendung
            this.btnTuyendung.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnTuyendung.Location = new System.Drawing.Point(50, 145);
            this.btnTuyendung.Name = "btnTuyendung";
            this.btnTuyendung.Size = new System.Drawing.Size(260, 45);
            this.btnTuyendung.TabIndex = 3;
            this.btnTuyendung.Text = "3. Tuyển Dụng & Hợp Đồng";
            this.btnTuyendung.UseVisualStyleBackColor = true;
            this.btnTuyendung.Click += new System.EventHandler(this.btnTuyendung_Click);

            // btnBienDong
            this.btnBienDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnBienDong.Location = new System.Drawing.Point(340, 145);
            this.btnBienDong.Name = "btnBienDong";
            this.btnBienDong.Size = new System.Drawing.Size(260, 45);
            this.btnBienDong.TabIndex = 4;
            this.btnBienDong.Text = "4. QĐ Lương & Bổ Nhiệm";
            this.btnBienDong.UseVisualStyleBackColor = true;
            this.btnBienDong.Click += new System.EventHandler(this.btnBienDong_Click);

            // btnPhanCong
            this.btnPhanCong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnPhanCong.Location = new System.Drawing.Point(50, 210);
            this.btnPhanCong.Name = "btnPhanCong";
            this.btnPhanCong.Size = new System.Drawing.Size(260, 45);
            this.btnPhanCong.TabIndex = 5;
            this.btnPhanCong.Text = "5. Phân Công & Giờ Phụ Trội";
            this.btnPhanCong.UseVisualStyleBackColor = true;
            this.btnPhanCong.Click += new System.EventHandler(this.btnPhanCong_Click);

            // btnChamCong
            this.btnChamCong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnChamCong.Location = new System.Drawing.Point(340, 210);
            this.btnChamCong.Name = "btnChamCong";
            this.btnChamCong.Size = new System.Drawing.Size(260, 45);
            this.btnChamCong.TabIndex = 6;
            this.btnChamCong.Text = "6. Bảng Chấm Công";
            this.btnChamCong.UseVisualStyleBackColor = true;
            this.btnChamCong.Click += new System.EventHandler(this.btnChamCong_Click);

            // btnKhenThuong
            this.btnKhenThuong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnKhenThuong.Location = new System.Drawing.Point(50, 275);
            this.btnKhenThuong.Name = "btnKhenThuong";
            this.btnKhenThuong.Size = new System.Drawing.Size(260, 45);
            this.btnKhenThuong.TabIndex = 7;
            this.btnKhenThuong.Text = "7. Khen Thưởng & Kỷ Luật";
            this.btnKhenThuong.UseVisualStyleBackColor = true;
            this.btnKhenThuong.Click += new System.EventHandler(this.btnKhenThuong_Click);

            // btnBangLuong
            this.btnBangLuong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBangLuong.Location = new System.Drawing.Point(340, 275);
            this.btnBangLuong.Name = "btnBangLuong";
            this.btnBangLuong.Size = new System.Drawing.Size(260, 45);
            this.btnBangLuong.TabIndex = 8;
            this.btnBangLuong.Text = "8. Tính & Xuất Bảng Lương";
            this.btnBangLuong.UseVisualStyleBackColor = true;
            this.btnBangLuong.Click += new System.EventHandler(this.btnBangLuong_Click);

            // btnThoat
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnThoat.Location = new System.Drawing.Point(200, 340);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(260, 40);
            this.btnThoat.TabIndex = 9;
            this.btnThoat.Text = "Thoát Hệ Thống";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);

            // FrmMain
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 400);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnBangLuong);
            this.Controls.Add(this.btnKhenThuong);
            this.Controls.Add(this.btnChamCong);
            this.Controls.Add(this.btnPhanCong);
            this.Controls.Add(this.btnBienDong);
            this.Controls.Add(this.btnTuyendung);
            this.Controls.Add(this.btnHoSoNV);
            this.Controls.Add(this.btnPhongBanCV);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang chủ - Quản lý Nhân sự Công ty Sơn Đông Á";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnPhongBanCV;
        private System.Windows.Forms.Button btnHoSoNV;
        private System.Windows.Forms.Button btnTuyendung;
        private System.Windows.Forms.Button btnBienDong;
        private System.Windows.Forms.Button btnPhanCong;
        private System.Windows.Forms.Button btnChamCong;
        private System.Windows.Forms.Button btnKhenThuong;
        private System.Windows.Forms.Button btnBangLuong;
        private System.Windows.Forms.Button btnThoat;
    }
}