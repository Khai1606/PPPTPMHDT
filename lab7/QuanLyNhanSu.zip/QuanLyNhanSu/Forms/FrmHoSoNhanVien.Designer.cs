﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmHoSoNhanVien
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpThongTin = new System.Windows.Forms.GroupBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.dtNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.lblSDT = new System.Windows.Forms.Label();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblPhongBan = new System.Windows.Forms.Label();
            this.cboPhongBan = new System.Windows.Forms.ComboBox();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.cboChucVu = new System.Windows.Forms.ComboBox();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            this.grpThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.SuspendLayout();

            // grpThongTin
            this.grpThongTin.Controls.Add(this.cboChucVu);
            this.grpThongTin.Controls.Add(this.lblChucVu);
            this.grpThongTin.Controls.Add(this.cboPhongBan);
            this.grpThongTin.Controls.Add(this.lblPhongBan);
            this.grpThongTin.Controls.Add(this.txtDiaChi);
            this.grpThongTin.Controls.Add(this.lblDiaChi);
            this.grpThongTin.Controls.Add(this.txtSDT);
            this.grpThongTin.Controls.Add(this.lblSDT);
            this.grpThongTin.Controls.Add(this.cboGioiTinh);
            this.grpThongTin.Controls.Add(this.lblGioiTinh);
            this.grpThongTin.Controls.Add(this.dtNgaySinh);
            this.grpThongTin.Controls.Add(this.lblNgaySinh);
            this.grpThongTin.Controls.Add(this.txtHoTen);
            this.grpThongTin.Controls.Add(this.lblHoTen);
            this.grpThongTin.Controls.Add(this.txtMaNV);
            this.grpThongTin.Controls.Add(this.lblMaNV);
            this.grpThongTin.Location = new System.Drawing.Point(12, 12);
            this.grpThongTin.Size = new System.Drawing.Size(760, 130);
            this.grpThongTin.Text = "Hồ sơ Sơ yếu lý lịch Nhân viên";

            this.lblMaNV.Text = "Mã NV:"; this.lblMaNV.Location = new System.Drawing.Point(15, 25);
            this.txtMaNV.Location = new System.Drawing.Point(70, 22); this.txtMaNV.Size = new System.Drawing.Size(110, 20);

            this.lblHoTen.Text = "Họ tên:"; this.lblHoTen.Location = new System.Drawing.Point(200, 25);
            this.txtHoTen.Location = new System.Drawing.Point(255, 22); this.txtHoTen.Size = new System.Drawing.Size(160, 20);

            this.lblNgaySinh.Text = "Ngày sinh:"; this.lblNgaySinh.Location = new System.Drawing.Point(430, 25);
            this.dtNgaySinh.Location = new System.Drawing.Point(495, 22); this.dtNgaySinh.Size = new System.Drawing.Size(120, 20);

            this.lblGioiTinh.Text = "Giới tính:"; this.lblGioiTinh.Location = new System.Drawing.Point(630, 25);
            this.cboGioiTinh.Location = new System.Drawing.Point(685, 22); this.cboGioiTinh.Size = new System.Drawing.Size(60, 21);

            this.lblSDT.Text = "SĐT:"; this.lblSDT.Location = new System.Drawing.Point(15, 60);
            this.txtSDT.Location = new System.Drawing.Point(70, 57); this.txtSDT.Size = new System.Drawing.Size(110, 20);

            this.lblDiaChi.Text = "Địa chỉ:"; this.lblDiaChi.Location = new System.Drawing.Point(200, 60);
            this.txtDiaChi.Location = new System.Drawing.Point(255, 57); this.txtDiaChi.Size = new System.Drawing.Size(490, 20);

            this.lblPhongBan.Text = "Phòng ban:"; this.lblPhongBan.Location = new System.Drawing.Point(15, 95);
            this.cboPhongBan.Location = new System.Drawing.Point(85, 92); this.cboPhongBan.Size = new System.Drawing.Size(180, 21);

            this.lblChucVu.Text = "Chức vụ:"; this.lblChucVu.Location = new System.Drawing.Point(290, 95);
            this.cboChucVu.Location = new System.Drawing.Point(350, 92); this.cboChucVu.Size = new System.Drawing.Size(180, 21);

            // btnThemNV
            this.btnThemNV.Location = new System.Drawing.Point(615, 150);
            this.btnThemNV.Size = new System.Drawing.Size(157, 30);
            this.btnThemNV.Text = "Tiếp Nhận Nhân Viên";
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);

            // dgvNhanVien
            this.dgvNhanVien.Location = new System.Drawing.Point(12, 190);
            this.dgvNhanVien.Size = new System.Drawing.Size(760, 250);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(672, 450);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgvNhanVien);
            this.Controls.Add(this.btnThemNV);
            this.Controls.Add(this.grpThongTin);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Hồ sơ Nhân viên";
            this.Load += new System.EventHandler(this.FrmHoSoNhanVien_Load);
            this.grpThongTin.ResumeLayout(false);
            this.grpThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox grpThongTin;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.DateTimePicker dtNgaySinh;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblPhongBan;
        private System.Windows.Forms.ComboBox cboPhongBan;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.ComboBox cboChucVu;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.Button btnDong;
    }
}