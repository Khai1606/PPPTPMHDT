﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmTuyendungHopDong : Form
    {
        private readonly TuyendungService svc = new TuyendungService();

        public FrmTuyendungHopDong()
        {
            InitializeComponent();
        }

        private void FrmTuyendungHopDong_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboPhongBan, svc.LayDanhSachPhongBan(), "TenPhongBan", "MaPhongBan");
            cboLoaiHD.Items.AddRange(new object[] { "Ngắn hạn", "Dài hạn" });
            cboLoaiHD.SelectedIndex = 0;
            dtNgayKy.Value = DateTime.Today;
            dtNgayBD.Value = DateTime.Today;
            Tai();
        }

        private void Tai()
        {
            dgvQDTD.DataSource = svc.LayQuyetDinhTuyendung();
            dgvHopDong.DataSource = svc.LayHopDongLaoDong();
        }

        private void cboLoaiHD_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isDaiHan = cboLoaiHD.Text == "Dài hạn";
            txtBHYT.Enabled = isDaiHan;
            txtBHXH.Enabled = isDaiHan;
            numMucDongBH.Enabled = isDaiHan;
        }

        private void btnLapQDTD_Click(object sender, EventArgs e)
        {
            var k = svc.LapQDTuyendung(
                txtSoQDTD.Text,
                txtMaNV_TD.Text,
                FormHelper.Gia(cboPhongBan),
                dtNgayKy.Value,
                (int)numThoiGianThuViec.Value,
                numLuongThuViec.Value,
                txtDieuKhoan.Text
            );

            if (FormHelper.Bao(k)) Tai();
        }

        private void btnKyHopDong_Click(object sender, EventArgs e)
        {
            bool isDaiHan = cboLoaiHD.Text == "Dài hạn";
            DateTime? ngayKT = isDaiHan ? (DateTime?)dtNgayKT.Value : null;

            var k = svc.KyHopDongLaoDong(
                txtSoHD.Text,
                txtMaNV_HD.Text,
                cboLoaiHD.Text,
                dtNgayBD.Value,
                ngayKT,
                isDaiHan,
                txtBHYT.Text,
                txtBHXH.Text,
                numMucDongBH.Value
            );

            if (FormHelper.Bao(k)) Tai();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}