﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmBangLuong : Form
    {
        public FrmBangLuong()
        {
            InitializeComponent();
        }

        private void FrmBangLuong_Load(object sender, EventArgs e)
        {
            numThang.Value = DateTime.Today.Month;
            numNam.Value = DateTime.Today.Year;
            TaiBangLuong();
        }

        private void TaiBangLuong()
        {
            int thang = (int)numThang.Value;
            int nam = (int)numNam.Value;

            string sql = @"
                SELECT 
                    b.MaBangLuong, 
                    b.MaNhanVien, 
                    n.HoTen, 
                    b.Thang, 
                    b.Nam, 
                    b.LuongCoBan, 
                    b.PhuCap, 
                    b.LuongPhuTroi, 
                    b.TienTrichBH, 
                    b.TienKhenThuong, 
                    b.TienKyLuat, 
                    b.LuongThucLinh
                FROM BangLuong b
                JOIN NhanVien n ON b.MaNhanVien = n.MaNhanVien
                WHERE b.Thang = @th AND b.Nam = @na
                ORDER BY b.MaNhanVien";

            DataTable dt = Db.Query(sql, Db.P("@th", thang), Db.P("@na", nam));
            dgvBangLuong.DataSource = dt;
        }

        private void btnTinhLuong_Click(object sender, EventArgs e)
        {
            int thang = (int)numThang.Value;
            int nam = (int)numNam.Value;

            try
            {
                DataTable dsNV = Db.Query("SELECT MaNhanVien FROM NhanVien WHERE TrangThai = N'Chính thức'");

                if (dsNV.Rows.Count == 0)
                {
                    MessageBox.Show("Chưa có nhân viên chính thức nào để tính lương!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int soLuongThanhCong = 0;

                foreach (DataRow row in dsNV.Rows)
                {
                    string maNV = row["MaNhanVien"].ToString();
                    string maBL = $"BL_{maNV}_{thang:D2}{nam}";

                    DataTable dtLuong = Db.Query(@"
                        SELECT TOP 1 LuongCoBan, (PhuCapLuong + PhuCapDocHai) AS PhuCap 
                        FROM QDLuong 
                        WHERE MaNhanVien = @nv AND NgayApdung <= SYSDATETIME() 
                        ORDER BY NgayApdung DESC", Db.P("@nv", maNV));

                    decimal luongCoBan = dtLuong.Rows.Count > 0 ? Convert.ToDecimal(dtLuong.Rows[0]["LuongCoBan"]) : 0;
                    decimal phuCapLuong = dtLuong.Rows.Count > 0 ? Convert.ToDecimal(dtLuong.Rows[0]["PhuCap"]) : 0;

                    decimal phuCapCV = Convert.ToDecimal(Db.Scalar(@"
                        SELECT ISNULL(c.PhuCapChucVu, 0) 
                        FROM NhanVien n 
                        JOIN ChucVu c ON n.MaChucVu = c.MaChucVu 
                        WHERE n.MaNhanVien = @nv", Db.P("@nv", maNV)) ?? 0);

                    decimal tongPhuCap = phuCapLuong + phuCapCV;

                    double gioPhuTroi = Convert.ToDouble(Db.Scalar(@"
                        SELECT ISNULL(SoGioPhuTroiTong, 0) 
                        FROM BangChamCong 
                        WHERE MaNhanVien = @nv AND Thang = @th AND Nam = @na",
                        Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);

                    decimal luongPhuTroi = 0;
                    if (luongCoBan > 0 && gioPhuTroi > 0)
                    {
                        luongPhuTroi = Math.Round((luongCoBan / 26m / 8m) * (decimal)gioPhuTroi * 1.5m, 0);
                    }

                    decimal tienBH = Convert.ToDecimal(Db.Scalar(@"
                        SELECT ISNULL(MucDong, 0) 
                        FROM HoSoBaoHiem 
                        WHERE MaNhanVien = @nv", Db.P("@nv", maNV)) ?? 0);

                    decimal tienThuong = Convert.ToDecimal(Db.Scalar(@"
                        SELECT ISNULL(SUM(SoTienThuong), 0) 
                        FROM QDKhenThuong 
                        WHERE MaDoiTuong = @nv AND MONTH(NgayKy) = @th AND YEAR(NgayKy) = @na",
                        Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);

                    decimal tienPhat = Convert.ToDecimal(Db.Scalar(@"
                        SELECT ISNULL(SUM(SoTienPhat), 0) 
                        FROM QDKyLuat 
                        WHERE MaDoiTuong = @nv AND MONTH(NgayKy) = @th AND YEAR(NgayKy) = @na",
                        Db.P("@nv", maNV), Db.P("@th", thang), Db.P("@na", nam)) ?? 0);

                    decimal luongThucLinh = luongCoBan + tongPhuCap + luongPhuTroi + tienThuong - tienPhat - tienBH;
                    if (luongThucLinh < 0) luongThucLinh = 0;

                    string sqlUpsert = @"
                        IF EXISTS (SELECT 1 FROM BangLuong WHERE MaBangLuong = @mbl)
                        BEGIN
                            UPDATE BangLuong 
                            SET LuongCoBan = @lcb, 
                                PhuCap = @pc, 
                                LuongPhuTroi = @lpt, 
                                TienTrichBH = @tbh, 
                                TienKhenThuong = @kt, 
                                TienKyLuat = @kl, 
                                LuongThucLinh = @tl
                            WHERE MaBangLuong = @mbl;
                        END
                        ELSE
                        BEGIN
                            INSERT INTO BangLuong(MaBangLuong, MaNhanVien, Thang, Nam, LuongCoBan, PhuCap, LuongPhuTroi, TienTrichBH, TienKhenThuong, TienKyLuat, LuongThucLinh)
                            VALUES(@mbl, @nv, @th, @na, @lcb, @pc, @lpt, @tbh, @kt, @kl, @tl);
                        END";

                    Db.Execute(sqlUpsert,
                        Db.P("@mbl", maBL),
                        Db.P("@nv", maNV),
                        Db.P("@th", thang),
                        Db.P("@na", nam),
                        Db.P("@lcb", luongCoBan),
                        Db.P("@pc", tongPhuCap),
                        Db.P("@lpt", luongPhuTroi),
                        Db.P("@tbh", tienBH),
                        Db.P("@kt", tienThuong),
                        Db.P("@kl", tienPhat),
                        Db.P("@tl", luongThucLinh));

                    soLuongThanhCong++;
                }

                MessageBox.Show($"Đã tính toán và lưu Bảng lương Tháng {thang}/{nam} cho {soLuongThanhCong} nhân viên thành công!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                TaiBangLuong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi trong quá trình tính lương: " + ex.Message, "Lỗi SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}