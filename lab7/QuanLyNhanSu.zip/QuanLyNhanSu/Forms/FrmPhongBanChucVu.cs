﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmPhongBanChucVu : Form
    {
        public FrmPhongBanChucVu() { InitializeComponent(); }

        private void FrmPhongBanChucVu_Load(object sender, EventArgs e) => TaiData();

        private void TaiData()
        {
            dgvPhongBan.DataSource = Db.Query("SELECT MaPhongBan, TenPhongBan, SoDienThoaiPB FROM PhongBan");
            dgvChucVu.DataSource = Db.Query("SELECT MaChucVu, TenChucVu, PhuCapChucVu FROM ChucVu");
        }

        private void btnThemPB_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO PhongBan(MaPhongBan, TenPhongBan, SoDienThoaiPB) VALUES(@m, @t, @s)",
                    Db.P("@m", txtMaPB.Text), Db.P("@t", txtTenPB.Text), Db.P("@s", txtSDTPB.Text));
                TaiData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Lỗi thêm Phòng ban"); }
        }

        private void btnThemCV_Click(object sender, EventArgs e)
        {
            try
            {
                Db.Execute("INSERT INTO ChucVu(MaChucVu, TenChucVu, PhuCapChucVu) VALUES(@m, @t, @p)",
                    Db.P("@m", txtMaCV.Text), Db.P("@t", txtTenCV.Text), Db.P("@p", numPhuCapCV.Value));
                TaiData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Lỗi thêm Chức vụ"); }
        }

        private void btnDong_Click(object sender, EventArgs e) => Close();
    }
}