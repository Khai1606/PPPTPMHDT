﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmTuyendungHopDong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabQDTD = new System.Windows.Forms.TabPage();
            this.dgvQDTD = new System.Windows.Forms.DataGridView();
            this.grpQDTD = new System.Windows.Forms.GroupBox();
            this.txtDieuKhoan = new System.Windows.Forms.TextBox();
            this.lblDieuKhoan = new System.Windows.Forms.Label();
            this.numLuongThuViec = new System.Windows.Forms.NumericUpDown();
            this.lblLuongTV = new System.Windows.Forms.Label();
            this.numThoiGianThuViec = new System.Windows.Forms.NumericUpDown();
            this.lblThoiGian = new System.Windows.Forms.Label();
            this.dtNgayKy = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKy = new System.Windows.Forms.Label();
            this.cboPhongBan = new System.Windows.Forms.ComboBox();
            this.lblPhongBan = new System.Windows.Forms.Label();
            this.txtMaNV_TD = new System.Windows.Forms.TextBox();
            this.lblMaNV_TD = new System.Windows.Forms.Label();
            this.txtSoQDTD = new System.Windows.Forms.TextBox();
            this.lblSoQDTD = new System.Windows.Forms.Label();
            this.btnLapQDTD = new System.Windows.Forms.Button();

            this.tabHopDong = new System.Windows.Forms.TabPage();
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.grpHopDong = new System.Windows.Forms.GroupBox();
            this.numMucDongBH = new System.Windows.Forms.NumericUpDown();
            this.lblMucDongBH = new System.Windows.Forms.Label();
            this.txtBHXH = new System.Windows.Forms.TextBox();
            this.lblBHXH = new System.Windows.Forms.Label();
            this.txtBHYT = new System.Windows.Forms.TextBox();
            this.lblBHYT = new System.Windows.Forms.Label();
            this.dtNgayKT = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.dtNgayBD = new System.Windows.Forms.DateTimePicker();
            this.lblNgayBD = new System.Windows.Forms.Label();
            this.cboLoaiHD = new System.Windows.Forms.ComboBox();
            this.lblLoaiHD = new System.Windows.Forms.Label();
            this.txtMaNV_HD = new System.Windows.Forms.TextBox();
            this.lblMaNV_HD = new System.Windows.Forms.Label();
            this.txtSoHD = new System.Windows.Forms.TextBox();
            this.lblSoHD = new System.Windows.Forms.Label();
            this.btnKyHopDong = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();

            this.tabControl1.SuspendLayout();
            this.tabQDTD.SuspendLayout();
            this.grpQDTD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQDTD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuongThuViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianThuViec)).BeginInit();
            this.tabHopDong.SuspendLayout();
            this.grpHopDong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMucDongBH)).BeginInit();
            this.SuspendLayout();

            // tabControl1
            this.tabControl1.Controls.Add(this.tabQDTD);
            this.tabControl1.Controls.Add(this.tabHopDong);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(760, 480);

            // tabQDTD
            this.tabQDTD.Controls.Add(this.btnLapQDTD);
            this.tabQDTD.Controls.Add(this.dgvQDTD);
            this.tabQDTD.Controls.Add(this.grpQDTD);
            this.tabQDTD.Location = new System.Drawing.Point(4, 22);
            this.tabQDTD.Name = "tabQDTD";
            this.tabQDTD.Padding = new System.Windows.Forms.Padding(3);
            this.tabQDTD.Size = new System.Drawing.Size(752, 454);
            this.tabQDTD.Text = "Quyết định Tuyển dụng (Thử việc)";

            // grpQDTD
            this.grpQDTD.Controls.Add(this.txtDieuKhoan);
            this.grpQDTD.Controls.Add(this.lblDieuKhoan);
            this.grpQDTD.Controls.Add(this.numLuongThuViec);
            this.grpQDTD.Controls.Add(this.lblLuongTV);
            this.grpQDTD.Controls.Add(this.numThoiGianThuViec);
            this.grpQDTD.Controls.Add(this.lblThoiGian);
            this.grpQDTD.Controls.Add(this.dtNgayKy);
            this.grpQDTD.Controls.Add(this.lblNgayKy);
            this.grpQDTD.Controls.Add(this.cboPhongBan);
            this.grpQDTD.Controls.Add(this.lblPhongBan);
            this.grpQDTD.Controls.Add(this.txtMaNV_TD);
            this.grpQDTD.Controls.Add(this.lblMaNV_TD);
            this.grpQDTD.Controls.Add(this.txtSoQDTD);
            this.grpQDTD.Controls.Add(this.lblSoQDTD);
            this.grpQDTD.Location = new System.Drawing.Point(10, 10);
            this.grpQDTD.Name = "grpQDTD";
            this.grpQDTD.Size = new System.Drawing.Size(730, 150);
            this.grpQDTD.TabStop = false;
            this.grpQDTD.Text = "Thông tin Quyết định Tuyển dụng";

            // Control layout details QDTD
            this.lblSoQDTD.Location = new System.Drawing.Point(15, 25);
            this.lblSoQDTD.Text = "Số QĐ:";
            this.txtSoQDTD.Location = new System.Drawing.Point(80, 22);
            this.txtSoQDTD.Size = new System.Drawing.Size(140, 20);

            this.lblMaNV_TD.Location = new System.Drawing.Point(240, 25);
            this.lblMaNV_TD.Text = "Mã NV:";
            this.txtMaNV_TD.Location = new System.Drawing.Point(310, 22);
            this.txtMaNV_TD.Size = new System.Drawing.Size(140, 20);

            this.lblPhongBan.Location = new System.Drawing.Point(470, 25);
            this.lblPhongBan.Text = "Phòng ban:";
            this.cboPhongBan.Location = new System.Drawing.Point(545, 22);
            this.cboPhongBan.Size = new System.Drawing.Size(165, 21);

            this.lblNgayKy.Location = new System.Drawing.Point(15, 60);
            this.lblNgayKy.Text = "Ngày ký:";
            this.dtNgayKy.Location = new System.Drawing.Point(80, 57);
            this.dtNgayKy.Size = new System.Drawing.Size(140, 20);

            this.lblThoiGian.Location = new System.Drawing.Point(240, 60);
            this.lblThoiGian.Text = "Thử việc (tháng):";
            this.numThoiGianThuViec.Location = new System.Drawing.Point(340, 57);
            this.numThoiGianThuViec.Size = new System.Drawing.Size(110, 20);
            this.numThoiGianThuViec.Value = 2;

            this.lblLuongTV.Location = new System.Drawing.Point(470, 60);
            this.lblLuongTV.Text = "Lương TV:";
            this.numLuongThuViec.Location = new System.Drawing.Point(545, 57);
            this.numLuongThuViec.Size = new System.Drawing.Size(165, 20);
            this.numLuongThuViec.Maximum = 100000000;

            this.lblDieuKhoan.Location = new System.Drawing.Point(15, 95);
            this.lblDieuKhoan.Text = "Điều khoản:";
            this.txtDieuKhoan.Location = new System.Drawing.Point(80, 92);
            this.txtDieuKhoan.Size = new System.Drawing.Size(630, 40);
            this.txtDieuKhoan.Multiline = true;

            // btnLapQDTD
            this.btnLapQDTD.Location = new System.Drawing.Point(600, 168);
            this.btnLapQDTD.Size = new System.Drawing.Size(140, 30);
            this.btnLapQDTD.Text = "Lập QĐ Tuyển dụng";
            this.btnLapQDTD.Click += new System.EventHandler(this.btnLapQDTD_Click);

            // dgvQDTD
            this.dgvQDTD.Location = new System.Drawing.Point(10, 205);
            this.dgvQDTD.Size = new System.Drawing.Size(730, 235);

            // tabHopDong
            this.tabHopDong.Controls.Add(this.btnKyHopDong);
            this.tabHopDong.Controls.Add(this.dgvHopDong);
            this.tabHopDong.Controls.Add(this.grpHopDong);
            this.tabHopDong.Text = "Hợp đồng Lao động & Bảo hiểm";

            // grpHopDong Controls Layout
            this.grpHopDong.Controls.Add(this.numMucDongBH);
            this.grpHopDong.Controls.Add(this.lblMucDongBH);
            this.grpHopDong.Controls.Add(this.txtBHXH);
            this.grpHopDong.Controls.Add(this.lblBHXH);
            this.grpHopDong.Controls.Add(this.txtBHYT);
            this.grpHopDong.Controls.Add(this.lblBHYT);
            this.grpHopDong.Controls.Add(this.dtNgayKT);
            this.grpHopDong.Controls.Add(this.lblNgayKT);
            this.grpHopDong.Controls.Add(this.dtNgayBD);
            this.grpHopDong.Controls.Add(this.lblNgayBD);
            this.grpHopDong.Controls.Add(this.cboLoaiHD);
            this.grpHopDong.Controls.Add(this.lblLoaiHD);
            this.grpHopDong.Controls.Add(this.txtMaNV_HD);
            this.grpHopDong.Controls.Add(this.lblMaNV_HD);
            this.grpHopDong.Controls.Add(this.txtSoHD);
            this.grpHopDong.Controls.Add(this.lblSoHD);
            this.grpHopDong.Location = new System.Drawing.Point(10, 10);
            this.grpHopDong.Size = new System.Drawing.Size(730, 150);
            this.grpHopDong.Text = "Thông tin Hợp đồng Lao động chính thức";

            this.lblSoHD.Location = new System.Drawing.Point(15, 25);
            this.lblSoHD.Text = "Số HĐ:";
            this.txtSoHD.Location = new System.Drawing.Point(80, 22);
            this.txtSoHD.Size = new System.Drawing.Size(140, 20);

            this.lblMaNV_HD.Location = new System.Drawing.Point(240, 25);
            this.lblMaNV_HD.Text = "Mã NV:";
            this.txtMaNV_HD.Location = new System.Drawing.Point(310, 22);
            this.txtMaNV_HD.Size = new System.Drawing.Size(140, 20);

            this.lblLoaiHD.Location = new System.Drawing.Point(470, 25);
            this.lblLoaiHD.Text = "Loại HĐ:";
            this.cboLoaiHD.Location = new System.Drawing.Point(545, 22);
            this.cboLoaiHD.Size = new System.Drawing.Size(165, 21);
            this.cboLoaiHD.SelectedIndexChanged += new System.EventHandler(this.cboLoaiHD_SelectedIndexChanged);

            this.lblNgayBD.Location = new System.Drawing.Point(15, 60);
            this.lblNgayBD.Text = "Ngày BD:";
            this.dtNgayBD.Location = new System.Drawing.Point(80, 57);
            this.dtNgayBD.Size = new System.Drawing.Size(140, 20);

            this.lblNgayKT.Location = new System.Drawing.Point(240, 60);
            this.lblNgayKT.Text = "Ngày KT:";
            this.dtNgayKT.Location = new System.Drawing.Point(310, 57);
            this.dtNgayKT.Size = new System.Drawing.Size(140, 20);

            this.lblBHYT.Location = new System.Drawing.Point(470, 60);
            this.lblBHYT.Text = "Số BHYT:";
            this.txtBHYT.Location = new System.Drawing.Point(545, 57);
            this.txtBHYT.Size = new System.Drawing.Size(165, 20);

            this.lblBHXH.Location = new System.Drawing.Point(15, 95);
            this.lblBHXH.Text = "Số BHXH:";
            this.txtBHXH.Location = new System.Drawing.Point(80, 92);
            this.txtBHXH.Size = new System.Drawing.Size(140, 20);

            this.lblMucDongBH.Location = new System.Drawing.Point(240, 95);
            this.lblMucDongBH.Text = "Mức đóng BH:";
            this.numMucDongBH.Location = new System.Drawing.Point(325, 92);
            this.numMucDongBH.Size = new System.Drawing.Size(125, 20);
            this.numMucDongBH.Maximum = 50000000;

            // btnKyHopDong
            this.btnKyHopDong.Location = new System.Drawing.Point(600, 168);
            this.btnKyHopDong.Size = new System.Drawing.Size(140, 30);
            this.btnKyHopDong.Text = "Ký Hợp đồng & Bảo hiểm";
            this.btnKyHopDong.Click += new System.EventHandler(this.btnKyHopDong_Click);

            // dgvHopDong
            this.dgvHopDong.Location = new System.Drawing.Point(10, 205);
            this.dgvHopDong.Size = new System.Drawing.Size(730, 235);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(670, 500);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // FrmTuyendungHopDong Main
            this.ClientSize = new System.Drawing.Size(784, 540);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Tuyển dụng & Hợp đồng Lao động";
            this.Load += new System.EventHandler(this.FrmTuyendungHopDong_Load);

            this.tabControl1.ResumeLayout(false);
            this.tabQDTD.ResumeLayout(false);
            this.grpQDTD.ResumeLayout(false);
            this.grpQDTD.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQDTD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuongThuViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianThuViec)).EndInit();
            this.tabHopDong.ResumeLayout(false);
            this.grpHopDong.ResumeLayout(false);
            this.grpHopDong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMucDongBH)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabQDTD;
        private System.Windows.Forms.GroupBox grpQDTD;
        private System.Windows.Forms.Label lblSoQDTD;
        private System.Windows.Forms.TextBox txtSoQDTD;
        private System.Windows.Forms.Label lblMaNV_TD;
        private System.Windows.Forms.TextBox txtMaNV_TD;
        private System.Windows.Forms.Label lblPhongBan;
        private System.Windows.Forms.ComboBox cboPhongBan;
        private System.Windows.Forms.Label lblNgayKy;
        private System.Windows.Forms.DateTimePicker dtNgayKy;
        private System.Windows.Forms.Label lblThoiGian;
        private System.Windows.Forms.NumericUpDown numThoiGianThuViec;
        private System.Windows.Forms.Label lblLuongTV;
        private System.Windows.Forms.NumericUpDown numLuongThuViec;
        private System.Windows.Forms.Label lblDieuKhoan;
        private System.Windows.Forms.TextBox txtDieuKhoan;
        private System.Windows.Forms.Button btnLapQDTD;
        private System.Windows.Forms.DataGridView dgvQDTD;

        private System.Windows.Forms.TabPage tabHopDong;
        private System.Windows.Forms.GroupBox grpHopDong;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.TextBox txtSoHD;
        private System.Windows.Forms.Label lblMaNV_HD;
        private System.Windows.Forms.TextBox txtMaNV_HD;
        private System.Windows.Forms.Label lblLoaiHD;
        private System.Windows.Forms.ComboBox cboLoaiHD;
        private System.Windows.Forms.Label lblNgayBD;
        private System.Windows.Forms.DateTimePicker dtNgayBD;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.DateTimePicker dtNgayKT;
        private System.Windows.Forms.Label lblBHYT;
        private System.Windows.Forms.TextBox txtBHYT;
        private System.Windows.Forms.Label lblBHXH;
        private System.Windows.Forms.TextBox txtBHXH;
        private System.Windows.Forms.Label lblMucDongBH;
        private System.Windows.Forms.NumericUpDown numMucDongBH;
        private System.Windows.Forms.Button btnKyHopDong;
        private System.Windows.Forms.DataGridView dgvHopDong;

        private System.Windows.Forms.Button btnDong;
    }
}