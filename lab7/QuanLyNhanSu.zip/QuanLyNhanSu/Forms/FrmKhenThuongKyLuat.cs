﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmKhenThuongKyLuat : Form
    {
        private readonly KhenThuongKyLuatService svc = new KhenThuongKyLuatService();

        public FrmKhenThuongKyLuat()
        {
            InitializeComponent();
        }

        private void FrmKhenThuongKyLuat_Load(object sender, EventArgs e)
        {
            dtNgayKT.Value = DateTime.Today;
            dtNgayKL.Value = DateTime.Today;

            cboLoaiDoiTuong.Items.Clear();
            cboLoaiDoiTuong.Items.AddRange(new object[] { "Cá nhân", "Tập thể" });
            cboLoaiDoiTuong.SelectedIndex = 0;

            TaiData();
        }

        private void TaiData()
        {
            dgvKhenThuong.DataSource = svc.LayQDKhenThuong();
            dgvKyLuat.DataSource = svc.LayQDKyLuat();
        }

        private void btnLapQDKT_Click(object sender, EventArgs e)
        {
            var k = svc.LapQDKhenThuong(
                txtSoQDKT.Text,
                dtNgayKT.Value,
                cboLoaiDoiTuong.Text,
                txtMaDoiTuong.Text,
                txtLyDoKT.Text,
                numSoTienKT.Value,
                chkChiTienMat.Checked
            );

            if (FormHelper.Bao(k))
            {
                TaiData();
                XoaFormKT();
            }
        }

        private void btnLapQDKL_Click(object sender, EventArgs e)
        {
            var k = svc.LapQDKyLuat(
                txtSoQDKL.Text,
                dtNgayKL.Value,
                cboLoaiDoiTuong.Text,
                txtMaDoiTuong.Text,
                txtLyDoKL.Text,
                numSoTienKL.Value,
                chkNopTienMat.Checked
            );

            if (FormHelper.Bao(k))
            {
                TaiData();
                XoaFormKL();
            }
        }

        private void XoaFormKT()
        {
            txtSoQDKT.Clear();
            txtLyDoKT.Clear();
            numSoTienKT.Value = 0;
            chkChiTienMat.Checked = false;
        }

        private void XoaFormKL()
        {
            txtSoQDKL.Clear();
            txtLyDoKL.Clear();
            numSoTienKL.Value = 0;
            chkNopTienMat.Checked = false;
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}