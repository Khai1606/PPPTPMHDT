﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmHoSoNhanVien : Form
    {
        public FrmHoSoNhanVien() { InitializeComponent(); }

        private void FrmHoSoNhanVien_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboPhongBan, Db.Query("SELECT MaPhongBan, TenPhongBan FROM PhongBan"), "TenPhongBan", "MaPhongBan");
            FormHelper.Nap(cboChucVu, Db.Query("SELECT MaChucVu, TenChucVu FROM ChucVu"), "TenChucVu", "MaChucVu");
            cboGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ" });
            cboGioiTinh.SelectedIndex = 0;
            TaiData();
        }

        private void TaiData()
        {
            dgvNhanVien.DataSource = Db.Query(@"SELECT n.MaNhanVien, n.HoTen, n.NgaySinh, n.GioiTinh, n.SoDienThoai, 
                                                       n.TrangThai, p.TenPhongBan, c.TenChucVu 
                                                FROM NhanVien n 
                                                LEFT JOIN PhongBan p ON n.MaPhongBan = p.MaPhongBan 
                                                LEFT JOIN ChucVu c ON n.MaChucVu = c.MaChucVu");
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = @"INSERT INTO NhanVien(MaNhanVien, HoTen, NgaySinh, GioiTinh, DiaChi, SoDienThoai, TrangThai, MaPhongBan, MaChucVu) 
                               VALUES(@m, @h, @ns, @gt, @dc, @sdt, N'Thử việc', @pb, @cv)";

                Db.Execute(sql,
                    Db.P("@m", txtMaNV.Text), Db.P("@h", txtHoTen.Text), Db.P("@ns", dtNgaySinh.Value),
                    Db.P("@gt", cboGioiTinh.Text), Db.P("@dc", txtDiaChi.Text), Db.P("@sdt", txtSDT.Text),
                    Db.P("@pb", FormHelper.Gia(cboPhongBan)), Db.P("@cv", FormHelper.Gia(cboChucVu)));

                MessageBox.Show("Thêm hồ sơ nhân viên thành công!", "Thông báo");
                TaiData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Lỗi tiếp nhận hồ sơ"); }
        }

        private void btnDong_Click(object sender, EventArgs e) => Close();
    }
}