﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmKhenThuongKyLuat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabKhenThuong = new System.Windows.Forms.TabPage();
            this.dgvKhenThuong = new System.Windows.Forms.DataGridView();
            this.chkChiTienMat = new System.Windows.Forms.CheckBox();
            this.btnLapQDKT = new System.Windows.Forms.Button();
            this.numSoTienKT = new System.Windows.Forms.NumericUpDown();
            this.txtLyDoKT = new System.Windows.Forms.TextBox();
            this.txtMaDoiTuong = new System.Windows.Forms.TextBox();
            this.cboLoaiDoiTuong = new System.Windows.Forms.ComboBox();
            this.dtNgayKT = new System.Windows.Forms.DateTimePicker();
            this.txtSoQDKT = new System.Windows.Forms.TextBox();
            this.lblSoQDKT = new System.Windows.Forms.Label();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.lblLoaiDT = new System.Windows.Forms.Label();
            this.lblMaDT = new System.Windows.Forms.Label();
            this.lblSoTienKT = new System.Windows.Forms.Label();
            this.lblLyDoKT = new System.Windows.Forms.Label();

            this.tabKyLuat = new System.Windows.Forms.TabPage();
            this.dgvKyLuat = new System.Windows.Forms.DataGridView();
            this.chkNopTienMat = new System.Windows.Forms.CheckBox();
            this.btnLapQDKL = new System.Windows.Forms.Button();
            this.numSoTienKL = new System.Windows.Forms.NumericUpDown();
            this.txtLyDoKL = new System.Windows.Forms.TextBox();
            this.dtNgayKL = new System.Windows.Forms.DateTimePicker();
            this.txtSoQDKL = new System.Windows.Forms.TextBox();
            this.lblSoQDKL = new System.Windows.Forms.Label();
            this.lblNgayKL = new System.Windows.Forms.Label();
            this.lblSoTienKL = new System.Windows.Forms.Label();
            this.lblLyDoKL = new System.Windows.Forms.Label();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabControl.SuspendLayout();
            this.tabKhenThuong.SuspendLayout();
            this.tabKyLuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienKT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienKL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhenThuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKyLuat)).BeginInit();
            this.SuspendLayout();

            // tabControl
            this.tabControl.Controls.Add(this.tabKhenThuong);
            this.tabControl.Controls.Add(this.tabKyLuat);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(760, 430);

            // tabKhenThuong
            this.tabKhenThuong.Controls.Add(this.lblLyDoKT);
            this.tabKhenThuong.Controls.Add(this.lblSoTienKT);
            this.tabKhenThuong.Controls.Add(this.lblMaDT);
            this.tabKhenThuong.Controls.Add(this.lblLoaiDT);
            this.tabKhenThuong.Controls.Add(this.lblNgayKT);
            this.tabKhenThuong.Controls.Add(this.lblSoQDKT);
            this.tabKhenThuong.Controls.Add(this.chkChiTienMat);
            this.tabKhenThuong.Controls.Add(this.btnLapQDKT);
            this.tabKhenThuong.Controls.Add(this.numSoTienKT);
            this.tabKhenThuong.Controls.Add(this.txtLyDoKT);
            this.tabKhenThuong.Controls.Add(this.txtMaDoiTuong);
            this.tabKhenThuong.Controls.Add(this.cboLoaiDoiTuong);
            this.tabKhenThuong.Controls.Add(this.dtNgayKT);
            this.tabKhenThuong.Controls.Add(this.txtSoQDKT);
            this.tabKhenThuong.Controls.Add(this.dgvKhenThuong);
            this.tabKhenThuong.Text = "Quyết Định Khen Thưởng";

            // Controls Layout Khen Thuong
            this.lblSoQDKT.Text = "Số QĐ:"; this.lblSoQDKT.Location = new System.Drawing.Point(15, 20);
            this.txtSoQDKT.Location = new System.Drawing.Point(65, 18); this.txtSoQDKT.Size = new System.Drawing.Size(90, 20);

            this.lblNgayKT.Text = "Ngày ký:"; this.lblNgayKT.Location = new System.Drawing.Point(165, 20);
            this.dtNgayKT.Location = new System.Drawing.Point(220, 18); this.dtNgayKT.Size = new System.Drawing.Size(110, 20);

            this.lblLoaiDT.Text = "Đối tượng:"; this.lblLoaiDT.Location = new System.Drawing.Point(340, 20);
            this.cboLoaiDoiTuong.Location = new System.Drawing.Point(405, 18); this.cboLoaiDoiTuong.Size = new System.Drawing.Size(90, 21);

            this.lblMaDT.Text = "Mã ĐT:"; this.lblMaDT.Location = new System.Drawing.Point(505, 20);
            this.txtMaDoiTuong.Location = new System.Drawing.Point(555, 18); this.txtMaDoiTuong.Size = new System.Drawing.Size(80, 20);

            this.lblSoTienKT.Text = "Tiền thưởng:"; this.lblSoTienKT.Location = new System.Drawing.Point(645, 20);
            this.numSoTienKT.Location = new System.Drawing.Point(645, 38); this.numSoTienKT.Size = new System.Drawing.Size(100, 20);
            this.numSoTienKT.Maximum = 100000000;

            this.lblLyDoKT.Text = "Lý do:"; this.lblLyDoKT.Location = new System.Drawing.Point(15, 50);
            this.txtLyDoKT.Location = new System.Drawing.Point(65, 48); this.txtLyDoKT.Size = new System.Drawing.Size(375, 20);

            this.chkChiTienMat.Location = new System.Drawing.Point(450, 48); this.chkChiTienMat.Size = new System.Drawing.Size(180, 20);
            this.chkChiTienMat.Text = "Lập phiếu chi tiền mặt";

            this.btnLapQDKT.Location = new System.Drawing.Point(645, 65); this.btnLapQDKT.Size = new System.Drawing.Size(100, 25);
            this.btnLapQDKT.Text = "Lập QĐ KT"; this.btnLapQDKT.Click += new System.EventHandler(this.btnLapQDKT_Click);

            this.dgvKhenThuong.Location = new System.Drawing.Point(15, 95); this.dgvKhenThuong.Size = new System.Drawing.Size(730, 295);

            // tabKyLuat
            this.tabKyLuat.Controls.Add(this.lblLyDoKL);
            this.tabKyLuat.Controls.Add(this.lblSoTienKL);
            this.tabKyLuat.Controls.Add(this.lblNgayKL);
            this.tabKyLuat.Controls.Add(this.lblSoQDKL);
            this.tabKyLuat.Controls.Add(this.chkNopTienMat);
            this.tabKyLuat.Controls.Add(this.btnLapQDKL);
            this.tabKyLuat.Controls.Add(this.numSoTienKL);
            this.tabKyLuat.Controls.Add(this.txtLyDoKL);
            this.tabKyLuat.Controls.Add(this.dtNgayKL);
            this.tabKyLuat.Controls.Add(this.txtSoQDKL);
            this.tabKyLuat.Controls.Add(this.dgvKyLuat);
            this.tabKyLuat.Text = "Quyết Định Kỷ Luật";

            // Controls Layout Ky Luat
            this.lblSoQDKL.Text = "Số QĐ:"; this.lblSoQDKL.Location = new System.Drawing.Point(15, 20);
            this.txtSoQDKL.Location = new System.Drawing.Point(65, 18); this.txtSoQDKL.Size = new System.Drawing.Size(100, 20);

            this.lblNgayKL.Text = "Ngày ký:"; this.lblNgayKL.Location = new System.Drawing.Point(180, 20);
            this.dtNgayKL.Location = new System.Drawing.Point(235, 18); this.dtNgayKL.Size = new System.Drawing.Size(120, 20);

            this.lblSoTienKL.Text = "Tiền phạt:"; this.lblSoTienKL.Location = new System.Drawing.Point(370, 20);
            this.numSoTienKL.Location = new System.Drawing.Point(430, 18); this.numSoTienKL.Size = new System.Drawing.Size(110, 20);
            this.numSoTienKL.Maximum = 50000000;

            this.lblLyDoKL.Text = "Lý do:"; this.lblLyDoKL.Location = new System.Drawing.Point(15, 50);
            this.txtLyDoKL.Location = new System.Drawing.Point(65, 48); this.txtLyDoKL.Size = new System.Drawing.Size(290, 20);

            this.chkNopTienMat.Location = new System.Drawing.Point(370, 48); this.chkNopTienMat.Size = new System.Drawing.Size(180, 20);
            this.chkNopTienMat.Text = "Lập phiếu thu tiền mặt";

            this.btnLapQDKL.Location = new System.Drawing.Point(645, 45); this.btnLapQDKL.Size = new System.Drawing.Size(100, 25);
            this.btnLapQDKL.Text = "Lập QĐ KL"; this.btnLapQDKL.Click += new System.EventHandler(this.btnLapQDKL_Click);

            this.dgvKyLuat.Location = new System.Drawing.Point(15, 85); this.dgvKyLuat.Size = new System.Drawing.Size(730, 305);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(672, 450);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // FrmKhenThuongKyLuat
            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Khen thưởng & Kỷ luật";
            this.Load += new System.EventHandler(this.FrmKhenThuongKyLuat_Load);

            this.tabControl.ResumeLayout(false);
            this.tabKhenThuong.ResumeLayout(false); this.tabKhenThuong.PerformLayout();
            this.tabKyLuat.ResumeLayout(false); this.tabKyLuat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienKT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienKL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhenThuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKyLuat)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabKhenThuong;
        private System.Windows.Forms.TabPage tabKyLuat;
        private System.Windows.Forms.DataGridView dgvKhenThuong;
        private System.Windows.Forms.TextBox txtSoQDKT;
        private System.Windows.Forms.DateTimePicker dtNgayKT;
        private System.Windows.Forms.ComboBox cboLoaiDoiTuong;
        private System.Windows.Forms.TextBox txtMaDoiTuong;
        private System.Windows.Forms.TextBox txtLyDoKT;
        private System.Windows.Forms.NumericUpDown numSoTienKT;
        private System.Windows.Forms.CheckBox chkChiTienMat;
        private System.Windows.Forms.Button btnLapQDKT;
        private System.Windows.Forms.Label lblSoQDKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.Label lblLoaiDT;
        private System.Windows.Forms.Label lblMaDT;
        private System.Windows.Forms.Label lblSoTienKT;
        private System.Windows.Forms.Label lblLyDoKT;

        private System.Windows.Forms.DataGridView dgvKyLuat;
        private System.Windows.Forms.TextBox txtSoQDKL;
        private System.Windows.Forms.DateTimePicker dtNgayKL;
        private System.Windows.Forms.TextBox txtLyDoKL;
        private System.Windows.Forms.NumericUpDown numSoTienKL;
        private System.Windows.Forms.CheckBox chkNopTienMat;
        private System.Windows.Forms.Button btnLapQDKL;
        private System.Windows.Forms.Label lblSoQDKL;
        private System.Windows.Forms.Label lblNgayKL;
        private System.Windows.Forms.Label lblSoTienKL;
        private System.Windows.Forms.Label lblLyDoKL;

        private System.Windows.Forms.Button btnDong;
    }
}