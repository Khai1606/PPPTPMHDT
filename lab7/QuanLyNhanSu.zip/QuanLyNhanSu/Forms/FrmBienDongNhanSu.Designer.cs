﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmBienDongNhanSu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabLuong = new System.Windows.Forms.TabPage();
            this.dgvQDLuong = new System.Windows.Forms.DataGridView();
            this.btnLapQDLuong = new System.Windows.Forms.Button();
            this.dtNgayAD_L = new System.Windows.Forms.DateTimePicker();
            this.numPhuCapDH = new System.Windows.Forms.NumericUpDown();
            this.numPhuCap = new System.Windows.Forms.NumericUpDown();
            this.numLuongCB = new System.Windows.Forms.NumericUpDown();
            this.dtNgayKy_L = new System.Windows.Forms.DateTimePicker();
            this.txtMaNV_L = new System.Windows.Forms.TextBox();
            this.txtSoQDL = new System.Windows.Forms.TextBox();

            this.tabChucVu = new System.Windows.Forms.TabPage();
            this.dgvQDChucVu = new System.Windows.Forms.DataGridView();
            this.btnLapQDCV = new System.Windows.Forms.Button();
            this.txtNoiDungCV = new System.Windows.Forms.TextBox();
            this.dtNgayAD_CV = new System.Windows.Forms.DateTimePicker();
            this.dtNgayKy_CV = new System.Windows.Forms.DateTimePicker();
            this.cboChucVu = new System.Windows.Forms.ComboBox();
            this.txtMaNV_CV = new System.Windows.Forms.TextBox();
            this.txtSoQDCV = new System.Windows.Forms.TextBox();
            this.btnDong = new System.Windows.Forms.Button();

            this.tabControl.SuspendLayout();
            this.tabLuong.SuspendLayout();
            this.tabChucVu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCapDH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuongCB)).BeginInit();
            this.SuspendLayout();

            this.tabControl.Controls.Add(this.tabLuong);
            this.tabControl.Controls.Add(this.tabChucVu);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Size = new System.Drawing.Size(760, 430);

            // Tab QĐ Lương
            this.tabLuong.Controls.Add(this.btnLapQDLuong);
            this.tabLuong.Controls.Add(this.dtNgayAD_L);
            this.tabLuong.Controls.Add(this.numPhuCapDH);
            this.tabLuong.Controls.Add(this.numPhuCap);
            this.tabLuong.Controls.Add(this.numLuongCB);
            this.tabLuong.Controls.Add(this.dtNgayKy_L);
            this.tabLuong.Controls.Add(this.txtMaNV_L);
            this.tabLuong.Controls.Add(this.txtSoQDL);
            this.tabLuong.Controls.Add(this.dgvQDLuong);
            this.tabLuong.Text = "Quyết Định Lương";

            this.txtSoQDL.Location = new System.Drawing.Point(20, 20); this.txtSoQDL.Size = new System.Drawing.Size(100, 20);
            this.txtMaNV_L.Location = new System.Drawing.Point(130, 20); this.txtMaNV_L.Size = new System.Drawing.Size(100, 20);
            this.dtNgayKy_L.Location = new System.Drawing.Point(240, 20); this.dtNgayKy_L.Size = new System.Drawing.Size(120, 20);
            this.numLuongCB.Location = new System.Drawing.Point(370, 20); this.numLuongCB.Maximum = 100000000;
            this.numPhuCap.Location = new System.Drawing.Point(500, 20); this.numPhuCap.Maximum = 50000000;
            this.numPhuCapDH.Location = new System.Drawing.Point(630, 20); this.numPhuCapDH.Maximum = 50000000;
            this.dtNgayAD_L.Location = new System.Drawing.Point(240, 50); this.dtNgayAD_L.Size = new System.Drawing.Size(120, 20);

            this.btnLapQDLuong.Location = new System.Drawing.Point(630, 48); this.btnLapQDLuong.Text = "Lập QĐ Lương"; this.btnLapQDLuong.Click += new System.EventHandler(this.btnLapQDLuong_Click);
            this.dgvQDLuong.Location = new System.Drawing.Point(20, 85); this.dgvQDLuong.Size = new System.Drawing.Size(710, 305);

            // Tab QĐ Chức Vụ
            this.tabChucVu.Controls.Add(this.btnLapQDCV);
            this.tabChucVu.Controls.Add(this.txtNoiDungCV);
            this.tabChucVu.Controls.Add(this.dtNgayAD_CV);
            this.tabChucVu.Controls.Add(this.dtNgayKy_CV);
            this.tabChucVu.Controls.Add(this.cboChucVu);
            this.tabChucVu.Controls.Add(this.txtMaNV_CV);
            this.tabChucVu.Controls.Add(this.txtSoQDCV);
            this.tabChucVu.Controls.Add(this.dgvQDChucVu);
            this.tabChucVu.Text = "Quyết Định Chức Vụ";

            this.txtSoQDCV.Location = new System.Drawing.Point(20, 20); this.txtSoQDCV.Size = new System.Drawing.Size(100, 20);
            this.txtMaNV_CV.Location = new System.Drawing.Point(130, 20); this.txtMaNV_CV.Size = new System.Drawing.Size(100, 20);
            this.cboChucVu.Location = new System.Drawing.Point(240, 20); this.cboChucVu.Size = new System.Drawing.Size(150, 21);
            this.dtNgayKy_CV.Location = new System.Drawing.Point(400, 20); this.dtNgayKy_CV.Size = new System.Drawing.Size(120, 20);
            this.dtNgayAD_CV.Location = new System.Drawing.Point(530, 20); this.dtNgayAD_CV.Size = new System.Drawing.Size(120, 20);
            this.txtNoiDungCV.Location = new System.Drawing.Point(20, 50); this.txtNoiDungCV.Size = new System.Drawing.Size(500, 20);

            this.btnLapQDCV.Location = new System.Drawing.Point(530, 48); this.btnLapQDCV.Text = "Lập QĐ Chức Vụ"; this.btnLapQDCV.Click += new System.EventHandler(this.btnLapQDCV_Click);
            this.dgvQDChucVu.Location = new System.Drawing.Point(20, 85); this.dgvQDChucVu.Size = new System.Drawing.Size(710, 305);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(672, 450);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Biến động Nhân sự";
            this.Load += new System.EventHandler(this.FrmBienDongNhanSu_Load);
            this.tabControl.ResumeLayout(false);
            this.tabLuong.ResumeLayout(false); this.tabLuong.PerformLayout();
            this.tabChucVu.ResumeLayout(false); this.tabChucVu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCapDH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPhuCap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuongCB)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabLuong;
        private System.Windows.Forms.TabPage tabChucVu;
        private System.Windows.Forms.DataGridView dgvQDLuong;
        private System.Windows.Forms.TextBox txtSoQDL;
        private System.Windows.Forms.TextBox txtMaNV_L;
        private System.Windows.Forms.DateTimePicker dtNgayKy_L;
        private System.Windows.Forms.NumericUpDown numLuongCB;
        private System.Windows.Forms.NumericUpDown numPhuCap;
        private System.Windows.Forms.NumericUpDown numPhuCapDH;
        private System.Windows.Forms.DateTimePicker dtNgayAD_L;
        private System.Windows.Forms.Button btnLapQDLuong;
        private System.Windows.Forms.DataGridView dgvQDChucVu;
        private System.Windows.Forms.TextBox txtSoQDCV;
        private System.Windows.Forms.TextBox txtMaNV_CV;
        private System.Windows.Forms.ComboBox cboChucVu;
        private System.Windows.Forms.DateTimePicker dtNgayKy_CV;
        private System.Windows.Forms.DateTimePicker dtNgayAD_CV;
        private System.Windows.Forms.TextBox txtNoiDungCV;
        private System.Windows.Forms.Button btnLapQDCV;
        private System.Windows.Forms.Button btnDong;
    }
}