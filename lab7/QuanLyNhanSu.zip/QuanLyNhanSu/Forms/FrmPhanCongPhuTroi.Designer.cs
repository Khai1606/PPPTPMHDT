﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmPhanCongPhuTroi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPhanCong = new System.Windows.Forms.TabPage();
            this.dgvPhanCong = new System.Windows.Forms.DataGridView();
            this.btnLapKH = new System.Windows.Forms.Button();
            this.txtCa = new System.Windows.Forms.TextBox();
            this.dtNgayLapKH = new System.Windows.Forms.DateTimePicker();
            this.numNam = new System.Windows.Forms.NumericUpDown();
            this.numTuan = new System.Windows.Forms.NumericUpDown();
            this.cboPhongBan = new System.Windows.Forms.ComboBox();
            this.txtMaKH = new System.Windows.Forms.TextBox();

            this.tabPhuTroi = new System.Windows.Forms.TabPage();
            this.dgvPhuTroi = new System.Windows.Forms.DataGridView();
            this.btnLapPhieuPT = new System.Windows.Forms.Button();
            this.txtMaNV_PT = new System.Windows.Forms.TextBox();
            this.cboHinhThuc = new System.Windows.Forms.ComboBox();
            this.numSoGioPT = new System.Windows.Forms.NumericUpDown();
            this.dtNgayPT = new System.Windows.Forms.DateTimePicker();
            this.txtSoPhieuPT = new System.Windows.Forms.TextBox();
            this.btnDong = new System.Windows.Forms.Button();

            this.tabControl.SuspendLayout();
            this.tabPhanCong.SuspendLayout();
            this.tabPhuTroi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoGioPT)).BeginInit();
            this.SuspendLayout();

            this.tabControl.Controls.Add(this.tabPhanCong);
            this.tabControl.Controls.Add(this.tabPhuTroi);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Size = new System.Drawing.Size(760, 430);

            // Tab Phân công Ca
            this.tabPhanCong.Controls.Add(this.btnLapKH);
            this.tabPhanCong.Controls.Add(this.txtCa);
            this.tabPhanCong.Controls.Add(this.dtNgayLapKH);
            this.tabPhanCong.Controls.Add(this.numNam);
            this.tabPhanCong.Controls.Add(this.numTuan);
            this.tabPhanCong.Controls.Add(this.cboPhongBan);
            this.tabPhanCong.Controls.Add(this.txtMaKH);
            this.tabPhanCong.Controls.Add(this.dgvPhanCong);
            this.tabPhanCong.Text = "Kế Hoạch Phân Công Ca";

            this.txtMaKH.Location = new System.Drawing.Point(20, 20); this.txtMaKH.Size = new System.Drawing.Size(100, 20);
            this.cboPhongBan.Location = new System.Drawing.Point(130, 20); this.cboPhongBan.Size = new System.Drawing.Size(150, 21);
            this.numTuan.Location = new System.Drawing.Point(290, 20); this.numTuan.Value = 40;
            this.numNam.Location = new System.Drawing.Point(360, 20); this.numNam.Maximum = 2100; this.numNam.Value = 2026;
            this.dtNgayLapKH.Location = new System.Drawing.Point(450, 20); this.dtNgayLapKH.Size = new System.Drawing.Size(120, 20);
            this.txtCa.Location = new System.Drawing.Point(20, 50); this.txtCa.Size = new System.Drawing.Size(550, 20);

            this.btnLapKH.Location = new System.Drawing.Point(590, 48); this.btnLapKH.Text = "Lập Kế Hoạch"; this.btnLapKH.Click += new System.EventHandler(this.btnLapKH_Click);
            this.dgvPhanCong.Location = new System.Drawing.Point(20, 85); this.dgvPhanCong.Size = new System.Drawing.Size(710, 305);

            // Tab Phụ Trội
            this.tabPhuTroi.Controls.Add(this.btnLapPhieuPT);
            this.tabPhuTroi.Controls.Add(this.txtMaNV_PT);
            this.tabPhuTroi.Controls.Add(this.cboHinhThuc);
            this.tabPhuTroi.Controls.Add(this.numSoGioPT);
            this.tabPhuTroi.Controls.Add(this.dtNgayPT);
            this.tabPhuTroi.Controls.Add(this.txtSoPhieuPT);
            this.tabPhuTroi.Controls.Add(this.dgvPhuTroi);
            this.tabPhuTroi.Text = "Phiếu Giờ Phụ Trội (x1.5)";

            this.txtSoPhieuPT.Location = new System.Drawing.Point(20, 20); this.txtSoPhieuPT.Size = new System.Drawing.Size(100, 20);
            this.dtNgayPT.Location = new System.Drawing.Point(130, 20); this.dtNgayPT.Size = new System.Drawing.Size(120, 20);
            this.numSoGioPT.Location = new System.Drawing.Point(260, 20); this.numSoGioPT.Value = 4;
            this.cboHinhThuc.Location = new System.Drawing.Point(340, 20); this.cboHinhThuc.Size = new System.Drawing.Size(120, 21);
            this.txtMaNV_PT.Location = new System.Drawing.Point(470, 20); this.txtMaNV_PT.Size = new System.Drawing.Size(100, 20);

            this.btnLapPhieuPT.Location = new System.Drawing.Point(590, 18); this.btnLapPhieuPT.Text = "Lập Phiếu PT"; this.btnLapPhieuPT.Click += new System.EventHandler(this.btnLapPhieuPT_Click);
            this.dgvPhuTroi.Location = new System.Drawing.Point(20, 60); this.dgvPhuTroi.Size = new System.Drawing.Size(710, 330);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(672, 450);
            this.btnDong.Size = new System.Drawing.Size(100, 30);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.ClientSize = new System.Drawing.Size(784, 495);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phân công ca & Theo dõi giờ phụ trội";
            this.Load += new System.EventHandler(this.FrmPhanCongPhuTroi_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPhanCong.ResumeLayout(false); this.tabPhanCong.PerformLayout();
            this.tabPhuTroi.ResumeLayout(false); this.tabPhuTroi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoGioPT)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPhanCong;
        private System.Windows.Forms.TabPage tabPhuTroi;
        private System.Windows.Forms.DataGridView dgvPhanCong;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.ComboBox cboPhongBan;
        private System.Windows.Forms.NumericUpDown numTuan;
        private System.Windows.Forms.NumericUpDown numNam;
        private System.Windows.Forms.DateTimePicker dtNgayLapKH;
        private System.Windows.Forms.TextBox txtCa;
        private System.Windows.Forms.Button btnLapKH;
        private System.Windows.Forms.DataGridView dgvPhuTroi;
        private System.Windows.Forms.TextBox txtSoPhieuPT;
        private System.Windows.Forms.DateTimePicker dtNgayPT;
        private System.Windows.Forms.NumericUpDown numSoGioPT;
        private System.Windows.Forms.ComboBox cboHinhThuc;
        private System.Windows.Forms.TextBox txtMaNV_PT;
        private System.Windows.Forms.Button btnLapPhieuPT;
        private System.Windows.Forms.Button btnDong;
    }
}