﻿using System;
using System.Windows.Forms;
using QuanLyNhanSu.Forms; // 1. Thêm dòng này để nhận diện FrmMain

namespace QuanLyNhanSu
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 2. Sửa Form1() thành FrmMain()
            Application.Run(new FrmMain());
        }
    }
}