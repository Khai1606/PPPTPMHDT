﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCongTyDuLich.Services;

namespace QuanLyCongTyDuLich.Forms
{
    public static class FrmHelper
    {
        public static void Nap(ComboBox cbo, DataTable dt, string hienThi, string giaTri)
        {
            cbo.DataSource = dt;
            cbo.DisplayMember = hienThi;
            cbo.ValueMember = giaTri;
        }

        public static string Gia(ComboBox cbo)
        {
            return cbo.SelectedValue != null ? cbo.SelectedValue.ToString() : "";
        }

        public static string O(DataGridView dgv, string cot)
        {
            if (dgv.CurrentRow == null || dgv.CurrentRow.Index < 0) return "";
            var v = dgv.CurrentRow.Cells[cot].Value;
            return v != null ? v.ToString() : "";
        }

        public static bool Bao(KetQuaXuLy k)
        {
            MessageBox.Show(k.ThongBao, k.ThanhCong ? "Thông báo" : "Lỗi",
                MessageBoxButtons.OK, k.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return k.ThanhCong;
        }
    }
}