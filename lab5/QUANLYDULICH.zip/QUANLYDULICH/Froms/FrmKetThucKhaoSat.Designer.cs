﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmKetThucKhaoSat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabKT = new System.Windows.Forms.TabControl();

            // Tab 1: Thanh toán đoàn
            this.tabTT = new System.Windows.Forms.TabPage();
            this.dgvDoan = new System.Windows.Forms.DataGridView();
            this.lblSoTT = new System.Windows.Forms.Label();
            this.txtSoTT = new System.Windows.Forms.TextBox();
            this.lblSoDK = new System.Windows.Forms.Label();
            this.txtSoDK = new System.Windows.Forms.TextBox();
            this.lblNgayTT = new System.Windows.Forms.Label();
            this.dtTT = new System.Windows.Forms.DateTimePicker();
            this.lblTien = new System.Windows.Forms.Label();
            this.numTien = new System.Windows.Forms.NumericUpDown();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();

            // Tab 2: Khảo sát
            this.tabKS = new System.Windows.Forms.TabPage();
            this.lblLoaiKS = new System.Windows.Forms.Label();
            this.cboLoaiKS = new System.Windows.Forms.ComboBox();
            this.lblDangKy = new System.Windows.Forms.Label();
            this.cboDangKy = new System.Windows.Forms.ComboBox();
            this.lblMaKS = new System.Windows.Forms.Label();
            this.txtMaKS = new System.Windows.Forms.TextBox();
            this.lblGui = new System.Windows.Forms.Label();
            this.dtGui = new System.Windows.Forms.DateTimePicker();
            this.btnGui = new System.Windows.Forms.Button();
            this.dgvKS = new System.Windows.Forms.DataGridView();
            this.lblKSChon = new System.Windows.Forms.Label();
            this.txtKSChon = new System.Windows.Forms.TextBox();
            this.lblPH = new System.Windows.Forms.Label();
            this.dtPH = new System.Windows.Forms.DateTimePicker();
            this.lblDiem = new System.Windows.Forms.Label();
            this.numDiem = new System.Windows.Forms.NumericUpDown();
            this.lblGopY = new System.Windows.Forms.Label();
            this.txtGopY = new System.Windows.Forms.TextBox();
            this.btnGhiPH = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabKT.SuspendLayout();
            this.tabTT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).BeginInit();
            this.tabKS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).BeginInit();
            this.SuspendLayout();

            // 
            // tabKT
            // 
            this.tabKT.Controls.Add(this.tabTT);
            this.tabKT.Controls.Add(this.tabKS);
            this.tabKT.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabKT.Location = new System.Drawing.Point(12, 12);
            this.tabKT.Name = "tabKT";
            this.tabKT.SelectedIndex = 0;
            this.tabKT.Size = new System.Drawing.Size(960, 580);
            this.tabKT.TabIndex = 0;

            // 
            // tabTT (Thanh toán sau tour)
            // 
            this.tabTT.Controls.Add(this.dgvDoan);
            this.tabTT.Controls.Add(this.lblSoTT);
            this.tabTT.Controls.Add(this.txtSoTT);
            this.tabTT.Controls.Add(this.lblSoDK);
            this.tabTT.Controls.Add(this.txtSoDK);
            this.tabTT.Controls.Add(this.lblNgayTT);
            this.tabTT.Controls.Add(this.dtTT);
            this.tabTT.Controls.Add(this.lblTien);
            this.tabTT.Controls.Add(this.numTien);
            this.tabTT.Controls.Add(this.lblGhiChu);
            this.tabTT.Controls.Add(this.txtGhiChu);
            this.tabTT.Controls.Add(this.btnThanhToan);
            this.tabTT.Location = new System.Drawing.Point(4, 29);
            this.tabTT.Name = "tabTT";
            this.tabTT.Padding = new System.Windows.Forms.Padding(3);
            this.tabTT.Size = new System.Drawing.Size(952, 547);
            this.tabTT.TabIndex = 0;
            this.tabTT.Text = "Thanh toán sau tour (đoàn)";
            this.tabTT.UseVisualStyleBackColor = true;

            // dgvDoan
            this.dgvDoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoan.Location = new System.Drawing.Point(15, 15);
            this.dgvDoan.Name = "dgvDoan";
            this.dgvDoan.RowHeadersWidth = 51;
            this.dgvDoan.RowTemplate.Height = 24;
            this.dgvDoan.Size = new System.Drawing.Size(920, 370);
            this.dgvDoan.TabIndex = 0;
            this.dgvDoan.SelectionChanged += new System.EventHandler(this.dgvDoan_SelectionChanged);

            // lblSoTT & txtSoTT
            this.lblSoTT.AutoSize = true;
            this.lblSoTT.Location = new System.Drawing.Point(15, 410);
            this.lblSoTT.Text = "Số thanh toán:";
            this.txtSoTT.Location = new System.Drawing.Point(120, 407);
            this.txtSoTT.Size = new System.Drawing.Size(120, 27);

            // lblSoDK & txtSoDK
            this.lblSoDK.AutoSize = true;
            this.lblSoDK.Location = new System.Drawing.Point(260, 410);
            this.lblSoDK.Text = "Phiếu đoàn:";
            this.txtSoDK.ReadOnly = true;
            this.txtSoDK.Location = new System.Drawing.Point(345, 407);
            this.txtSoDK.Size = new System.Drawing.Size(120, 27);

            // lblNgayTT & dtTT
            this.lblNgayTT.AutoSize = true;
            this.lblNgayTT.Location = new System.Drawing.Point(485, 410);
            this.lblNgayTT.Text = "Ngày thanh toán:";
            this.dtTT.CustomFormat = "dd/MM/yyyy";
            this.dtTT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTT.Location = new System.Drawing.Point(610, 407);
            this.dtTT.Size = new System.Drawing.Size(125, 27);

            // lblTien & numTien
            this.lblTien.AutoSize = true;
            this.lblTien.Location = new System.Drawing.Point(15, 455);
            this.lblTien.Text = "Số tiền:";
            this.numTien.DecimalPlaces = 0;
            this.numTien.Location = new System.Drawing.Point(120, 452);
            this.numTien.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numTien.Size = new System.Drawing.Size(150, 27);

            // lblGhiChu & txtGhiChu
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Location = new System.Drawing.Point(290, 455);
            this.lblGhiChu.Text = "Ghi chú:";
            this.txtGhiChu.Location = new System.Drawing.Point(355, 452);
            this.txtGhiChu.Size = new System.Drawing.Size(380, 27);

            // btnThanhToan
            this.btnThanhToan.Location = new System.Drawing.Point(755, 448);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(180, 35);
            this.btnThanhToan.TabIndex = 6;
            this.btnThanhToan.Text = "Ghi nhận thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);

            // 
            // tabKS (Khảo sát khách hàng)
            // 
            this.tabKS.Controls.Add(this.lblLoaiKS);
            this.tabKS.Controls.Add(this.cboLoaiKS);
            this.tabKS.Controls.Add(this.lblDangKy);
            this.tabKS.Controls.Add(this.cboDangKy);
            this.tabKS.Controls.Add(this.lblMaKS);
            this.tabKS.Controls.Add(this.txtMaKS);
            this.tabKS.Controls.Add(this.lblGui);
            this.tabKS.Controls.Add(this.dtGui);
            this.tabKS.Controls.Add(this.btnGui);
            this.tabKS.Controls.Add(this.dgvKS);
            this.tabKS.Controls.Add(this.lblKSChon);
            this.tabKS.Controls.Add(this.txtKSChon);
            this.tabKS.Controls.Add(this.lblPH);
            this.tabKS.Controls.Add(this.dtPH);
            this.tabKS.Controls.Add(this.lblDiem);
            this.tabKS.Controls.Add(this.numDiem);
            this.tabKS.Controls.Add(this.lblGopY);
            this.tabKS.Controls.Add(this.txtGopY);
            this.tabKS.Controls.Add(this.btnGhiPH);
            this.tabKS.Location = new System.Drawing.Point(4, 29);
            this.tabKS.Name = "tabKS";
            this.tabKS.Padding = new System.Windows.Forms.Padding(3);
            this.tabKS.Size = new System.Drawing.Size(952, 547);
            this.tabKS.TabIndex = 1;
            this.tabKS.Text = "Khảo sát khách hàng";
            this.tabKS.UseVisualStyleBackColor = true;

            // Block gửi khảo sát
            this.lblLoaiKS.AutoSize = true;
            this.lblLoaiKS.Location = new System.Drawing.Point(15, 20);
            this.lblLoaiKS.Text = "Loại khách:";
            this.cboLoaiKS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKS.Location = new System.Drawing.Point(100, 17);
            this.cboLoaiKS.Size = new System.Drawing.Size(90, 28);
            this.cboLoaiKS.SelectedIndexChanged += new System.EventHandler(this.cboLoaiKS_SelectedIndexChanged);

            this.lblDangKy.AutoSize = true;
            this.lblDangKy.Location = new System.Drawing.Point(205, 20);
            this.lblDangKy.Text = "Đăng ký đã kết thúc:";
            this.cboDangKy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDangKy.Location = new System.Drawing.Point(340, 17);
            this.cboDangKy.Size = new System.Drawing.Size(260, 28);

            this.lblMaKS.AutoSize = true;
            this.lblMaKS.Location = new System.Drawing.Point(615, 20);
            this.lblMaKS.Text = "Mã KS:";
            this.txtMaKS.Location = new System.Drawing.Point(675, 17);
            this.txtMaKS.Size = new System.Drawing.Size(90, 27);

            this.lblGui.AutoSize = true;
            this.lblGui.Location = new System.Drawing.Point(15, 60);
            this.lblGui.Text = "Ngày gửi:";
            this.dtGui.CustomFormat = "dd/MM/yyyy";
            this.dtGui.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtGui.Location = new System.Drawing.Point(100, 57);
            this.dtGui.Size = new System.Drawing.Size(120, 27);

            this.btnGui.Location = new System.Drawing.Point(780, 15);
            this.btnGui.Name = "btnGui";
            this.btnGui.Size = new System.Drawing.Size(155, 35);
            this.btnGui.Text = "Gửi phiếu khảo sát";
            this.btnGui.UseVisualStyleBackColor = true;
            this.btnGui.Click += new System.EventHandler(this.btnGui_Click);

            // dgvKS
            this.dgvKS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKS.Location = new System.Drawing.Point(15, 100);
            this.dgvKS.Name = "dgvKS";
            this.dgvKS.RowHeadersWidth = 51;
            this.dgvKS.RowTemplate.Height = 24;
            this.dgvKS.Size = new System.Drawing.Size(920, 290);
            this.dgvKS.SelectionChanged += new System.EventHandler(this.dgvKS_SelectionChanged);

            // Block ghi nhận phản hồi
            this.lblKSChon.AutoSize = true;
            this.lblKSChon.Location = new System.Drawing.Point(15, 410);
            this.lblKSChon.Text = "Phiếu chọn:";
            this.txtKSChon.ReadOnly = true;
            this.txtKSChon.Location = new System.Drawing.Point(105, 407);
            this.txtKSChon.Size = new System.Drawing.Size(100, 27);

            this.lblPH.AutoSize = true;
            this.lblPH.Location = new System.Drawing.Point(220, 410);
            this.lblPH.Text = "Ngày phản hồi:";
            this.dtPH.CustomFormat = "dd/MM/yyyy";
            this.dtPH.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPH.Location = new System.Drawing.Point(330, 407);
            this.dtPH.Size = new System.Drawing.Size(120, 27);

            this.lblDiem.AutoSize = true;
            this.lblDiem.Location = new System.Drawing.Point(465, 410);
            this.lblDiem.Text = "Điểm (1-5):";
            this.numDiem.Location = new System.Drawing.Point(545, 407);
            this.numDiem.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            this.numDiem.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numDiem.Size = new System.Drawing.Size(60, 27);
            this.numDiem.Value = new decimal(new int[] { 5, 0, 0, 0 });

            this.lblGopY.AutoSize = true;
            this.lblGopY.Location = new System.Drawing.Point(15, 455);
            this.lblGopY.Text = "Góp ý:";
            this.txtGopY.Location = new System.Drawing.Point(105, 452);
            this.txtGopY.Size = new System.Drawing.Size(650, 27);

            this.btnGhiPH.Location = new System.Drawing.Point(780, 448);
            this.btnGhiPH.Name = "btnGhiPH";
            this.btnGhiPH.Size = new System.Drawing.Size(155, 35);
            this.btnGhiPH.Text = "Ghi nhận góp ý";
            this.btnGhiPH.UseVisualStyleBackColor = true;
            this.btnGhiPH.Click += new System.EventHandler(this.btnGhiPH_Click);

            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(862, 602);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // 
            // FrmKetThucKhaoSat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 650);
            this.Controls.Add(this.tabKT);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmKetThucKhaoSat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Kết thúc tour - thanh toán đoàn - khảo sát";
            this.Load += new System.EventHandler(this.FrmKetThucKhaoSat_Load);
            this.tabKT.ResumeLayout(false);
            this.tabTT.ResumeLayout(false);
            this.tabTT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).EndInit();
            this.tabKS.ResumeLayout(false);
            this.tabKS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabKT;
        private System.Windows.Forms.TabPage tabTT;
        private System.Windows.Forms.DataGridView dgvDoan;
        private System.Windows.Forms.Label lblSoTT;
        private System.Windows.Forms.TextBox txtSoTT;
        private System.Windows.Forms.Label lblSoDK;
        private System.Windows.Forms.TextBox txtSoDK;
        private System.Windows.Forms.Label lblNgayTT;
        private System.Windows.Forms.DateTimePicker dtTT;
        private System.Windows.Forms.Label lblTien;
        private System.Windows.Forms.NumericUpDown numTien;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnThanhToan;

        private System.Windows.Forms.TabPage tabKS;
        private System.Windows.Forms.Label lblLoaiKS;
        private System.Windows.Forms.ComboBox cboLoaiKS;
        private System.Windows.Forms.Label lblDangKy;
        private System.Windows.Forms.ComboBox cboDangKy;
        private System.Windows.Forms.Label lblMaKS;
        private System.Windows.Forms.TextBox txtMaKS;
        private System.Windows.Forms.Label lblGui;
        private System.Windows.Forms.DateTimePicker dtGui;
        private System.Windows.Forms.Button btnGui;
        private System.Windows.Forms.DataGridView dgvKS;
        private System.Windows.Forms.Label lblKSChon;
        private System.Windows.Forms.TextBox txtKSChon;
        private System.Windows.Forms.Label lblPH;
        private System.Windows.Forms.DateTimePicker dtPH;
        private System.Windows.Forms.Label lblDiem;
        private System.Windows.Forms.NumericUpDown numDiem;
        private System.Windows.Forms.Label lblGopY;
        private System.Windows.Forms.TextBox txtGopY;
        private System.Windows.Forms.Button btnGhiPH;

        private System.Windows.Forms.Button btnDong;
    }
}