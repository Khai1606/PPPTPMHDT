﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();
            this.tabPhuongTien = new System.Windows.Forms.TabPage();
            this.dgvPT = new System.Windows.Forms.DataGridView();
            this.lblPTMa = new System.Windows.Forms.Label();
            this.txtPTMa = new System.Windows.Forms.TextBox();
            this.lblPTTen = new System.Windows.Forms.Label();
            this.txtPTTen = new System.Windows.Forms.TextBox();
            this.lblPTGhiChu = new System.Windows.Forms.Label();
            this.txtPTGhiChu = new System.Windows.Forms.TextBox();
            this.btnThemPT = new System.Windows.Forms.Button();

            this.tabDiemBan = new System.Windows.Forms.TabPage();
            this.dgvDB = new System.Windows.Forms.DataGridView();
            this.lblDBMa = new System.Windows.Forms.Label();
            this.txtDBMa = new System.Windows.Forms.TextBox();
            this.lblDBTen = new System.Windows.Forms.Label();
            this.txtDBTen = new System.Windows.Forms.TextBox();
            this.lblDBDiaChi = new System.Windows.Forms.Label();
            this.txtDBDiaChi = new System.Windows.Forms.TextBox();
            this.lblDBDT = new System.Windows.Forms.Label();
            this.txtDBDT = new System.Windows.Forms.TextBox();
            this.btnThemDB = new System.Windows.Forms.Button();

            this.tabHDV = new System.Windows.Forms.TabPage();
            this.dgvHDV = new System.Windows.Forms.DataGridView();
            this.lblHDVMa = new System.Windows.Forms.Label();
            this.txtHDVMa = new System.Windows.Forms.TextBox();
            this.lblHDVTen = new System.Windows.Forms.Label();
            this.txtHDVTen = new System.Windows.Forms.TextBox();
            this.lblHDVDT = new System.Windows.Forms.Label();
            this.txtHDVDT = new System.Windows.Forms.TextBox();
            this.lblLuong = new System.Windows.Forms.Label();
            this.numLuong = new System.Windows.Forms.NumericUpDown();
            this.btnThemHDV = new System.Windows.Forms.Button();

            this.tabDiemTQ = new System.Windows.Forms.TabPage();
            this.dgvDTQ = new System.Windows.Forms.DataGridView();
            this.lblDTQMa = new System.Windows.Forms.Label();
            this.txtDTQMa = new System.Windows.Forms.TextBox();
            this.lblDTQTen = new System.Windows.Forms.Label();
            this.txtDTQTen = new System.Windows.Forms.TextBox();
            this.lblDTQDiaDiem = new System.Windows.Forms.Label();
            this.txtDTQDiaDiem = new System.Windows.Forms.TextBox();
            this.lblDTQNoiDung = new System.Windows.Forms.Label();
            this.txtDTQNoiDung = new System.Windows.Forms.TextBox();
            this.lblDTQYNghia = new System.Windows.Forms.Label();
            this.txtDTQYNghia = new System.Windows.Forms.TextBox();
            this.btnThemDTQ = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabDanhMuc.SuspendLayout();
            this.tabPhuongTien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).BeginInit();
            this.tabDiemBan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).BeginInit();
            this.tabHDV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).BeginInit();
            this.tabDiemTQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).BeginInit();
            this.SuspendLayout();

            // 
            // tabDanhMuc
            // 
            this.tabDanhMuc.Controls.Add(this.tabPhuongTien);
            this.tabDanhMuc.Controls.Add(this.tabDiemBan);
            this.tabDanhMuc.Controls.Add(this.tabHDV);
            this.tabDanhMuc.Controls.Add(this.tabDiemTQ);
            this.tabDanhMuc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabDanhMuc.Location = new System.Drawing.Point(12, 12);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(960, 580);
            this.tabDanhMuc.TabIndex = 0;

            // 
            // tabPhuongTien
            // 
            this.tabPhuongTien.Controls.Add(this.dgvPT);
            this.tabPhuongTien.Controls.Add(this.lblPTMa);
            this.tabPhuongTien.Controls.Add(this.txtPTMa);
            this.tabPhuongTien.Controls.Add(this.lblPTTen);
            this.tabPhuongTien.Controls.Add(this.txtPTTen);
            this.tabPhuongTien.Controls.Add(this.lblPTGhiChu);
            this.tabPhuongTien.Controls.Add(this.txtPTGhiChu);
            this.tabPhuongTien.Controls.Add(this.btnThemPT);
            this.tabPhuongTien.Location = new System.Drawing.Point(4, 29);
            this.tabPhuongTien.Name = "tabPhuongTien";
            this.tabPhuongTien.Padding = new System.Windows.Forms.Padding(3);
            this.tabPhuongTien.Size = new System.Drawing.Size(952, 547);
            this.tabPhuongTien.TabIndex = 0;
            this.tabPhuongTien.Text = "Phương tiện";
            this.tabPhuongTien.UseVisualStyleBackColor = true;

            // dgvPT
            this.dgvPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPT.Location = new System.Drawing.Point(15, 15);
            this.dgvPT.Name = "dgvPT";
            this.dgvPT.RowHeadersWidth = 51;
            this.dgvPT.RowTemplate.Height = 24;
            this.dgvPT.Size = new System.Drawing.Size(920, 380);
            this.dgvPT.TabIndex = 0;

            // lblPTMa, txtPTMa
            this.lblPTMa.AutoSize = true;
            this.lblPTMa.Location = new System.Drawing.Point(15, 415);
            this.lblPTMa.Name = "lblPTMa";
            this.lblPTMa.Size = new System.Drawing.Size(55, 20);
            this.lblPTMa.Text = "Mã PT:";
            this.txtPTMa.Location = new System.Drawing.Point(115, 412);
            this.txtPTMa.Name = "txtPTMa";
            this.txtPTMa.Size = new System.Drawing.Size(160, 27);
            this.txtPTMa.TabIndex = 1;

            // lblPTTen, txtPTTen
            this.lblPTTen.AutoSize = true;
            this.lblPTTen.Location = new System.Drawing.Point(300, 415);
            this.lblPTTen.Name = "lblPTTen";
            this.lblPTTen.Size = new System.Drawing.Size(57, 20);
            this.lblPTTen.Text = "Tên PT:";
            this.txtPTTen.Location = new System.Drawing.Point(410, 412);
            this.txtPTTen.Name = "txtPTTen";
            this.txtPTTen.Size = new System.Drawing.Size(270, 27);
            this.txtPTTen.TabIndex = 2;

            // lblPTGhiChu, txtPTGhiChu
            this.lblPTGhiChu.AutoSize = true;
            this.lblPTGhiChu.Location = new System.Drawing.Point(15, 460);
            this.lblPTGhiChu.Name = "lblPTGhiChu";
            this.lblPTGhiChu.Size = new System.Drawing.Size(61, 20);
            this.lblPTGhiChu.Text = "Ghi chú:";
            this.txtPTGhiChu.Location = new System.Drawing.Point(115, 457);
            this.txtPTGhiChu.Name = "txtPTGhiChu";
            this.txtPTGhiChu.Size = new System.Drawing.Size(565, 27);
            this.txtPTGhiChu.TabIndex = 3;

            // btnThemPT
            this.btnThemPT.Location = new System.Drawing.Point(705, 452);
            this.btnThemPT.Name = "btnThemPT";
            this.btnThemPT.Size = new System.Drawing.Size(110, 35);
            this.btnThemPT.TabIndex = 4;
            this.btnThemPT.Text = "Thêm";
            this.btnThemPT.UseVisualStyleBackColor = true;
            this.btnThemPT.Click += new System.EventHandler(this.btnThemPT_Click);

            // 
            // tabDiemBan
            // 
            this.tabDiemBan.Controls.Add(this.dgvDB);
            this.tabDiemBan.Controls.Add(this.lblDBMa);
            this.tabDiemBan.Controls.Add(this.txtDBMa);
            this.tabDiemBan.Controls.Add(this.lblDBTen);
            this.tabDiemBan.Controls.Add(this.txtDBTen);
            this.tabDiemBan.Controls.Add(this.lblDBDiaChi);
            this.tabDiemBan.Controls.Add(this.txtDBDiaChi);
            this.tabDiemBan.Controls.Add(this.lblDBDT);
            this.tabDiemBan.Controls.Add(this.txtDBDT);
            this.tabDiemBan.Controls.Add(this.btnThemDB);
            this.tabDiemBan.Location = new System.Drawing.Point(4, 29);
            this.tabDiemBan.Name = "tabDiemBan";
            this.tabDiemBan.Padding = new System.Windows.Forms.Padding(3);
            this.tabDiemBan.Size = new System.Drawing.Size(952, 547);
            this.tabDiemBan.TabIndex = 1;
            this.tabDiemBan.Text = "Điểm bán vé";
            this.tabDiemBan.UseVisualStyleBackColor = true;

            // dgvDB
            this.dgvDB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDB.Location = new System.Drawing.Point(15, 15);
            this.dgvDB.Name = "dgvDB";
            this.dgvDB.RowHeadersWidth = 51;
            this.dgvDB.RowTemplate.Height = 24;
            this.dgvDB.Size = new System.Drawing.Size(920, 380);
            this.dgvDB.TabIndex = 0;

            // lblDBMa, txtDBMa
            this.lblDBMa.AutoSize = true;
            this.lblDBMa.Location = new System.Drawing.Point(15, 415);
            this.lblDBMa.Name = "lblDBMa";
            this.lblDBMa.Size = new System.Drawing.Size(96, 20);
            this.lblDBMa.Text = "Mã điểm bán:";
            this.txtDBMa.Location = new System.Drawing.Point(125, 412);
            this.txtDBMa.Name = "txtDBMa";
            this.txtDBMa.Size = new System.Drawing.Size(150, 27);
            this.txtDBMa.TabIndex = 1;

            // lblDBTen, txtDBTen
            this.lblDBTen.AutoSize = true;
            this.lblDBTen.Location = new System.Drawing.Point(300, 415);
            this.lblDBTen.Name = "lblDBTen";
            this.lblDBTen.Size = new System.Drawing.Size(98, 20);
            this.lblDBTen.Text = "Tên điểm bán:";
            this.txtDBTen.Location = new System.Drawing.Point(410, 412);
            this.txtDBTen.Name = "txtDBTen";
            this.txtDBTen.Size = new System.Drawing.Size(270, 27);
            this.txtDBTen.TabIndex = 2;

            // lblDBDiaChi, txtDBDiaChi
            this.lblDBDiaChi.AutoSize = true;
            this.lblDBDiaChi.Location = new System.Drawing.Point(15, 460);
            this.lblDBDiaChi.Name = "lblDBDiaChi";
            this.lblDBDiaChi.Size = new System.Drawing.Size(58, 20);
            this.lblDBDiaChi.Text = "Địa chỉ:";
            this.txtDBDiaChi.Location = new System.Drawing.Point(125, 457);
            this.txtDBDiaChi.Name = "txtDBDiaChi";
            this.txtDBDiaChi.Size = new System.Drawing.Size(270, 27);
            this.txtDBDiaChi.TabIndex = 3;

            // lblDBDT, txtDBDT
            this.lblDBDT.AutoSize = true;
            this.lblDBDT.Location = new System.Drawing.Point(415, 460);
            this.lblDBDT.Name = "lblDBDT";
            this.lblDBDT.Size = new System.Drawing.Size(81, 20);
            this.lblDBDT.Text = "Điện thoại:";
            this.txtDBDT.Location = new System.Drawing.Point(505, 457);
            this.txtDBDT.Name = "txtDBDT";
            this.txtDBDT.Size = new System.Drawing.Size(175, 27);
            this.txtDBDT.TabIndex = 4;

            // btnThemDB
            this.btnThemDB.Location = new System.Drawing.Point(705, 452);
            this.btnThemDB.Name = "btnThemDB";
            this.btnThemDB.Size = new System.Drawing.Size(110, 35);
            this.btnThemDB.TabIndex = 5;
            this.btnThemDB.Text = "Thêm";
            this.btnThemDB.UseVisualStyleBackColor = true;
            this.btnThemDB.Click += new System.EventHandler(this.btnThemDB_Click);

            // 
            // tabHDV
            // 
            this.tabHDV.Controls.Add(this.dgvHDV);
            this.tabHDV.Controls.Add(this.lblHDVMa);
            this.tabHDV.Controls.Add(this.txtHDVMa);
            this.tabHDV.Controls.Add(this.lblHDVTen);
            this.tabHDV.Controls.Add(this.txtHDVTen);
            this.tabHDV.Controls.Add(this.lblHDVDT);
            this.tabHDV.Controls.Add(this.txtHDVDT);
            this.tabHDV.Controls.Add(this.lblLuong);
            this.tabHDV.Controls.Add(this.numLuong);
            this.tabHDV.Controls.Add(this.btnThemHDV);
            this.tabHDV.Location = new System.Drawing.Point(4, 29);
            this.tabHDV.Name = "tabHDV";
            this.tabHDV.Padding = new System.Windows.Forms.Padding(3);
            this.tabHDV.Size = new System.Drawing.Size(952, 547);
            this.tabHDV.TabIndex = 2;
            this.tabHDV.Text = "Hướng dẫn viên";
            this.tabHDV.UseVisualStyleBackColor = true;

            // dgvHDV
            this.dgvHDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHDV.Location = new System.Drawing.Point(15, 15);
            this.dgvHDV.Name = "dgvHDV";
            this.dgvHDV.RowHeadersWidth = 51;
            this.dgvHDV.RowTemplate.Height = 24;
            this.dgvHDV.Size = new System.Drawing.Size(920, 380);
            this.dgvHDV.TabIndex = 0;

            // lblHDVMa, txtHDVMa
            this.lblHDVMa.AutoSize = true;
            this.lblHDVMa.Location = new System.Drawing.Point(15, 415);
            this.lblHDVMa.Name = "lblHDVMa";
            this.lblHDVMa.Size = new System.Drawing.Size(68, 20);
            this.lblHDVMa.Text = "Mã HDV:";
            this.txtHDVMa.Location = new System.Drawing.Point(115, 412);
            this.txtHDVMa.Name = "txtHDVMa";
            this.txtHDVMa.Size = new System.Drawing.Size(160, 27);
            this.txtHDVMa.TabIndex = 1;

            // lblHDVTen, txtHDVTen
            this.lblHDVTen.AutoSize = true;
            this.lblHDVTen.Location = new System.Drawing.Point(300, 415);
            this.lblHDVTen.Name = "lblHDVTen";
            this.lblHDVTen.Size = new System.Drawing.Size(57, 20);
            this.lblHDVTen.Text = "Họ tên:";
            this.txtHDVTen.Location = new System.Drawing.Point(380, 412);
            this.txtHDVTen.Name = "txtHDVTen";
            this.txtHDVTen.Size = new System.Drawing.Size(300, 27);
            this.txtHDVTen.TabIndex = 2;

            // lblHDVDT, txtHDVDT
            this.lblHDVDT.AutoSize = true;
            this.lblHDVDT.Location = new System.Drawing.Point(15, 460);
            this.lblHDVDT.Name = "lblHDVDT";
            this.lblHDVDT.Size = new System.Drawing.Size(81, 20);
            this.lblHDVDT.Text = "Điện thoại:";
            this.txtHDVDT.Location = new System.Drawing.Point(115, 457);
            this.txtHDVDT.Name = "txtHDVDT";
            this.txtHDVDT.Size = new System.Drawing.Size(160, 27);
            this.txtHDVDT.TabIndex = 3;

            // lblLuong, numLuong
            this.lblLuong.AutoSize = true;
            this.lblLuong.Location = new System.Drawing.Point(300, 460);
            this.lblLuong.Name = "lblLuong";
            this.lblLuong.Size = new System.Drawing.Size(103, 20);
            this.lblLuong.Text = "Lương cơ bản:";
            this.numLuong.DecimalPlaces = 0;
            this.numLuong.Location = new System.Drawing.Point(410, 457);
            this.numLuong.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            this.numLuong.Name = "numLuong";
            this.numLuong.Size = new System.Drawing.Size(170, 27);
            this.numLuong.TabIndex = 4;

            // btnThemHDV
            this.btnThemHDV.Location = new System.Drawing.Point(705, 452);
            this.btnThemHDV.Name = "btnThemHDV";
            this.btnThemHDV.Size = new System.Drawing.Size(110, 35);
            this.btnThemHDV.TabIndex = 5;
            this.btnThemHDV.Text = "Thêm";
            this.btnThemHDV.UseVisualStyleBackColor = true;
            this.btnThemHDV.Click += new System.EventHandler(this.btnThemHDV_Click);

            // 
            // tabDiemTQ
            // 
            this.tabDiemTQ.Controls.Add(this.dgvDTQ);
            this.tabDiemTQ.Controls.Add(this.lblDTQMa);
            this.tabDiemTQ.Controls.Add(this.txtDTQMa);
            this.tabDiemTQ.Controls.Add(this.lblDTQTen);
            this.tabDiemTQ.Controls.Add(this.txtDTQTen);
            this.tabDiemTQ.Controls.Add(this.lblDTQDiaDiem);
            this.tabDiemTQ.Controls.Add(this.txtDTQDiaDiem);
            this.tabDiemTQ.Controls.Add(this.lblDTQNoiDung);
            this.tabDiemTQ.Controls.Add(this.txtDTQNoiDung);
            this.tabDiemTQ.Controls.Add(this.lblDTQYNghia);
            this.tabDiemTQ.Controls.Add(this.txtDTQYNghia);
            this.tabDiemTQ.Controls.Add(this.btnThemDTQ);
            this.tabDiemTQ.Location = new System.Drawing.Point(4, 29);
            this.tabDiemTQ.Name = "tabDiemTQ";
            this.tabDiemTQ.Padding = new System.Windows.Forms.Padding(3);
            this.tabDiemTQ.Size = new System.Drawing.Size(952, 547);
            this.tabDiemTQ.TabIndex = 3;
            this.tabDiemTQ.Text = "Điểm tham quan";
            this.tabDiemTQ.UseVisualStyleBackColor = true;

            // dgvDTQ
            this.dgvDTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDTQ.Location = new System.Drawing.Point(15, 15);
            this.dgvDTQ.Name = "dgvDTQ";
            this.dgvDTQ.RowHeadersWidth = 51;
            this.dgvDTQ.RowTemplate.Height = 24;
            this.dgvDTQ.Size = new System.Drawing.Size(920, 330);
            this.dgvDTQ.TabIndex = 0;

            // lblDTQMa, txtDTQMa
            this.lblDTQMa.AutoSize = true;
            this.lblDTQMa.Location = new System.Drawing.Point(15, 365);
            this.lblDTQMa.Name = "lblDTQMa";
            this.lblDTQMa.Size = new System.Drawing.Size(90, 20);
            this.lblDTQMa.Text = "Mã điểm TQ:";
            this.txtDTQMa.Location = new System.Drawing.Point(115, 362);
            this.txtDTQMa.Name = "txtDTQMa";
            this.txtDTQMa.Size = new System.Drawing.Size(150, 27);
            this.txtDTQMa.TabIndex = 1;

            // lblDTQTen, txtDTQTen
            this.lblDTQTen.AutoSize = true;
            this.lblDTQTen.Location = new System.Drawing.Point(285, 365);
            this.lblDTQTen.Name = "lblDTQTen";
            this.lblDTQTen.Size = new System.Drawing.Size(92, 20);
            this.lblDTQTen.Text = "Tên điểm TQ:";
            this.txtDTQTen.Location = new System.Drawing.Point(385, 362);
            this.txtDTQTen.Name = "txtDTQTen";
            this.txtDTQTen.Size = new System.Drawing.Size(220, 27);
            this.txtDTQTen.TabIndex = 2;

            // lblDTQDiaDiem, txtDTQDiaDiem
            this.lblDTQDiaDiem.AutoSize = true;
            this.lblDTQDiaDiem.Location = new System.Drawing.Point(625, 365);
            this.lblDTQDiaDiem.Name = "lblDTQDiaDiem";
            this.lblDTQDiaDiem.Size = new System.Drawing.Size(73, 20);
            this.lblDTQDiaDiem.Text = "Địa điểm:";
            this.txtDTQDiaDiem.Location = new System.Drawing.Point(705, 362);
            this.txtDTQDiaDiem.Name = "txtDTQDiaDiem";
            this.txtDTQDiaDiem.Size = new System.Drawing.Size(230, 27);
            this.txtDTQDiaDiem.TabIndex = 3;

            // lblDTQNoiDung, txtDTQNoiDung
            this.lblDTQNoiDung.AutoSize = true;
            this.lblDTQNoiDung.Location = new System.Drawing.Point(15, 410);
            this.lblDTQNoiDung.Name = "lblDTQNoiDung";
            this.lblDTQNoiDung.Size = new System.Drawing.Size(74, 20);
            this.lblDTQNoiDung.Text = "Nội dung:";
            this.txtDTQNoiDung.Location = new System.Drawing.Point(115, 407);
            this.txtDTQNoiDung.Name = "txtDTQNoiDung";
            this.txtDTQNoiDung.Size = new System.Drawing.Size(820, 27);
            this.txtDTQNoiDung.TabIndex = 4;

            // lblDTQYNghia, txtDTQYNghia
            this.lblDTQYNghia.AutoSize = true;
            this.lblDTQYNghia.Location = new System.Drawing.Point(15, 455);
            this.lblDTQYNghia.Name = "lblDTQYNghia";
            this.lblDTQYNghia.Size = new System.Drawing.Size(66, 20);
            this.lblDTQYNghia.Text = "Ý nghĩa:";
            this.txtDTQYNghia.Location = new System.Drawing.Point(115, 452);
            this.txtDTQYNghia.Name = "txtDTQYNghia";
            this.txtDTQYNghia.Size = new System.Drawing.Size(580, 27);
            this.txtDTQYNghia.TabIndex = 5;

            // btnThemDTQ
            this.btnThemDTQ.Location = new System.Drawing.Point(715, 448);
            this.btnThemDTQ.Name = "btnThemDTQ";
            this.btnThemDTQ.Size = new System.Drawing.Size(110, 35);
            this.btnThemDTQ.TabIndex = 6;
            this.btnThemDTQ.Text = "Thêm";
            this.btnThemDTQ.UseVisualStyleBackColor = true;
            this.btnThemDTQ.Click += new System.EventHandler(this.btnThemDTQ_Click);

            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(862, 602);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 650);
            this.Controls.Add(this.tabDanhMuc);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Danh mục";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            this.tabDanhMuc.ResumeLayout(false);
            this.tabPhuongTien.ResumeLayout(false);
            this.tabPhuongTien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).EndInit();
            this.tabDiemBan.ResumeLayout(false);
            this.tabDiemBan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).EndInit();
            this.tabHDV.ResumeLayout(false);
            this.tabHDV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).EndInit();
            this.tabDiemTQ.ResumeLayout(false);
            this.tabDiemTQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabDanhMuc;
        private System.Windows.Forms.TabPage tabPhuongTien;
        private System.Windows.Forms.DataGridView dgvPT;
        private System.Windows.Forms.Label lblPTMa;
        private System.Windows.Forms.TextBox txtPTMa;
        private System.Windows.Forms.Label lblPTTen;
        private System.Windows.Forms.TextBox txtPTTen;
        private System.Windows.Forms.Label lblPTGhiChu;
        private System.Windows.Forms.TextBox txtPTGhiChu;
        private System.Windows.Forms.Button btnThemPT;

        private System.Windows.Forms.TabPage tabDiemBan;
        private System.Windows.Forms.DataGridView dgvDB;
        private System.Windows.Forms.Label lblDBMa;
        private System.Windows.Forms.TextBox txtDBMa;
        private System.Windows.Forms.Label lblDBTen;
        private System.Windows.Forms.TextBox txtDBTen;
        private System.Windows.Forms.Label lblDBDiaChi;
        private System.Windows.Forms.TextBox txtDBDiaChi;
        private System.Windows.Forms.Label lblDBDT;
        private System.Windows.Forms.TextBox txtDBDT;
        private System.Windows.Forms.Button btnThemDB;

        private System.Windows.Forms.TabPage tabHDV;
        private System.Windows.Forms.DataGridView dgvHDV;
        private System.Windows.Forms.Label lblHDVMa;
        private System.Windows.Forms.TextBox txtHDVMa;
        private System.Windows.Forms.Label lblHDVTen;
        private System.Windows.Forms.TextBox txtHDVTen;
        private System.Windows.Forms.Label lblHDVDT;
        private System.Windows.Forms.TextBox txtHDVDT;
        private System.Windows.Forms.Label lblLuong;
        private System.Windows.Forms.NumericUpDown numLuong;
        private System.Windows.Forms.Button btnThemHDV;

        private System.Windows.Forms.TabPage tabDiemTQ;
        private System.Windows.Forms.DataGridView dgvDTQ;
        private System.Windows.Forms.Label lblDTQMa;
        private System.Windows.Forms.TextBox txtDTQMa;
        private System.Windows.Forms.Label lblDTQTen;
        private System.Windows.Forms.TextBox txtDTQTen;
        private System.Windows.Forms.Label lblDTQDiaDiem;
        private System.Windows.Forms.TextBox txtDTQDiaDiem;
        private System.Windows.Forms.Label lblDTQNoiDung;
        private System.Windows.Forms.TextBox txtDTQNoiDung;
        private System.Windows.Forms.Label lblDTQYNghia;
        private System.Windows.Forms.TextBox txtDTQYNghia;
        private System.Windows.Forms.Button btnThemDTQ;

        private System.Windows.Forms.Button btnDong;
    }
}