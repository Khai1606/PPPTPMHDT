﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmLuongThongKe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabTK = new System.Windows.Forms.TabControl();

            // Tab 1: Lương HDV
            this.tabLuong = new System.Windows.Forms.TabPage();
            this.lblThangLuong = new System.Windows.Forms.Label();
            this.numThangLuong = new System.Windows.Forms.NumericUpDown();
            this.lblNamLuong = new System.Windows.Forms.Label();
            this.numNamLuong = new System.Windows.Forms.NumericUpDown();
            this.btnXemLuong = new System.Windows.Forms.Button();
            this.dgvLuong = new System.Windows.Forms.DataGridView();

            // Tab 2: Thống kê Doanh thu
            this.tabDoanhThu = new System.Windows.Forms.TabPage();
            this.lblThangDT = new System.Windows.Forms.Label();
            this.numThangDT = new System.Windows.Forms.NumericUpDown();
            this.lblNamDT = new System.Windows.Forms.Label();
            this.numNamDT = new System.Windows.Forms.NumericUpDown();
            this.btnXemDT = new System.Windows.Forms.Button();
            this.dgvDoanhThu = new System.Windows.Forms.DataGridView();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabTK.SuspendLayout();
            this.tabLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThangLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).BeginInit();
            this.tabDoanhThu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThangDT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamDT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).BeginInit();
            this.SuspendLayout();

            // 
            // tabTK
            // 
            this.tabTK.Controls.Add(this.tabLuong);
            this.tabTK.Controls.Add(this.tabDoanhThu);
            this.tabTK.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabTK.Location = new System.Drawing.Point(12, 12);
            this.tabTK.Name = "tabTK";
            this.tabTK.SelectedIndex = 0;
            this.tabTK.Size = new System.Drawing.Size(960, 580);
            this.tabTK.TabIndex = 0;

            // 
            // tabLuong (Bảng lương HDV)
            // 
            this.tabLuong.Controls.Add(this.lblThangLuong);
            this.tabLuong.Controls.Add(this.numThangLuong);
            this.tabLuong.Controls.Add(this.lblNamLuong);
            this.tabLuong.Controls.Add(this.numNamLuong);
            this.tabLuong.Controls.Add(this.btnXemLuong);
            this.tabLuong.Controls.Add(this.dgvLuong);
            this.tabLuong.Location = new System.Drawing.Point(4, 29);
            this.tabLuong.Name = "tabLuong";
            this.tabLuong.Padding = new System.Windows.Forms.Padding(3);
            this.tabLuong.Size = new System.Drawing.Size(952, 547);
            this.tabLuong.TabIndex = 0;
            this.tabLuong.Text = "Lương hướng dẫn viên";
            this.tabLuong.UseVisualStyleBackColor = true;

            // lblThangLuong & numThangLuong
            this.lblThangLuong.AutoSize = true;
            this.lblThangLuong.Location = new System.Drawing.Point(15, 20);
            this.lblThangLuong.Text = "Tháng:";
            this.numThangLuong.Location = new System.Drawing.Point(70, 17);
            this.numThangLuong.Maximum = new decimal(new int[] { 12, 0, 0, 0 });
            this.numThangLuong.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThangLuong.Size = new System.Drawing.Size(70, 27);

            // lblNamLuong & numNamLuong
            this.lblNamLuong.AutoSize = true;
            this.lblNamLuong.Location = new System.Drawing.Point(160, 20);
            this.lblNamLuong.Text = "Năm:";
            this.numNamLuong.Location = new System.Drawing.Point(210, 17);
            this.numNamLuong.Maximum = new decimal(new int[] { 2100, 0, 0, 0 });
            this.numNamLuong.Minimum = new decimal(new int[] { 2000, 0, 0, 0 });
            this.numNamLuong.Size = new System.Drawing.Size(90, 27);

            // btnXemLuong
            this.btnXemLuong.Location = new System.Drawing.Point(320, 14);
            this.btnXemLuong.Name = "btnXemLuong";
            this.btnXemLuong.Size = new System.Drawing.Size(120, 33);
            this.btnXemLuong.TabIndex = 2;
            this.btnXemLuong.Text = "Tính bảng lương";
            this.btnXemLuong.UseVisualStyleBackColor = true;
            this.btnXemLuong.Click += new System.EventHandler(this.btnXemLuong_Click);

            // dgvLuong
            this.dgvLuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLuong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLuong.Location = new System.Drawing.Point(15, 60);
            this.dgvLuong.Name = "dgvLuong";
            this.dgvLuong.RowHeadersWidth = 51;
            this.dgvLuong.RowTemplate.Height = 24;
            this.dgvLuong.Size = new System.Drawing.Size(920, 470);
            this.dgvLuong.TabIndex = 3;

            // 
            // tabDoanhThu (Thống kê Doanh thu)
            // 
            this.tabDoanhThu.Controls.Add(this.lblThangDT);
            this.tabDoanhThu.Controls.Add(this.numThangDT);
            this.tabDoanhThu.Controls.Add(this.lblNamDT);
            this.tabDoanhThu.Controls.Add(this.numNamDT);
            this.tabDoanhThu.Controls.Add(this.btnXemDT);
            this.tabDoanhThu.Controls.Add(this.dgvDoanhThu);
            this.tabDoanhThu.Location = new System.Drawing.Point(4, 29);
            this.tabDoanhThu.Name = "tabDoanhThu";
            this.tabDoanhThu.Padding = new System.Windows.Forms.Padding(3);
            this.tabDoanhThu.Size = new System.Drawing.Size(952, 547);
            this.tabDoanhThu.TabIndex = 1;
            this.tabDoanhThu.Text = "Thống kê doanh thu";
            this.tabDoanhThu.UseVisualStyleBackColor = true;

            // lblThangDT & numThangDT
            this.lblThangDT.AutoSize = true;
            this.lblThangDT.Location = new System.Drawing.Point(15, 20);
            this.lblThangDT.Text = "Tháng:";
            this.numThangDT.Location = new System.Drawing.Point(70, 17);
            this.numThangDT.Maximum = new decimal(new int[] { 12, 0, 0, 0 });
            this.numThangDT.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThangDT.Size = new System.Drawing.Size(70, 27);

            // lblNamDT & numNamDT
            this.lblNamDT.AutoSize = true;
            this.lblNamDT.Location = new System.Drawing.Point(160, 20);
            this.lblNamDT.Text = "Năm:";
            this.numNamDT.Location = new System.Drawing.Point(210, 17);
            this.numNamDT.Maximum = new decimal(new int[] { 2100, 0, 0, 0 });
            this.numNamDT.Minimum = new decimal(new int[] { 2000, 0, 0, 0 });
            this.numNamDT.Size = new System.Drawing.Size(90, 27);

            // btnXemDT
            this.btnXemDT.Location = new System.Drawing.Point(320, 14);
            this.btnXemDT.Name = "btnXemDT";
            this.btnXemDT.Size = new System.Drawing.Size(120, 33);
            this.btnXemDT.TabIndex = 2;
            this.btnXemDT.Text = "Xem thống kê";
            this.btnXemDT.UseVisualStyleBackColor = true;
            this.btnXemDT.Click += new System.EventHandler(this.btnXemDT_Click);

            // dgvDoanhThu
            this.dgvDoanhThu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoanhThu.Location = new System.Drawing.Point(15, 60);
            this.dgvDoanhThu.Name = "dgvDoanhThu";
            this.dgvDoanhThu.RowHeadersWidth = 51;
            this.dgvDoanhThu.RowTemplate.Height = 24;
            this.dgvDoanhThu.Size = new System.Drawing.Size(920, 470);
            this.dgvDoanhThu.TabIndex = 3;

            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(862, 602);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // 
            // FrmLuongThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 650);
            this.Controls.Add(this.tabTK);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmLuongThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Thống kê - Tính lương";
            this.Load += new System.EventHandler(this.FrmLuongThongKe_Load);
            this.tabTK.ResumeLayout(false);
            this.tabLuong.ResumeLayout(false);
            this.tabLuong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThangLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).EndInit();
            this.tabDoanhThu.ResumeLayout(false);
            this.tabDoanhThu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThangDT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamDT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabTK;
        private System.Windows.Forms.TabPage tabLuong;
        private System.Windows.Forms.Label lblThangLuong;
        private System.Windows.Forms.NumericUpDown numThangLuong;
        private System.Windows.Forms.Label lblNamLuong;
        private System.Windows.Forms.NumericUpDown numNamLuong;
        private System.Windows.Forms.Button btnXemLuong;
        private System.Windows.Forms.DataGridView dgvLuong;

        private System.Windows.Forms.TabPage tabDoanhThu;
        private System.Windows.Forms.Label lblThangDT;
        private System.Windows.Forms.NumericUpDown numThangDT;
        private System.Windows.Forms.Label lblNamDT;
        private System.Windows.Forms.NumericUpDown numNamDT;
        private System.Windows.Forms.Button btnXemDT;
        private System.Windows.Forms.DataGridView dgvDoanhThu;

        private System.Windows.Forms.Button btnDong;
    }
}