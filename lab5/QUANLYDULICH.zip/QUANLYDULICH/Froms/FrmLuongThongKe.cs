﻿using System;
using System.Windows.Forms;
using QuanLyCongTyDuLich.Services;

namespace QuanLyCongTyDuLich.Forms
{
    public partial class FrmLuongThongKe : Form
    {
        private readonly ThongKeService svc = new ThongKeService();

        public FrmLuongThongKe()
        {
            InitializeComponent();
        }

        private void FrmLuongThongKe_Load(object sender, EventArgs e)
        {
            int thang = DateTime.Today.Month;
            int nam = DateTime.Today.Year;

            numThangLuong.Value = thang;
            numNamLuong.Value = nam;
            numThangDT.Value = thang;
            numNamDT.Value = nam;

            btnXemLuong_Click(sender, e);
            btnXemDT_Click(sender, e);
        }

        private void btnXemLuong_Click(object sender, EventArgs e)
        {
            dgvLuong.DataSource = svc.BangLuong((int)numThangLuong.Value, (int)numNamLuong.Value);
        }

        private void btnXemDT_Click(object sender, EventArgs e)
        {
            dgvDoanhThu.DataSource = svc.ThongKeDoanhThu((int)numThangDT.Value, (int)numNamDT.Value);
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}