﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmTour
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblChonTour = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.tabTour = new System.Windows.Forms.TabControl();

            // Tab 1: Tour
            this.tabP1 = new System.Windows.Forms.TabPage();
            this.dgvTour = new System.Windows.Forms.DataGridView();
            this.lblMa = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblNgay = new System.Windows.Forms.Label();
            this.numNgay = new System.Windows.Forms.NumericUpDown();
            this.lblDem = new System.Windows.Forms.Label();
            this.numDem = new System.Windows.Forms.NumericUpDown();
            this.lblGia = new System.Windows.Forms.Label();
            this.numGia = new System.Windows.Forms.NumericUpDown();
            this.lblMoTa = new System.Windows.Forms.Label();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.btnThemTour = new System.Windows.Forms.Button();

            // Tab 2: Diem Dung
            this.tabP2 = new System.Windows.Forms.TabPage();
            this.dgvDiemDung = new System.Windows.Forms.DataGridView();
            this.lblThuTu = new System.Windows.Forms.Label();
            this.numThuTu = new System.Windows.Forms.NumericUpDown();
            this.lblDiemDung = new System.Windows.Forms.Label();
            this.txtDiemDung = new System.Windows.Forms.TextBox();
            this.chkDoiPT = new System.Windows.Forms.CheckBox();
            this.chkAn = new System.Windows.Forms.CheckBox();
            this.chkKS = new System.Windows.Forms.CheckBox();
            this.lblSao = new System.Windows.Forms.Label();
            this.numSao = new System.Windows.Forms.NumericUpDown();
            this.lblGhiChuDD = new System.Windows.Forms.Label();
            this.txtGhiChuDD = new System.Windows.Forms.TextBox();
            this.btnThemDD = new System.Windows.Forms.Button();

            // Tab 3: Chang PT
            this.tabP3 = new System.Windows.Forms.TabPage();
            this.dgvChang = new System.Windows.Forms.DataGridView();
            this.lblChang = new System.Windows.Forms.Label();
            this.numChang = new System.Windows.Forms.NumericUpDown();
            this.lblPT = new System.Windows.Forms.Label();
            this.cboPT = new System.Windows.Forms.ComboBox();
            this.lblGhiChuPT = new System.Windows.Forms.Label();
            this.txtGhiChuPT = new System.Windows.Forms.TextBox();
            this.btnThemChang = new System.Windows.Forms.Button();

            // Tab 4: Diem TQ
            this.tabP4 = new System.Windows.Forms.TabPage();
            this.dgvTQ = new System.Windows.Forms.DataGridView();
            this.lblDTQ = new System.Windows.Forms.Label();
            this.cboDTQ = new System.Windows.Forms.ComboBox();
            this.lblThuTuTQ = new System.Windows.Forms.Label();
            this.numThuTuTQ = new System.Windows.Forms.NumericUpDown();
            this.btnThemTQ = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabTour.SuspendLayout();
            this.tabP1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).BeginInit();
            this.tabP2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSao)).BeginInit();
            this.tabP3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChang)).BeginInit();
            this.tabP4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTuTQ)).BeginInit();
            this.SuspendLayout();

            // 
            // lblChonTour
            // 
            this.lblChonTour.AutoSize = true;
            this.lblChonTour.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonTour.Location = new System.Drawing.Point(20, 15);
            this.lblChonTour.Name = "lblChonTour";
            this.lblChonTour.Size = new System.Drawing.Size(240, 20);
            this.lblChonTour.Text = "Tour đang chọn (cho các tab hành trình):";
            // 
            // cboTour
            // 
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTour.FormattingEnabled = true;
            this.cboTour.Location = new System.Drawing.Point(270, 12);
            this.cboTour.Name = "cboTour";
            this.cboTour.Size = new System.Drawing.Size(300, 28);
            this.cboTour.TabIndex = 1;
            this.cboTour.SelectedIndexChanged += new System.EventHandler(this.cboTour_SelectedIndexChanged);

            // 
            // tabTour
            // 
            this.tabTour.Controls.Add(this.tabP1);
            this.tabTour.Controls.Add(this.tabP2);
            this.tabTour.Controls.Add(this.tabP3);
            this.tabTour.Controls.Add(this.tabP4);
            this.tabTour.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabTour.Location = new System.Drawing.Point(15, 50);
            this.tabTour.Name = "tabTour";
            this.tabTour.SelectedIndex = 0;
            this.tabTour.Size = new System.Drawing.Size(950, 540);
            this.tabTour.TabIndex = 2;

            // 
            // tabP1 (Tour)
            // 
            this.tabP1.Controls.Add(this.dgvTour);
            this.tabP1.Controls.Add(this.lblMa);
            this.tabP1.Controls.Add(this.txtMa);
            this.tabP1.Controls.Add(this.lblTen);
            this.tabP1.Controls.Add(this.txtTen);
            this.tabP1.Controls.Add(this.lblNgay);
            this.tabP1.Controls.Add(this.numNgay);
            this.tabP1.Controls.Add(this.lblDem);
            this.tabP1.Controls.Add(this.numDem);
            this.tabP1.Controls.Add(this.lblGia);
            this.tabP1.Controls.Add(this.numGia);
            this.tabP1.Controls.Add(this.lblMoTa);
            this.tabP1.Controls.Add(this.txtMoTa);
            this.tabP1.Controls.Add(this.btnThemTour);
            this.tabP1.Location = new System.Drawing.Point(4, 29);
            this.tabP1.Name = "tabP1";
            this.tabP1.Padding = new System.Windows.Forms.Padding(3);
            this.tabP1.Size = new System.Drawing.Size(942, 507);
            this.tabP1.TabIndex = 0;
            this.tabP1.Text = "Tour";
            this.tabP1.UseVisualStyleBackColor = true;

            // dgvTour
            this.dgvTour.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTour.Location = new System.Drawing.Point(15, 15);
            this.dgvTour.Name = "dgvTour";
            this.dgvTour.RowHeadersWidth = 51;
            this.dgvTour.RowTemplate.Height = 24;
            this.dgvTour.Size = new System.Drawing.Size(910, 320);
            this.dgvTour.TabIndex = 0;

            // Controls của Tab 1
            this.lblMa.AutoSize = true;
            this.lblMa.Location = new System.Drawing.Point(15, 355);
            this.lblMa.Text = "Mã tour:";
            this.txtMa.Location = new System.Drawing.Point(115, 352);
            this.txtMa.Size = new System.Drawing.Size(130, 27);

            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(265, 355);
            this.lblTen.Text = "Tên tour:";
            this.txtTen.Location = new System.Drawing.Point(340, 352);
            this.txtTen.Size = new System.Drawing.Size(380, 27);

            this.lblNgay.AutoSize = true;
            this.lblNgay.Location = new System.Drawing.Point(15, 395);
            this.lblNgay.Text = "Số ngày:";
            this.numNgay.Location = new System.Drawing.Point(115, 392);
            this.numNgay.Size = new System.Drawing.Size(80, 27);
            this.numNgay.Value = new decimal(new int[] { 3, 0, 0, 0 });

            this.lblDem.AutoSize = true;
            this.lblDem.Location = new System.Drawing.Point(220, 395);
            this.lblDem.Text = "Số đêm:";
            this.numDem.Location = new System.Drawing.Point(290, 392);
            this.numDem.Size = new System.Drawing.Size(80, 27);
            this.numDem.Value = new decimal(new int[] { 2, 0, 0, 0 });

            this.lblGia.AutoSize = true;
            this.lblGia.Location = new System.Drawing.Point(400, 395);
            this.lblGia.Text = "Đơn giá / khách:";
            this.numGia.Location = new System.Drawing.Point(520, 392);
            this.numGia.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            this.numGia.Size = new System.Drawing.Size(150, 27);

            this.lblMoTa.AutoSize = true;
            this.lblMoTa.Location = new System.Drawing.Point(15, 435);
            this.lblMoTa.Text = "Mô tả:";
            this.txtMoTa.Location = new System.Drawing.Point(115, 432);
            this.txtMoTa.Size = new System.Drawing.Size(605, 27);

            this.btnThemTour.Location = new System.Drawing.Point(750, 427);
            this.btnThemTour.Name = "btnThemTour";
            this.btnThemTour.Size = new System.Drawing.Size(120, 35);
            this.btnThemTour.Text = "Thêm tour";
            this.btnThemTour.UseVisualStyleBackColor = true;
            this.btnThemTour.Click += new System.EventHandler(this.btnThemTour_Click);

            // 
            // tabP2 (Diem Dung)
            // 
            this.tabP2.Controls.Add(this.dgvDiemDung);
            this.tabP2.Controls.Add(this.lblThuTu);
            this.tabP2.Controls.Add(this.numThuTu);
            this.tabP2.Controls.Add(this.lblDiemDung);
            this.tabP2.Controls.Add(this.txtDiemDung);
            this.tabP2.Controls.Add(this.chkDoiPT);
            this.tabP2.Controls.Add(this.chkAn);
            this.tabP2.Controls.Add(this.chkKS);
            this.tabP2.Controls.Add(this.lblSao);
            this.tabP2.Controls.Add(this.numSao);
            this.tabP2.Controls.Add(this.lblGhiChuDD);
            this.tabP2.Controls.Add(this.txtGhiChuDD);
            this.tabP2.Controls.Add(this.btnThemDD);
            this.tabP2.Location = new System.Drawing.Point(4, 29);
            this.tabP2.Name = "tabP2";
            this.tabP2.Padding = new System.Windows.Forms.Padding(3);
            this.tabP2.Size = new System.Drawing.Size(942, 507);
            this.tabP2.TabIndex = 1;
            this.tabP2.Text = "Điểm dừng";
            this.tabP2.UseVisualStyleBackColor = true;

            this.dgvDiemDung.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDiemDung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDiemDung.Location = new System.Drawing.Point(15, 15);
            this.dgvDiemDung.Size = new System.Drawing.Size(910, 320);

            this.lblThuTu.AutoSize = true;
            this.lblThuTu.Location = new System.Drawing.Point(15, 355);
            this.lblThuTu.Text = "Thứ tự:";
            this.numThuTu.Location = new System.Drawing.Point(115, 352);
            this.numThuTu.Size = new System.Drawing.Size(80, 27);
            this.numThuTu.Value = new decimal(new int[] { 1, 0, 0, 0 });

            this.lblDiemDung.AutoSize = true;
            this.lblDiemDung.Location = new System.Drawing.Point(220, 355);
            this.lblDiemDung.Text = "Tên điểm dừng:";
            this.txtDiemDung.Location = new System.Drawing.Point(340, 352);
            this.txtDiemDung.Size = new System.Drawing.Size(380, 27);

            this.chkDoiPT.AutoSize = true;
            this.chkDoiPT.Location = new System.Drawing.Point(15, 395);
            this.chkDoiPT.Text = "Đổi phương tiện";

            this.chkAn.AutoSize = true;
            this.chkAn.Location = new System.Drawing.Point(160, 395);
            this.chkAn.Text = "Có nơi ăn";

            this.chkKS.AutoSize = true;
            this.chkKS.Location = new System.Drawing.Point(280, 395);
            this.chkKS.Text = "Có khách sạn";
            this.chkKS.CheckedChanged += new System.EventHandler(this.chkKS_CheckedChanged);

            this.lblSao.AutoSize = true;
            this.lblSao.Location = new System.Drawing.Point(410, 395);
            this.lblSao.Text = "Hạng sao:";
            this.numSao.Enabled = false;
            this.numSao.Location = new System.Drawing.Point(490, 392);
            this.numSao.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            this.numSao.Minimum = new decimal(new int[] { 2, 0, 0, 0 });
            this.numSao.Size = new System.Drawing.Size(60, 27);
            this.numSao.Value = new decimal(new int[] { 3, 0, 0, 0 });

            this.lblGhiChuDD.AutoSize = true;
            this.lblGhiChuDD.Location = new System.Drawing.Point(15, 435);
            this.lblGhiChuDD.Text = "Ghi chú:";
            this.txtGhiChuDD.Location = new System.Drawing.Point(115, 432);
            this.txtGhiChuDD.Size = new System.Drawing.Size(605, 27);

            this.btnThemDD.Location = new System.Drawing.Point(750, 427);
            this.btnThemDD.Size = new System.Drawing.Size(120, 35);
            this.btnThemDD.Text = "Thêm điểm dừng";
            this.btnThemDD.UseVisualStyleBackColor = true;
            this.btnThemDD.Click += new System.EventHandler(this.btnThemDD_Click);

            // 
            // tabP3 (Chang PT)
            // 
            this.tabP3.Controls.Add(this.dgvChang);
            this.tabP3.Controls.Add(this.lblChang);
            this.tabP3.Controls.Add(this.numChang);
            this.tabP3.Controls.Add(this.lblPT);
            this.tabP3.Controls.Add(this.cboPT);
            this.tabP3.Controls.Add(this.lblGhiChuPT);
            this.tabP3.Controls.Add(this.txtGhiChuPT);
            this.tabP3.Controls.Add(this.btnThemChang);
            this.tabP3.Location = new System.Drawing.Point(4, 29);
            this.tabP3.Name = "tabP3";
            this.tabP3.Padding = new System.Windows.Forms.Padding(3);
            this.tabP3.Size = new System.Drawing.Size(942, 507);
            this.tabP3.TabIndex = 2;
            this.tabP3.Text = "Phương tiện theo chặng";
            this.tabP3.UseVisualStyleBackColor = true;

            this.dgvChang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChang.Location = new System.Drawing.Point(15, 15);
            this.dgvChang.Size = new System.Drawing.Size(910, 320);

            this.lblChang.AutoSize = true;
            this.lblChang.Location = new System.Drawing.Point(15, 355);
            this.lblChang.Text = "Chặng thứ:";
            this.numChang.Location = new System.Drawing.Point(115, 352);
            this.numChang.Size = new System.Drawing.Size(80, 27);
            this.numChang.Value = new decimal(new int[] { 1, 0, 0, 0 });

            this.lblPT.AutoSize = true;
            this.lblPT.Location = new System.Drawing.Point(220, 355);
            this.lblPT.Text = "Phương tiện:";
            this.cboPT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPT.Location = new System.Drawing.Point(320, 352);
            this.cboPT.Size = new System.Drawing.Size(200, 28);

            this.lblGhiChuPT.AutoSize = true;
            this.lblGhiChuPT.Location = new System.Drawing.Point(15, 395);
            this.lblGhiChuPT.Text = "Ghi chú:";
            this.txtGhiChuPT.Location = new System.Drawing.Point(115, 392);
            this.txtGhiChuPT.Size = new System.Drawing.Size(605, 27);

            this.btnThemChang.Location = new System.Drawing.Point(750, 387);
            this.btnThemChang.Size = new System.Drawing.Size(120, 35);
            this.btnThemChang.Text = "Gắn phương tiện";
            this.btnThemChang.UseVisualStyleBackColor = true;
            this.btnThemChang.Click += new System.EventHandler(this.btnThemChang_Click);

            // 
            // tabP4 (Diem TQ)
            // 
            this.tabP4.Controls.Add(this.dgvTQ);
            this.tabP4.Controls.Add(this.lblDTQ);
            this.tabP4.Controls.Add(this.cboDTQ);
            this.tabP4.Controls.Add(this.lblThuTuTQ);
            this.tabP4.Controls.Add(this.numThuTuTQ);
            this.tabP4.Controls.Add(this.btnThemTQ);
            this.tabP4.Location = new System.Drawing.Point(4, 29);
            this.tabP4.Name = "tabP4";
            this.tabP4.Padding = new System.Windows.Forms.Padding(3);
            this.tabP4.Size = new System.Drawing.Size(942, 507);
            this.tabP4.TabIndex = 3;
            this.tabP4.Text = "Điểm tham quan";
            this.tabP4.UseVisualStyleBackColor = true;

            this.dgvTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTQ.Location = new System.Drawing.Point(15, 15);
            this.dgvTQ.Size = new System.Drawing.Size(910, 320);

            this.lblDTQ.AutoSize = true;
            this.lblDTQ.Location = new System.Drawing.Point(15, 355);
            this.lblDTQ.Text = "Điểm tham quan:";
            this.cboDTQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDTQ.Location = new System.Drawing.Point(140, 352);
            this.cboDTQ.Size = new System.Drawing.Size(300, 28);

            this.lblThuTuTQ.AutoSize = true;
            this.lblThuTuTQ.Location = new System.Drawing.Point(470, 355);
            this.lblThuTuTQ.Text = "Thứ tự:";
            this.numThuTuTQ.Location = new System.Drawing.Point(530, 352);
            this.numThuTuTQ.Size = new System.Drawing.Size(80, 27);
            this.numThuTuTQ.Value = new decimal(new int[] { 1, 0, 0, 0 });

            this.btnThemTQ.Location = new System.Drawing.Point(650, 347);
            this.btnThemTQ.Size = new System.Drawing.Size(120, 35);
            this.btnThemTQ.Text = "Gắn điểm TQ";
            this.btnThemTQ.UseVisualStyleBackColor = true;
            this.btnThemTQ.Click += new System.EventHandler(this.btnThemTQ_Click);

            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(855, 600);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 3;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // 
            // FrmTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 645);
            this.Controls.Add(this.lblChonTour);
            this.Controls.Add(this.cboTour);
            this.Controls.Add(this.tabTour);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmTour";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Tour - hành trình";
            this.Load += new System.EventHandler(this.FrmTour_Load);
            this.tabTour.ResumeLayout(false);
            this.tabP1.ResumeLayout(false);
            this.tabP1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).EndInit();
            this.tabP2.ResumeLayout(false);
            this.tabP2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSao)).EndInit();
            this.tabP3.ResumeLayout(false);
            this.tabP3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChang)).EndInit();
            this.tabP4.ResumeLayout(false);
            this.tabP4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTuTQ)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblChonTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.TabControl tabTour;

        private System.Windows.Forms.TabPage tabP1;
        private System.Windows.Forms.DataGridView dgvTour;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblNgay;
        private System.Windows.Forms.NumericUpDown numNgay;
        private System.Windows.Forms.Label lblDem;
        private System.Windows.Forms.NumericUpDown numDem;
        private System.Windows.Forms.Label lblGia;
        private System.Windows.Forms.NumericUpDown numGia;
        private System.Windows.Forms.Label lblMoTa;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Button btnThemTour;

        private System.Windows.Forms.TabPage tabP2;
        private System.Windows.Forms.DataGridView dgvDiemDung;
        private System.Windows.Forms.Label lblThuTu;
        private System.Windows.Forms.NumericUpDown numThuTu;
        private System.Windows.Forms.Label lblDiemDung;
        private System.Windows.Forms.TextBox txtDiemDung;
        private System.Windows.Forms.CheckBox chkDoiPT;
        private System.Windows.Forms.CheckBox chkAn;
        private System.Windows.Forms.CheckBox chkKS;
        private System.Windows.Forms.Label lblSao;
        private System.Windows.Forms.NumericUpDown numSao;
        private System.Windows.Forms.Label lblGhiChuDD;
        private System.Windows.Forms.TextBox txtGhiChuDD;
        private System.Windows.Forms.Button btnThemDD;

        private System.Windows.Forms.TabPage tabP3;
        private System.Windows.Forms.DataGridView dgvChang;
        private System.Windows.Forms.Label lblChang;
        private System.Windows.Forms.NumericUpDown numChang;
        private System.Windows.Forms.Label lblPT;
        private System.Windows.Forms.ComboBox cboPT;
        private System.Windows.Forms.Label lblGhiChuPT;
        private System.Windows.Forms.TextBox txtGhiChuPT;
        private System.Windows.Forms.Button btnThemChang;

        private System.Windows.Forms.TabPage tabP4;
        private System.Windows.Forms.DataGridView dgvTQ;
        private System.Windows.Forms.Label lblDTQ;
        private System.Windows.Forms.ComboBox cboDTQ;
        private System.Windows.Forms.Label lblThuTuTQ;
        private System.Windows.Forms.NumericUpDown numThuTuTQ;
        private System.Windows.Forms.Button btnThemTQ;

        private System.Windows.Forms.Button btnDong;
    }
}