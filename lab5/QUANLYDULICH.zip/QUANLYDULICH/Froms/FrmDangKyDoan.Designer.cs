﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDangKyDoan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpDoan = new System.Windows.Forms.GroupBox();
            this.lblMaDoan = new System.Windows.Forms.Label();
            this.txtMaDoan = new System.Windows.Forms.TextBox();
            this.lblTenCQ = new System.Windows.Forms.Label();
            this.txtTenCQ = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDT = new System.Windows.Forms.Label();
            this.txtDT = new System.Windows.Forms.TextBox();
            this.lblDaiDien = new System.Windows.Forms.Label();
            this.txtDaiDien = new System.Windows.Forms.TextBox();

            this.grpDangKy = new System.Windows.Forms.GroupBox();
            this.lblSo = new System.Windows.Forms.Label();
            this.txtSo = new System.Windows.Forms.TextBox();
            this.lblTour = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.lblNgayDi = new System.Windows.Forms.Label();
            this.dtDi = new System.Windows.Forms.DateTimePicker();
            this.lblNguoi = new System.Windows.Forms.Label();
            this.numNguoi = new System.Windows.Forms.NumericUpDown();
            this.lblDon = new System.Windows.Forms.Label();
            this.txtDon = new System.Windows.Forms.TextBox();
            this.lblCoc = new System.Windows.Forms.Label();
            this.numCoc = new System.Windows.Forms.NumericUpDown();
            this.chkBH = new System.Windows.Forms.CheckBox();
            this.lblKetThucTitle = new System.Windows.Forms.Label();
            this.lblKetThuc = new System.Windows.Forms.Label();
            this.lblTongTitle = new System.Windows.Forms.Label();
            this.lblTong = new System.Windows.Forms.Label();

            this.lblThanhVienTitle = new System.Windows.Forms.Label();
            this.dgvThanhVien = new System.Windows.Forms.DataGridView();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.lblDanhSachTitle = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            this.grpDoan.SuspendLayout();
            this.grpDangKy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            // 
            // grpDoan
            // 
            this.grpDoan.Controls.Add(this.lblMaDoan);
            this.grpDoan.Controls.Add(this.txtMaDoan);
            this.grpDoan.Controls.Add(this.lblTenCQ);
            this.grpDoan.Controls.Add(this.txtTenCQ);
            this.grpDoan.Controls.Add(this.lblDiaChi);
            this.grpDoan.Controls.Add(this.txtDiaChi);
            this.grpDoan.Controls.Add(this.lblDT);
            this.grpDoan.Controls.Add(this.txtDT);
            this.grpDoan.Controls.Add(this.lblDaiDien);
            this.grpDoan.Controls.Add(this.txtDaiDien);
            this.grpDoan.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDoan.Location = new System.Drawing.Point(15, 12);
            this.grpDoan.Name = "grpDoan";
            this.grpDoan.Size = new System.Drawing.Size(480, 260);
            this.grpDoan.TabIndex = 0;
            this.grpDoan.TabStop = false;
            this.grpDoan.Text = "Thông tin đoàn khách";

            // lblMaDoan & txtMaDoan
            this.lblMaDoan.AutoSize = true;
            this.lblMaDoan.Location = new System.Drawing.Point(15, 30);
            this.lblMaDoan.Text = "Mã đoàn:";
            this.txtMaDoan.Location = new System.Drawing.Point(135, 27);
            this.txtMaDoan.Size = new System.Drawing.Size(150, 27);

            // lblTenCQ & txtTenCQ
            this.lblTenCQ.AutoSize = true;
            this.lblTenCQ.Location = new System.Drawing.Point(15, 75);
            this.lblTenCQ.Text = "Cơ quan / gia đình:";
            this.txtTenCQ.Location = new System.Drawing.Point(135, 72);
            this.txtTenCQ.Size = new System.Drawing.Size(325, 27);

            // lblDiaChi & txtDiaChi
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 120);
            this.lblDiaChi.Text = "Địa chỉ:";
            this.txtDiaChi.Location = new System.Drawing.Point(135, 117);
            this.txtDiaChi.Size = new System.Drawing.Size(325, 27);

            // lblDT & txtDT
            this.lblDT.AutoSize = true;
            this.lblDT.Location = new System.Drawing.Point(15, 165);
            this.lblDT.Text = "Điện thoại:";
            this.txtDT.Location = new System.Drawing.Point(135, 162);
            this.txtDT.Size = new System.Drawing.Size(150, 27);

            // lblDaiDien & txtDaiDien
            this.lblDaiDien.AutoSize = true;
            this.lblDaiDien.Location = new System.Drawing.Point(15, 210);
            this.lblDaiDien.Text = "Người đại diện:";
            this.txtDaiDien.Location = new System.Drawing.Point(135, 207);
            this.txtDaiDien.Size = new System.Drawing.Size(325, 27);

            // 
            // grpDangKy
            // 
            this.grpDangKy.Controls.Add(this.lblSo);
            this.grpDangKy.Controls.Add(this.txtSo);
            this.grpDangKy.Controls.Add(this.lblTour);
            this.grpDangKy.Controls.Add(this.cboTour);
            this.grpDangKy.Controls.Add(this.lblNgayDi);
            this.grpDangKy.Controls.Add(this.dtDi);
            this.grpDangKy.Controls.Add(this.lblNguoi);
            this.grpDangKy.Controls.Add(this.numNguoi);
            this.grpDangKy.Controls.Add(this.lblDon);
            this.grpDangKy.Controls.Add(this.txtDon);
            this.grpDangKy.Controls.Add(this.lblCoc);
            this.grpDangKy.Controls.Add(this.numCoc);
            this.grpDangKy.Controls.Add(this.chkBH);
            this.grpDangKy.Controls.Add(this.lblKetThucTitle);
            this.grpDangKy.Controls.Add(this.lblKetThuc);
            this.grpDangKy.Controls.Add(this.lblTongTitle);
            this.grpDangKy.Controls.Add(this.lblTong);
            this.grpDangKy.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDangKy.Location = new System.Drawing.Point(510, 12);
            this.grpDangKy.Name = "grpDangKy";
            this.grpDangKy.Size = new System.Drawing.Size(465, 260);
            this.grpDangKy.TabIndex = 1;
            this.grpDangKy.TabStop = false;
            this.grpDangKy.Text = "Đăng ký tour";

            // lblSo & txtSo
            this.lblSo.AutoSize = true;
            this.lblSo.Location = new System.Drawing.Point(15, 30);
            this.lblSo.Text = "Số phiếu:";
            this.txtSo.Location = new System.Drawing.Point(110, 27);
            this.txtSo.Size = new System.Drawing.Size(115, 27);

            // lblTour & cboTour
            this.lblTour.AutoSize = true;
            this.lblTour.Location = new System.Drawing.Point(235, 30);
            this.lblTour.Text = "Tour:";
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.Location = new System.Drawing.Point(280, 27);
            this.cboTour.Size = new System.Drawing.Size(170, 28);
            this.cboTour.SelectedIndexChanged += new System.EventHandler(this.TinhTong);

            // lblNgayDi & dtDi
            this.lblNgayDi.AutoSize = true;
            this.lblNgayDi.Location = new System.Drawing.Point(15, 75);
            this.lblNgayDi.Text = "Ngày đi:";
            this.dtDi.CustomFormat = "dd/MM/yyyy";
            this.dtDi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDi.Location = new System.Drawing.Point(110, 72);
            this.dtDi.Size = new System.Drawing.Size(115, 27);
            this.dtDi.ValueChanged += new System.EventHandler(this.TinhTong);

            // lblNguoi & numNguoi
            this.lblNguoi.AutoSize = true;
            this.lblNguoi.Location = new System.Drawing.Point(235, 75);
            this.lblNguoi.Text = "Số người:";
            this.numNguoi.Location = new System.Drawing.Point(310, 72);
            this.numNguoi.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numNguoi.Minimum = new decimal(new int[] { 13, 0, 0, 0 });
            this.numNguoi.Size = new System.Drawing.Size(140, 27);
            this.numNguoi.Value = new decimal(new int[] { 13, 0, 0, 0 });
            this.numNguoi.ValueChanged += new System.EventHandler(this.TinhTong);

            // lblDon & txtDon
            this.lblDon.AutoSize = true;
            this.lblDon.Location = new System.Drawing.Point(15, 120);
            this.lblDon.Text = "Địa điểm đón:";
            this.txtDon.Location = new System.Drawing.Point(110, 117);
            this.txtDon.Size = new System.Drawing.Size(340, 27);

            // lblCoc & numCoc
            this.lblCoc.AutoSize = true;
            this.lblCoc.Location = new System.Drawing.Point(15, 165);
            this.lblCoc.Text = "Tiền cọc:";
            this.numCoc.DecimalPlaces = 0;
            this.numCoc.Location = new System.Drawing.Point(110, 162);
            this.numCoc.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numCoc.Size = new System.Drawing.Size(160, 27);

            // chkBH
            this.chkBH.AutoSize = true;
            this.chkBH.Location = new System.Drawing.Point(290, 164);
            this.chkBH.Text = "Mua bảo hiểm";
            this.chkBH.CheckedChanged += new System.EventHandler(this.chkBH_CheckedChanged);

            // lblKetThucTitle & lblKetThuc
            this.lblKetThucTitle.AutoSize = true;
            this.lblKetThucTitle.Location = new System.Drawing.Point(15, 210);
            this.lblKetThucTitle.Text = "Kết thúc DK:";
            this.lblKetThuc.AutoSize = true;
            this.lblKetThuc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKetThuc.Location = new System.Drawing.Point(110, 210);
            this.lblKetThuc.Text = "-";

            // lblTongTitle & lblTong
            this.lblTongTitle.AutoSize = true;
            this.lblTongTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTitle.Location = new System.Drawing.Point(220, 210);
            this.lblTongTitle.Text = "Tổng dự kiến:";
            this.lblTong.AutoSize = true;
            this.lblTong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTong.ForeColor = System.Drawing.Color.FromArgb(180, 0, 0);
            this.lblTong.Location = new System.Drawing.Point(320, 208);
            this.lblTong.Text = "0 đ";

            // 
            // lblThanhVienTitle & dgvThanhVien
            // 
            this.lblThanhVienTitle.AutoSize = true;
            this.lblThanhVienTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanhVienTitle.Location = new System.Drawing.Point(15, 280);
            this.lblThanhVienTitle.Text = "Danh sách người cùng đi (bắt buộc đủ số người khi mua bảo hiểm):";

            this.dgvThanhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThanhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThanhVien.Location = new System.Drawing.Point(15, 305);
            this.dgvThanhVien.Name = "dgvThanhVien";
            this.dgvThanhVien.RowHeadersWidth = 51;
            this.dgvThanhVien.RowTemplate.Height = 24;
            this.dgvThanhVien.Size = new System.Drawing.Size(960, 130);
            this.dgvThanhVien.TabIndex = 2;

            // 
            // btnDangKy & btnHuy
            // 
            this.btnDangKy.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(630, 445);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(160, 35);
            this.btnDangKy.TabIndex = 3;
            this.btnDangKy.Text = "Lập phiếu đăng ký";
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);

            this.btnHuy.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.Location = new System.Drawing.Point(805, 445);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(170, 35);
            this.btnHuy.TabIndex = 4;
            this.btnHuy.Text = "Hủy phiếu (mất cọc)";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);

            // 
            // lblDanhSachTitle & dgv
            // 
            this.lblDanhSachTitle.AutoSize = true;
            this.lblDanhSachTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDanhSachTitle.Location = new System.Drawing.Point(15, 485);
            this.lblDanhSachTitle.Text = "Các phiếu đăng ký đoàn:";

            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(15, 510);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(960, 160);
            this.dgv.TabIndex = 5;

            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.Location = new System.Drawing.Point(865, 680);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 6;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // 
            // FrmDangKyDoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 725);
            this.Controls.Add(this.grpDoan);
            this.Controls.Add(this.grpDangKy);
            this.Controls.Add(this.lblThanhVienTitle);
            this.Controls.Add(this.dgvThanhVien);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.lblDanhSachTitle);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDangKyDoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Phiếu đăng ký theo đoàn";
            this.Load += new System.EventHandler(this.FrmDangKyDoan_Load);
            this.grpDoan.ResumeLayout(false);
            this.grpDoan.PerformLayout();
            this.grpDangKy.ResumeLayout(false);
            this.grpDangKy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.GroupBox grpDoan;
        private System.Windows.Forms.Label lblMaDoan;
        private System.Windows.Forms.TextBox txtMaDoan;
        private System.Windows.Forms.Label lblTenCQ;
        private System.Windows.Forms.TextBox txtTenCQ;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDT;
        private System.Windows.Forms.TextBox txtDT;
        private System.Windows.Forms.Label lblDaiDien;
        private System.Windows.Forms.TextBox txtDaiDien;

        private System.Windows.Forms.GroupBox grpDangKy;
        private System.Windows.Forms.Label lblSo;
        private System.Windows.Forms.TextBox txtSo;
        private System.Windows.Forms.Label lblTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.Label lblNgayDi;
        private System.Windows.Forms.DateTimePicker dtDi;
        private System.Windows.Forms.Label lblNguoi;
        private System.Windows.Forms.NumericUpDown numNguoi;
        private System.Windows.Forms.Label lblDon;
        private System.Windows.Forms.TextBox txtDon;
        private System.Windows.Forms.Label lblCoc;
        private System.Windows.Forms.NumericUpDown numCoc;
        private System.Windows.Forms.CheckBox chkBH;
        private System.Windows.Forms.Label lblKetThucTitle;
        private System.Windows.Forms.Label lblKetThuc;
        private System.Windows.Forms.Label lblTongTitle;
        private System.Windows.Forms.Label lblTong;

        private System.Windows.Forms.Label lblThanhVienTitle;
        private System.Windows.Forms.DataGridView dgvThanhVien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Label lblDanhSachTitle;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}