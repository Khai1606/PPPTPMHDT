﻿using System;
using System.Data;
using QuanLyCongTyDuLich.Data;

namespace QuanLyCongTyDuLich.Services
{
    public class ThongKeService
    {
        public DataTable BangLuong(int thang, int nam)
        {
            var dt = Db.Query(@"SELECT h.MaHDV, h.HoTen, h.LuongCoBan,
                                       ISNULL(c.SoTour, 0) AS SoTour, ISNULL(c.TongThuLao, 0) AS TongThuLaoTour,
                                       CASE WHEN ISNULL(c.SoTour, 0) >= @m THEN @thuong ELSE 0 END AS TienThuong,
                                       h.LuongCoBan + ISNULL(c.TongThuLao, 0) + CASE WHEN ISNULL(c.SoTour, 0) >= @m THEN @thuong ELSE 0 END AS TongThucLinh
                                FROM HuongDanVien h
                                LEFT JOIN (
                                    SELECT MaHDV, COUNT(*) AS SoTour, SUM(ThuLaoTour) AS TongThuLao
                                    FROM PhanCongHDV
                                    WHERE MONTH(NgayBatDau) = @mThang AND YEAR(NgayBatDau) = @mNam
                                    GROUP BY MaHDV
                                ) c ON h.MaHDV = c.MaHDV
                                ORDER BY h.HoTen",
                               Db.P("@m", 3), Db.P("@thuong", 500000m),
                                Db.P("@mThang", thang), Db.P("@mNam", nam));
            return dt;
        }
        public DataTable ThongKeDoanhThu(int thang, int nam)
        {
            decimal doanhThuLe = Convert.ToDecimal(Db.Scalar(@"SELECT ISNULL(SUM(d.ThanhTien), 0)
                                                               FROM DangKyLe d JOIN ChuyenLe c ON d.MaChuyen = c.MaChuyen
                                                               WHERE MONTH(c.NgayDi) = @m AND YEAR(c.NgayDi) = @y",
                                                               Db.P("@m", thang), Db.P("@y", nam)));

            decimal doanhThuDoan = Convert.ToDecimal(Db.Scalar(@"SELECT ISNULL(SUM(TongTienDuKien), 0)
                                                                 FROM DangKyDoan
                                                                 WHERE TrangThai <> @huy AND MONTH(NgayDi) = @m AND YEAR(NgayDi) = @y",
                                                                 Db.P("@huy", QuyDinh.HuyMatCoc), Db.P("@m", thang), Db.P("@y", nam)));

            DataTable dt = new DataTable();
            dt.Columns.Add("KhoanMuc", typeof(string));
            dt.Columns.Add("Thang", typeof(int));
            dt.Columns.Add("Nam", typeof(int));
            dt.Columns.Add("DoanhThu", typeof(decimal));

            dt.Rows.Add("Doanh thu khách lẻ", thang, nam, doanhThuLe);
            dt.Rows.Add("Doanh thu tour đoàn", thang, nam, doanhThuDoan);
            dt.Rows.Add("TỔNG DOANH THU", thang, nam, doanhThuLe + doanhThuDoan);

            return dt;
        }
    }
}